"""Env-aware accessor for config/db-target-system.json and config/test_mapping.py, both of which
are now nested one level deeper by environment (dev/qa) since App IDs for the DB connectors differ
per environment. app/dbautomation/config.py and lib/test_catalog.py each keep their own thin
reader (per-file validation/purpose stays separate, per this codebase's existing convention of not
merging distinct-purpose readers), but both delegate the actual "which app_ids exist right now" and
"which env are we in" questions to this module instead of duplicating that logic themselves.

Reads config/db-target-system.json and config/test_mapping.py fresh from disk on every call (no
caching), matching the "always read the current file" convention already used everywhere else in
this codebase.
"""

import json
from pathlib import Path

from config.env_bootstrap import CURRENT_ENV
from config.test_mapping import TEST_MAPPING

BASE_DIR = Path(__file__).resolve().parent.parent
DB_TARGET_SYSTEM_PATH = BASE_DIR / "config" / "db-target-system.json"


def current_env() -> str:
    return CURRENT_ENV


def _read_db_target_systems() -> dict:
    if not DB_TARGET_SYSTEM_PATH.exists():
        return {}
    all_envs = json.loads(DB_TARGET_SYSTEM_PATH.read_text())
    if CURRENT_ENV not in all_envs:
        raise LookupError(
            f"config/db-target-system.json has no '{CURRENT_ENV}' section (found: {sorted(all_envs.keys())})"
        )
    return all_envs[CURRENT_ENV]


def get_app_config(app_id: str) -> dict:
    config = _read_db_target_systems().get(app_id)
    if not config:
        raise LookupError(f"No dbautomation config found for app_id '{app_id}' in env '{CURRENT_ENV}'")
    return config


def app_ids_for_env() -> list:
    return list(_read_db_target_systems().keys())


def get_test_mapping() -> dict:
    if CURRENT_ENV not in TEST_MAPPING:
        raise LookupError(
            f"config/test_mapping.py has no '{CURRENT_ENV}' section (found: {sorted(TEST_MAPPING.keys())})"
        )
    return TEST_MAPPING[CURRENT_ENV]
