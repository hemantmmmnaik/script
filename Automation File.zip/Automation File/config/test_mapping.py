"""Maps each Okta app_id to the specific CSV test files that should run against it, split by
grant type and by environment (dev/qa) -- App IDs for these connectors differ between
environments, so the top-level key is the environment, selected via config/env_bootstrap.py's
--env flag (config/apps.py::get_test_mapping() returns the slice for the current environment).
Adding a new app/connector to the run means one new dict entry + CSV file(s), no runner changes.

Paths are relative to the repo root (where the scripts/*.py entrypoints are invoked from).
"""

TEST_MAPPING = {
    "dev": {
        "0oa10v7gnfmHtqvwt1d8": {
            "connector_type": "ORACLE",
            "bundle_files": ["test-files/bundle/cstool-bundle.csv"],
            "entitlement_files": ["test-files/entitlement/cstool-entitlement.csv"],
        },
        "0oa10tfup5xJR1rmO1d8": {
            "connector_type": "MSSQL",
            "bundle_files": ["test-files/bundle/cdmassive-bundle.csv"],
            "entitlement_files": ["test-files/entitlement/cdmassive-entitlement.csv"],
        },
    },
    "qa": {
        "REPLACE_ME_QA_CSTOOL_APP_ID": {
            "connector_type": "ORACLE",
            "bundle_files": ["test-files/bundle/cstool-bundle.csv"],
            "entitlement_files": ["test-files/entitlement/cstool-entitlement.csv"],
        },
        "REPLACE_ME_QA_CDMASSIVE_APP_ID": {
            "connector_type": "MSSQL",
            "bundle_files": ["test-files/bundle/cdmassive-bundle.csv"],
            "entitlement_files": ["test-files/entitlement/cdmassive-entitlement.csv"],
        },
    },
}
