"""Resolves which environment (dev/qa) this process should run against and loads the matching
.env.<env> file, BEFORE app.settings (or anything importing it) is ever imported.

Every CLI script under scripts/ must import this module as its very first import -- ahead of any
app.*/lib.*/config.* import -- since app.settings reads os.environ into frozen module-level
constants the moment it is first imported. Parsing --env inside argparse (which normally runs
well after those imports) would be too late to matter; this module does its own minimal argv scan
instead, so it can run first.
"""

import sys
from pathlib import Path

from dotenv import load_dotenv

VALID_ENVS = ("dev", "qa")
DEFAULT_ENV = "dev"

# Computed independently (not by importing app.settings.BASE_DIR) -- importing app.settings is
# exactly what this module must run before.
BASE_DIR = Path(__file__).resolve().parent.parent


def _parse_env_from_argv(argv: list) -> str:
    """Manual argv scan supporting both '--env qa' and '--env=qa'. Keep the accepted values in
    sync with the --env choices declared in each script's argparse (see scripts/*.py) -- argparse
    only re-validates for --help/consistency, this scan is what actually takes effect."""
    for i, arg in enumerate(argv):
        if arg == "--env" and i + 1 < len(argv):
            return argv[i + 1]
        if arg.startswith("--env="):
            return arg.split("=", 1)[1]
    return DEFAULT_ENV


def _resolve_env(argv: list) -> str:
    env = _parse_env_from_argv(argv)
    if env not in VALID_ENVS:
        raise SystemExit(f"Invalid --env '{env}': expected one of {VALID_ENVS}")
    return env


CURRENT_ENV = _resolve_env(sys.argv[1:])

_env_file = BASE_DIR / f".env.{CURRENT_ENV}"
if _env_file.exists():
    load_dotenv(_env_file, override=True)
else:
    print(f"[WARN] {_env_file.name} not found -- falling back to .env for --env {CURRENT_ENV}", file=sys.stderr)
    load_dotenv(BASE_DIR / ".env", override=True)
