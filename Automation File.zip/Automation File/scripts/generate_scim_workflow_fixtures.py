"""Generates test-files/workflow/assign_requests_scim_full.xlsx and
unassign_requests_scim_full.xlsx -- one row per approved SATC id
(config/test_case_registry_scim.json) that belongs to that action, mirroring
scripts/generate_full_workflow_fixtures.py but for the SCIM app set.

None of the SCIM apps (test-files/bundle/scim bundles.csv) are present in
config/db-target-system.json, so unlike the base script, applicationId/requestableItem
are sourced straight from that CSV (Application Id / Bundle 1 / Bundle 2 columns) keyed by
app name, not from config/db-target-system.json. Each SCIM app has two known real bundle
names -- single-access test cases use Bundle 1, MULTIPLE-access test cases use
"Bundle 1;Bundle 2" (blocked test cases still get a TODO_COLLECTION_ID_* placeholder, same
convention as the base script).

Usage:
    python -m scripts.generate_scim_workflow_fixtures
"""

import csv
import json
from pathlib import Path

from openpyxl import Workbook

REGISTRY_PATH = Path("config/test_case_registry_scim.json")
BUNDLE_CSV_PATH = Path("test-files/bundle/scim bundles.csv")

ASSIGN_PATH = Path("test-files/workflow/assign_requests_scim_full.xlsx")
UNASSIGN_PATH = Path("test-files/workflow/unassign_requests_scim_full.xlsx")

ASSIGN_HEADER = [
    "user_email", "applicationId", "item_type", "requestableItem",
    "expirationTime", "timeZone", "referenceId", "comment", "test_case",
]
UNASSIGN_HEADER = [
    "user_email", "applicationId", "item_type", "requestableItem",
    "referenceId", "comment", "test_case",
]

SELF_USER = "Ranjan.Khadka@dellteam.com"
OTHER_USER = "sagar.shrestha@dellteam.com"

# The registry's app_name doesn't always match the CSV's Name column verbatim (e.g. registry
# "Boomi Corp(764416)" vs CSV "Boomi Corp") -- map registry app_name -> CSV app_name here.
REGISTRY_TO_CSV_APP_NAME = {
    "Boomi Corp(764416)": "Boomi Corp",
    "Boomi-PCI(455651)": "Boomi-PCI",
}


def _load_bundle_index() -> dict:
    """{app_name: {"app_id": ..., "bundle1": ..., "bundle2": ...}} from the SCIM bundles CSV."""
    index = {}
    with BUNDLE_CSV_PATH.open(newline="") as f:
        for row in csv.DictReader(f):
            name = row["Name"].strip()
            index[name] = {
                "app_id": row["Application Id"].strip(),
                "bundle1": row["Bundle 1"].strip(),
                "bundle2": row["Bundle 2"].strip(),
            }
    return index


def _bundles_for(entry: dict) -> str:
    multiple = "MULTIPLE" in entry["description"]
    return f"{entry['_bundle1']};{entry['_bundle2']}" if multiple else entry["_bundle1"]


def _classify_add_access(entry: dict) -> dict:
    if entry["execution"] == "blocked":
        return {"user_email": SELF_USER, "item_type": "collection",
                "requestable_item": f"TODO_COLLECTION_ID_{entry['_id']}", "expiration_time": ""}
    other_user = entry["blocked_reason"] is not None  # "for someone (another user)" variant
    return {
        "user_email": OTHER_USER if other_user else SELF_USER,
        "item_type": "bundle",
        "requestable_item": _bundles_for(entry),
        "expiration_time": "",
    }


def _classify_sunset_date(entry: dict) -> dict:
    present = "sunset_present" in entry["checks"]
    return {
        "user_email": SELF_USER,
        "item_type": "bundle",
        "requestable_item": _bundles_for(entry),
        "expiration_time": "2026-12-31T23:59:59.000Z" if present else "",
    }


def _classify_remove_access(entry: dict) -> dict:
    if entry["execution"] == "blocked":
        return {"user_email": SELF_USER, "item_type": "collection",
                "requestable_item": f"TODO_COLLECTION_ID_{entry['_id']}"}
    other_user = entry["blocked_reason"] is not None  # "for someone (another user)" variant
    return {
        "user_email": OTHER_USER if other_user else SELF_USER,
        "item_type": "bundle",
        "requestable_item": _bundles_for(entry),
    }


def _classify_add_remove(entry: dict) -> dict:
    if entry["execution"] == "blocked":
        return {"user_email": SELF_USER, "item_type": "collection",
                "requestable_item": f"TODO_COLLECTION_ID_{entry['_id']}", "expiration_time": ""}
    return {
        "user_email": SELF_USER,
        "item_type": "bundle",
        "requestable_item": _bundles_for(entry),
        "expiration_time": "",
    }


def _classify_servicenow_form(entry: dict) -> dict:
    return {"user_email": SELF_USER, "item_type": "collection",
            "requestable_item": f"TODO_COLLECTION_ID_{entry['_id']}"}


_ASSIGN_MODULES = {"Add Access": _classify_add_access, "Sunset Date": _classify_sunset_date, "Add/Remove": _classify_add_remove}
_UNASSIGN_MODULES = {
    "Remove Access": _classify_remove_access,
    "ServiceNow form (App Owner)": _classify_servicenow_form,
    "ServiceNow form": _classify_servicenow_form,
}


def _rows_for(modules: dict, bundle_index: dict, registry: dict) -> list:
    rows = []
    for atc_id, entry in sorted(registry.items(), key=lambda kv: kv[1]["order"]):
        classify = modules.get(entry["module"])
        if not classify:
            continue
        csv_app_name = REGISTRY_TO_CSV_APP_NAME.get(entry["app_name"], entry["app_name"])
        bundle_info = bundle_index.get(csv_app_name)
        if not bundle_info:
            raise SystemExit(f"No SCIM bundle configured for app '{entry['app_name']}' (test case {atc_id})")
        entry = {**entry, "_id": atc_id, "_bundle1": bundle_info["bundle1"], "_bundle2": bundle_info["bundle2"]}
        fields = classify(entry)
        rows.append({
            "user_email": fields["user_email"],
            "applicationId": bundle_info["app_id"],
            "item_type": fields["item_type"],
            "requestableItem": fields["requestable_item"],
            "expirationTime": fields.get("expiration_time", ""),
            "timeZone": "America/New_York" if fields.get("expiration_time") else "",
            "referenceId": f"RITM_{atc_id}",
            "comment": entry["description"][:120],
            "test_case": atc_id,
        })
    return rows


def _write_xlsx(path: Path, header: list, rows: list) -> None:
    wb = Workbook()
    ws = wb.active
    ws.append(header)
    for row in rows:
        ws.append([row.get(col, "") for col in header])
    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)


def main() -> None:
    registry = json.loads(REGISTRY_PATH.read_text())
    bundle_index = _load_bundle_index()

    assign_rows = _rows_for(_ASSIGN_MODULES, bundle_index, registry)
    unassign_rows = _rows_for(_UNASSIGN_MODULES, bundle_index, registry)

    _write_xlsx(ASSIGN_PATH, ASSIGN_HEADER, assign_rows)
    _write_xlsx(UNASSIGN_PATH, UNASSIGN_HEADER, unassign_rows)

    print(f"[INFO] Wrote {len(assign_rows)} row(s) to {ASSIGN_PATH}")
    print(f"[INFO] Wrote {len(unassign_rows)} row(s) to {UNASSIGN_PATH}")
    print("[INFO] Termination test cases are not included -- see test-files/termination/termination_requests.csv.")


if __name__ == "__main__":
    main()
