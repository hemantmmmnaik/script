#!/usr/bin/env python3
"""Apply an xlsx of grant/revoke rows directly against Okta, without the web UI.

Usage:
    python scripts/bulk_grant_cli.py path/to/rows.xlsx

The xlsx must have "appId", "entitlementValueName" (an entitlement value name or a bundle
name), and "userEmail" columns, plus an optional "action" column (add/grant, or
remove/revoke — defaults to add). Apps referenced by appId are loaded fresh from Okta; they
do not need to have been added via the UI first. A success/failure report is written to
data/reports/ on completion.
"""
import argparse
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import config.env_bootstrap  # noqa: F401,E402 -- must load the right .env before anything else imports app.settings

from app.services import bulk_grant_service, connectors_service, report_service  # noqa: E402


async def _load_connectors(app_ids: list, errors: list) -> dict:
    print(f"Loading {len(app_ids)} app(s) from Okta…")
    loaded = await connectors_service.batch_load(app_ids)
    connectors = {}
    for app_id, result in zip(app_ids, loaded):
        if result.get("status") != "loaded":
            errors.append(f"{app_id}: failed to load entitlements/bundles ({result.get('error')})")
        try:
            app_info = await connectors_service.get_app(app_id)
        except Exception as exc:
            app_info = {"id": app_id, "label": app_id}
            errors.append(f"{app_id}: failed to load app metadata ({exc})")
        connectors[app_id] = {**result, "app": app_info}
    return connectors


async def run(xlsx_path: Path) -> int:
    rows = bulk_grant_service.parse_rows(xlsx_path.read_bytes())
    if not rows:
        print("No valid rows found in xlsx (check required columns and non-empty cells).")
        return 1

    errors = []
    for row in rows:
        if row["action"] not in bulk_grant_service.ADD_ACTIONS and row["action"] not in bulk_grant_service.REMOVE_ACTIONS:
            errors.append(f"row {row['rowNum']}: unknown action \"{row['action']}\" — skipped")
    rows = [
        r for r in rows
        if r["action"] in bulk_grant_service.ADD_ACTIONS or r["action"] in bulk_grant_service.REMOVE_ACTIONS
    ]

    app_ids = sorted({r["appId"] for r in rows})
    connectors = await _load_connectors(app_ids, errors)

    actions, resolve_errors = await bulk_grant_service.resolve_rows_to_actions(rows, connectors)
    errors.extend(resolve_errors)

    if not actions:
        print("No actions resolved from the xlsx — nothing to run.")
        for err in errors:
            print(f"  - {err}")
        return 1

    print(f"Resolved {len(actions)} action(s) from {len(rows)} row(s). Executing against Okta…")
    results = await bulk_grant_service.execute_actions(actions, connectors)

    report_path = report_service.write_queue_report(results)
    succeeded = sum(1 for r in results if r["status"] == "success")
    failed = len(results) - succeeded

    print(f"Done. {succeeded} succeeded, {failed} failed.")
    if errors:
        print(f"{len(errors)} warning(s) during resolution:")
        for err in errors:
            print(f"  - {err}")
    print(f"Report saved to {report_path}")

    return 1 if failed or errors else 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("xlsx_path", type=Path, help="Path to the xlsx file of grant/revoke rows")
    parser.add_argument("--env", choices=["dev", "qa"], default="dev",
                         help="Environment to target (default: dev). Already applied by config.env_bootstrap.")
    args = parser.parse_args()
    assert args.env == config.env_bootstrap.CURRENT_ENV

    if not args.xlsx_path.exists():
        parser.error(f"file not found: {args.xlsx_path}")

    return asyncio.run(run(args.xlsx_path))


if __name__ == "__main__":
    sys.exit(main())
