"""Runs all three workflow test phases -- assign, unassign, then termination -- back to back in a
single command, and writes ONE combined set of reports (same format as run_workflow_tests.py /
run_termination_tests.py) covering every test case from all three phases.

This is purely an orchestrator: it reuses run_workflow_tests.run_all / run_termination_tests.run_all
unchanged, concatenates their WorkflowResult lists, and feeds that combined list through the same
lib/workflow_reporting.write_reports()/print_app_summary()/print_summary() used by the individual
scripts -- so report structure/format is identical, just with more rows.

Usage:
    python -m scripts.run_all_tests
    python -m scripts.run_all_tests --env qa
    python -m scripts.run_all_tests --assign-file test-files/workflow/assign_requests.xlsx \\
        --unassign-file test-files/workflow/unassign_requests.xlsx \\
        --termination-file test-files/termination/termination_requests.csv
"""

import config.env_bootstrap  # noqa: F401,E402 -- must load the right .env before anything else imports app.settings

import argparse
import asyncio
import sys
import time
from pathlib import Path

from lib.workflow_reporting import print_app_summary, print_summary, write_reports
from lib.workflow_runner import read_xlsx_rows
from scripts.run_termination_tests import read_termination_rows
from scripts.run_termination_tests import run_all as run_all_termination
from scripts.run_workflow_tests import run_all as run_all_workflow

DEFAULT_ASSIGN_FILE = "test-files/workflow/assign_requests.xlsx"
DEFAULT_UNASSIGN_FILE = "test-files/workflow/unassign_requests.xlsx"
DEFAULT_TERMINATION_FILE = "test-files/termination/termination_requests.csv"


async def run_all(assign_file: str, unassign_file: str, termination_file: str) -> list:
    combined = []

    print(f"[INFO] === Phase 1/3: assign -- {assign_file} ===")
    assign_rows = read_xlsx_rows(assign_file, "assign")
    print(f"[INFO] Loaded {len(assign_rows)} assign row(s).")
    combined.extend(await run_all_workflow(assign_rows))

    print(f"[INFO] === Phase 2/3: unassign -- {unassign_file} ===")
    unassign_rows = read_xlsx_rows(unassign_file, "unassign")
    print(f"[INFO] Loaded {len(unassign_rows)} unassign row(s).")
    combined.extend(await run_all_workflow(unassign_rows))

    print(f"[INFO] === Phase 3/3: termination -- {termination_file} ===")
    termination_rows = read_termination_rows(termination_file)
    print(f"[INFO] Loaded {len(termination_rows)} termination row(s).")
    combined.extend(await run_all_termination(termination_rows))

    return combined


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run assign, unassign, and termination test cases back to back and produce one combined report."
    )
    parser.add_argument("--assign-file", dest="assign_file", default=DEFAULT_ASSIGN_FILE,
                         help=f"Path to the assign xlsx file (default: {DEFAULT_ASSIGN_FILE}).")
    parser.add_argument("--unassign-file", dest="unassign_file", default=DEFAULT_UNASSIGN_FILE,
                         help=f"Path to the unassign xlsx file (default: {DEFAULT_UNASSIGN_FILE}).")
    parser.add_argument("--termination-file", dest="termination_file", default=DEFAULT_TERMINATION_FILE,
                         help=f"Path to the termination csv file (default: {DEFAULT_TERMINATION_FILE}).")
    parser.add_argument("--env", choices=["dev", "qa"], default="dev",
                         help="Environment to target (default: dev). Already applied by config.env_bootstrap.")
    args = parser.parse_args()
    assert args.env == config.env_bootstrap.CURRENT_ENV

    try:
        results = asyncio.run(run_all(args.assign_file, args.unassign_file, args.termination_file))
    except SystemExit:
        raise
    except Exception as exc:  # noqa: BLE001 - top-level guard so the CLI exits cleanly
        print(f"[FATAL] {exc}", file=sys.stderr)
        sys.exit(1)

    if not results:
        return

    timestamp = time.strftime("%Y%m%d_%H%M%S")
    app_summary_path, summary_path, detail_path, csv_path = write_reports(
        results, Path("reports"), generated_at=time.strftime("%Y-%m-%d %H:%M:%S"), timestamp=timestamp
    )
    print_app_summary(results)
    print_summary(results)
    print(f"[INFO] App summary report: {app_summary_path}")
    print(f"[INFO] Summary report:     {summary_path}")
    print(f"[INFO] Detail report:      {detail_path}")
    print(f"[INFO] CSV report:         {csv_path}")


if __name__ == "__main__":
    main()
