"""Test 13 -- deactivates each user in test-files/termination/termination_requests.csv and
verifies Okta grants (and, where known, target-system access) are revoked across every app in
config/test_mapping.py. Produces the same WorkflowResult shape as run_workflow_tests.py so it
feeds the existing app-differentiated reporting (lib/workflow_reporting.py).

Usage:
    python -m scripts.run_termination_tests
    python -m scripts.run_termination_tests --env qa

Warning: this actually deactivates the listed Okta users, via the termination Workflows invoke
webhook (POST {"employeeID": ...} -- see app/services/workflow_service.py). Only point
termination_requests.csv at disposable test users.
"""

import config.env_bootstrap  # noqa: F401,E402 -- must load the right .env before anything else imports app.settings

import argparse
import asyncio
import csv
import sys
import time
from pathlib import Path

from lib import test_case_registry
from lib.grant_runner import fetch_app_name, fetch_users_by_email
from lib.termination_runner import app_result, target_system_result, verify_termination_revokes_access
from lib.test_catalog import apps_in_scope
from lib.workflow_reporting import print_app_summary, print_summary, write_reports
from lib.workflow_runner import WorkflowResult

TEST_FILE = "test-files/termination/termination_requests.csv"


def _termination_ids_for_app(app_id: str) -> tuple:
    """Returns (app_atc_id, target_system_atc_id) -- the two approved ids
    config/test_case_registry.json defines for this app's Termination module (checks
    "termination_app" / "termination_target_system"), or (None, None) if this app has neither
    (e.g. Extended Partner Network, which has no approved test cases at all)."""
    app_atc_id = target_system_atc_id = None
    for tc_id in test_case_registry.ids_for_app(app_id):
        entry = test_case_registry.get(tc_id)
        if "termination_app" in entry["checks"]:
            app_atc_id = tc_id
        elif "termination_target_system" in entry["checks"]:
            target_system_atc_id = tc_id
    return app_atc_id, target_system_atc_id


def read_termination_rows(file_path: str) -> list:
    """Returns a list of (email, employee_id) tuples. employeeID is the payload the termination
    Workflows invoke webhook expects (see lib/termination_runner.py); user_email is only used
    afterward, to resolve the Okta user for grant/target-system verification."""
    path = Path(file_path)
    if not path.exists():
        raise SystemExit(f"Test file not found: {file_path}")
    with path.open(newline="", encoding="utf-8-sig") as fh:
        reader = csv.DictReader(fh)
        headers = {h.strip() for h in reader.fieldnames} if reader.fieldnames else set()
        if not {"user_email", "employeeID"} <= headers:
            raise SystemExit(f"{file_path} must have user_email and employeeID columns. Found: {reader.fieldnames}")
        rows = [((row.get("user_email") or "").strip(), (row.get("employeeID") or "").strip()) for row in reader]
    rows = [(email, employee_id) for email, employee_id in rows if email and employee_id]
    if not rows:
        raise SystemExit(f"No user_email/employeeID rows found in {file_path} -- nothing to process.")
    return rows


def _result(email: str, app_id: str, app_name: str, test_case_id: str, status: str, reason: str) -> WorkflowResult:
    return WorkflowResult(
        action="deactivate", user_email=email, application_id=app_id, item_type="termination",
        requestable_item="", requestable_item_id="", entitlement_id="", reference_id="",
        app_name=app_name, test_case_id=test_case_id, overall_status=status, failure_reason=reason,
    )


async def run_all(rows: list) -> list:
    app_ids = apps_in_scope()
    app_names = {app_id: await fetch_app_name(app_id) for app_id in app_ids}
    termination_ids = {app_id: _termination_ids_for_app(app_id) for app_id in app_ids}

    emails = [email for email, _ in rows]
    print(f"[INFO] Resolving {len(set(e.lower() for e in emails))} unique user(s) via Okta search...")
    users_by_email = await fetch_users_by_email(emails)

    def _emit(email: str, app_id: str, status: str, reason: str) -> list:
        app_atc_id, target_system_atc_id = termination_ids[app_id]
        results = []
        for tc_id in (app_atc_id, target_system_atc_id):
            if tc_id:
                results.append(_result(email, app_id, app_names.get(app_id, ""), tc_id, status, reason))
        return results

    results = []
    for email, employee_id in rows:
        user = users_by_email.get(email.strip().lower())
        if not user:
            for app_id in app_ids:
                results.extend(_emit(email, app_id, "FAILED", "User not found in Okta for this email"))
            continue

        user_id = user["id"]
        user_login = (user.get("profile", {}) or {}).get("login") or email
        print(f"[INFO] Deactivating {email} (employeeID {employee_id}) and verifying access revocation across {len(app_ids)} app(s)...")
        termination = await verify_termination_revokes_access(user_id, user_login, employee_id, app_ids=app_ids)

        if not termination["deactivated"]:
            for app_id in app_ids:
                results.extend(_emit(email, app_id, "FAILED", termination["reason"]))
            continue

        for app_id in app_ids:
            detail = termination["per_app"][app_id]
            app_atc_id, target_system_atc_id = termination_ids[app_id]
            if app_atc_id:
                status, reason = app_result(detail)
                results.append(_result(email, app_id, app_names.get(app_id, ""), app_atc_id, status, reason))
            if target_system_atc_id:
                status, reason = target_system_result(detail)
                results.append(_result(email, app_id, app_names.get(app_id, ""), target_system_atc_id, status, reason))

    return results


def main() -> None:
    parser = argparse.ArgumentParser(description="Run user termination test cases (Termination module, per config/test_case_registry.json).")
    parser.add_argument("--env", choices=["dev", "qa"], default="dev",
                         help="Environment to target (default: dev). Already applied by config.env_bootstrap.")
    args = parser.parse_args()
    assert args.env == config.env_bootstrap.CURRENT_ENV

    rows = read_termination_rows(TEST_FILE)
    try:
        results = asyncio.run(run_all(rows))
    except SystemExit:
        raise
    except Exception as exc:  # noqa: BLE001 - top-level guard so the CLI exits cleanly
        print(f"[FATAL] {exc}", file=sys.stderr)
        sys.exit(1)

    if not results:
        return

    timestamp = time.strftime("%Y%m%d_%H%M%S")
    app_summary_path, summary_path, detail_path, csv_path = write_reports(
        results, Path("reports"), generated_at=time.strftime("%Y-%m-%d %H:%M:%S"), timestamp=timestamp
    )
    print_app_summary(results)
    print_summary(results)
    print(f"[INFO] App summary report: {app_summary_path}")
    print(f"[INFO] Summary report:     {summary_path}")
    print(f"[INFO] Detail report:      {detail_path}")
    print(f"[INFO] CSV report:         {csv_path}")


if __name__ == "__main__":
    main()
