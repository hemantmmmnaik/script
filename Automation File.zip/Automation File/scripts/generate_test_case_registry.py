"""Generates config/test_case_registry.json from the approved spec
"JDBC Application_Onboarding_Test_Cases approved.xlsx" (sheet "Automation").

This is a one-time / rerunnable generator, not something the test runners import or execute at
run time -- if the approved spreadsheet is revised (a test case added/reworded), rerun this
script to regenerate config/test_case_registry.json, then re-review the diff. lib/test_case_registry.py
is what the runners actually read from at run time.

Classification is pattern-based: the 158 rows in the spec reduce to 14 distinct
(Functionality Module, Test Case Description) pairs, reused verbatim across every app -- see
_PATTERNS below. Each pattern maps to an "execution" mode and a list of "checks" the runners
already know how to perform (see lib/workflow_runner.py, lib/termination_runner.py). Rows whose
module/description doesn't match a known pattern are classified "execution": "unknown" so they
show up loudly instead of being silently miscategorized.

Usage:
    python -m scripts.generate_test_case_registry
"""

import json
import sys
from pathlib import Path

from openpyxl import load_workbook

SPEC_PATH = Path("JDBC Application_Onboarding_Test_Cases approved.xlsx")
OUTPUT_PATH = Path("config/db-target-system.json").parent / "test_case_registry.json"
SHEET_NAME = "Automation"

# Maps the spec's free-text "Application Name (Target App)" to the exact `name` field used in
# config/db-target-system.json (see config/apps.py) -- the two are hand-typed independently and
# drift in punctuation/casing/abbreviation, so this is a small explicit table, not a fuzzy match.
APP_NAME_ALIASES = {
    "CSTool (CIS)": "CSTool (CIS)",
    "CLM": "CLM",
    "CDMassive": "CDMassive",
    "Brazil Tax Engine": "Brazil Tax Engine",
    "GAFT": "GAFT",
    "Digital Licensing and Fulfillment (DLF)": "Digital Licensing & Fulfillment (DLF)",
    "FIMS EMEA": "FIMS EMEA",
    "Novus": "NOVUS",
    "Solve Engine Employ User": "Solve Engine",
    "Vendor Inquiry Portal(VIP)": "Vendor Inquiry portal (VIP)",
    "Automatic Remote Access": "Automatic Remote Access (ARA)",
}

# (module, description) -> (execution, checks, blocked_reason). Descriptions are matched exactly
# (after strip()) against the spec's current wording -- see the docstring above.
_PATTERNS = {
    ("Add Access", "Verify that a user can add access for themselves from ServiceNow for a SINGLE access."):
        ("assign", ["target_system"], None),
    ("Add Access", "Verify that a user can add access for themselves from ServiceNow for MULTIPLE accesses."):
        ("assign", ["target_system"], None),
    ("Add Access", "Verify that a user can add access for someone (another user) from ServiceNow for a SINGLE access."):
        ("assign", ["target_system"], "No ServiceNow integration -- requests must be originated manually via the Workflows webhook today"),
    ("Add Access", "Verify that a user can add access for someone (another user) from ServiceNow for MULTIPLE accesses."):
        ("assign", ["target_system"], "No ServiceNow integration -- requests must be originated manually via the Workflows webhook today"),
    ("Sunset Date", "Verify that the selected \"Set Access Expiration Date\" (sunset date) is included in the payload from the ServiceNow request ONLY if selected in the form."):
        ("assign", ["sunset_present"], None),
    ("Sunset Date", "Verify that the sunset date is NOT included in the payload if \"Set Access Expiration Date\" is not selected."):
        ("assign", ["sunset_absent"], None),
    ("Remove Access", "Verify the selected single access is removed for themselves in the Target App once the SNOW request is approved."):
        ("unassign", ["target_system"], None),
    ("Remove Access", "Verify the selected single access is removed for someone (another user) in the Target App once the SNOW request is approved."):
        ("unassign", ["target_system"], "No ServiceNow integration -- requests must be originated manually via the Workflows webhook today"),
    ("Remove Access", "Verify the user's access is removed automatically when the sunset (expiration) date is reached."):
        ("blocked", [], "No expiration watcher or mocking strategy implemented -- needs a design decision"),
    ("Add Access", "If an account for the requestor does not exist, create an account in the Target App once the access-addition request arrives in Okta."):
        ("blocked", [], "create_user procedure exists in config/db-target-system.json but no runner path calls or verifies it"),
    ("Add/Remove", "Verify the add/remove transactions from ServiceNow are logged in Okta and sent to Splunk."):
        ("blocked", [], "No ServiceNow or Splunk integration"),
    ("Add/Remove", "Verify the Okta service account is displayed as the actor for add/revoke transactions in the logs."):
        ("assign", ["audit_log"], None),
    ("Termination", "Verify that when a user is terminated, all accesses are removed in the Target App."):
        ("termination", ["termination_app"], None),
    ("Termination", "Verify that when all accesses are removed for a user, they are also removed from the Target System once the user is deactivated."):
        ("termination", ["termination_target_system"], None),
    ("ServiceNow form (App Owner)", "Verify that an application owner can remove access for users in their application from the ServiceNow form."):
        ("blocked", [], "No ServiceNow integration"),
}


def _resolve_app_name(raw_name: str) -> str:
    resolved = APP_NAME_ALIASES.get(raw_name.strip())
    if not resolved:
        raise SystemExit(f"No alias mapping for app name '{raw_name}' -- add it to APP_NAME_ALIASES")
    return resolved


def _classify(module: str, description: str) -> tuple:
    key = (module.strip(), description.strip())
    match = _PATTERNS.get(key)
    if not match:
        return "unknown", [], f"Unrecognized (module, description) pair -- add to _PATTERNS: {key!r}"
    return match


def generate() -> dict:
    if not SPEC_PATH.exists():
        raise SystemExit(f"Spec file not found: {SPEC_PATH}")

    wb = load_workbook(SPEC_PATH, read_only=True, data_only=True)
    ws = wb[SHEET_NAME]
    rows_iter = ws.iter_rows(values_only=True)
    next(rows_iter)  # blank spacer row
    header = [str(h).strip() if h is not None else "" for h in next(rows_iter)]
    col = {name: header.index(name) for name in
           ("TC #", "Application Name (Target App)", "Functionality Module", "Test Case Description", "Expected Result")}

    registry = {}
    order = 0
    for raw_row in rows_iter:
        if raw_row is None or not raw_row[col["TC #"]]:
            continue
        tc_id = str(raw_row[col["TC #"]]).strip()
        app_name_raw = str(raw_row[col["Application Name (Target App)"]] or "").strip()
        module = str(raw_row[col["Functionality Module"]] or "").strip()
        description = str(raw_row[col["Test Case Description"]] or "").strip()
        expected_result = str(raw_row[col["Expected Result"]] or "").strip()

        if tc_id in registry:
            raise SystemExit(f"Duplicate TC id in spec: {tc_id}")

        app_name = _resolve_app_name(app_name_raw)
        execution, checks, blocked_reason = _classify(module, description)

        registry[tc_id] = {
            "order": order,
            "app_name": app_name,
            "module": module,
            "description": description,
            "expected_result": expected_result,
            "execution": execution,
            "checks": checks,
            "blocked_reason": blocked_reason,
        }
        order += 1
    wb.close()

    if not registry:
        raise SystemExit("No rows found in spec -- nothing generated.")
    return registry


def main() -> None:
    registry = generate()
    unknown = [tc_id for tc_id, entry in registry.items() if entry["execution"] == "unknown"]
    if unknown:
        print(f"[WARN] {len(unknown)} test case(s) with unrecognized module/description: {unknown}", file=sys.stderr)

    OUTPUT_PATH.write_text(json.dumps(registry, indent=2) + "\n", encoding="utf-8")
    print(f"[INFO] Wrote {len(registry)} test case(s) to {OUTPUT_PATH}")


if __name__ == "__main__":
    main()
