"""Root test runner: executes bundle and/or entitlement grant test cases across every app_id
configured in config/test_mapping.py, verifying both the Okta grant and the downstream
target-system access for each row, and writes summary + per-app reports to reports/.

Usage:
    python run_tests.py                # run everything (bundle + entitlement, all apps)
    python run_tests.py bundle         # run only bundle test files, all apps
    python run_tests.py entitlement    # run only entitlement test files, all apps
"""

import config.env_bootstrap  # noqa: F401,E402 -- must load the right .env before anything else imports app.settings

import argparse
import asyncio
import sys
import time
from pathlib import Path

from app.concurrency import run_limited
from config.apps import get_test_mapping
from lib.grant_runner import (
    TestJob,
    fetch_app_name,
    fetch_bundles_by_name,
    fetch_entitlement_value_index,
    fetch_users_by_email,
    process_bundle_row,
    process_entitlement_row,
    read_bundle_csv,
    read_entitlement_csv,
)
from lib.reporting import print_summary, write_reports


def collect_jobs(mapping: dict, target: str = None) -> list:
    jobs = []
    for app_id, cfg in mapping.items():
        connector_type = cfg.get("connector_type", "UNKNOWN")
        if target in (None, "bundle"):
            for file_path in cfg.get("bundle_files", []):
                jobs.append(TestJob(app_id=app_id, connector_type=connector_type, test_type="bundle", source_file=file_path))
        if target in (None, "entitlement"):
            for file_path in cfg.get("entitlement_files", []):
                jobs.append(TestJob(app_id=app_id, connector_type=connector_type, test_type="entitlement", source_file=file_path))
    return jobs


async def run_all(jobs: list) -> list:
    if not jobs:
        print("[WARN] No test files mapped for the selected target -- nothing to run.")
        return []

    # Resolve each app's display name once (shared across all its jobs) so reports can show the
    # app name instead of the raw app_id.
    app_names = {}
    for job in jobs:
        if job.app_id not in app_names:
            app_names[job.app_id] = await fetch_app_name(job.app_id)
        job.app_name = app_names[job.app_id]

    # Parse every CSV up front so we can batch-resolve all unique emails in one pass.
    job_rows = []  # list of (job, rows)
    all_emails = []
    for job in jobs:
        print(f"[INFO] Loading {job.test_type} test file for app {job.app_id}: {job.source_file}")
        rows = read_bundle_csv(job.source_file) if job.test_type == "bundle" else read_entitlement_csv(job.source_file)
        job_rows.append((job, rows))
        all_emails.extend(r.email for r in rows)

    print(f"[INFO] Resolving {len(set(e.lower() for e in all_emails))} unique user(s) via Okta search...")
    users_by_email = await fetch_users_by_email(all_emails)
    print(f"[INFO] Resolved {len(users_by_email)} user(s).")

    # Pre-fetch bundles/entitlement value index once per app_id (shared across that app's rows).
    bundles_cache, value_index_cache = {}, {}
    for job, _rows in job_rows:
        if job.test_type == "bundle" and job.app_id not in bundles_cache:
            print(f"[INFO] Fetching bundles for app {job.app_id}...")
            bundles_cache[job.app_id] = await fetch_bundles_by_name(job.app_id)
        if job.test_type == "entitlement" and job.app_id not in value_index_cache:
            print(f"[INFO] Fetching entitlement schemas for app {job.app_id}...")
            value_index_cache[job.app_id] = await fetch_entitlement_value_index(job.app_id)

    tasks = []
    for job, rows in job_rows:
        for row in rows:
            if job.test_type == "bundle":
                tasks.append(lambda job=job, row=row: process_bundle_row(job, row, users_by_email, bundles_cache[job.app_id]))
            else:
                tasks.append(lambda job=job, row=row: process_entitlement_row(job, row, users_by_email, value_index_cache[job.app_id]))

    print(f"[INFO] Running {len(tasks)} test case(s) with concurrency=5...")
    return await run_limited(tasks, limit=5)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run bundle and/or entitlement grant test cases across configured apps.")
    parser.add_argument("target", nargs="?", choices=["bundle", "entitlement"], default=None,
                         help="Run only bundle or only entitlement test files; omit to run both.")
    parser.add_argument("--target", dest="target_flag", choices=["bundle", "entitlement"], default=None,
                         help="Same as the positional 'target' argument.")
    parser.add_argument("--env", choices=["dev", "qa"], default="dev",
                         help="Environment to target (default: dev). Already applied by config.env_bootstrap.")
    args = parser.parse_args()
    assert args.env == config.env_bootstrap.CURRENT_ENV
    target = args.target_flag or args.target

    jobs = collect_jobs(get_test_mapping(), target)

    try:
        results = asyncio.run(run_all(jobs))
    except SystemExit:
        raise
    except Exception as exc:  # noqa: BLE001 - top-level guard so the CLI exits cleanly
        print(f"[FATAL] {exc}", file=sys.stderr)
        sys.exit(1)

    if not results:
        return

    timestamp = time.strftime("%Y%m%d_%H%M%S")
    summary_path, detail_path, csv_path = write_reports(
        results, Path("reports"), generated_at=time.strftime("%Y-%m-%d %H:%M:%S"), timestamp=timestamp
    )
    print_summary(results)
    print(f"[INFO] Summary report:  {summary_path}")
    print(f"[INFO] Detail report:   {detail_path}")
    print(f"[INFO] CSV report:      {csv_path}")


if __name__ == "__main__":
    main()
