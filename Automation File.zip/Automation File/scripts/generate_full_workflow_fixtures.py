"""Generates test-files/workflow/assign_requests_full.xlsx and unassign_requests_full.xlsx --
one row per approved ATC id (config/test_case_registry.json) that belongs to that action, so every
non-termination test case in the approved spec has a runnable/blocked row instead of just the
hand-picked subset in assign_requests.xlsx/unassign_requests.xlsx (which are left untouched).

Only CSTool (CIS) and CDMassive have known real bundle/entitlement names in this repo (used
elsewhere in test-files/) -- every other app gets an obvious TODO_* placeholder requestableItem
that a tester must replace with a real name before that row can pass live. Blocked test cases
(execution == "blocked") get a "collection" placeholder row instead, since process_row_group
short-circuits them to BLOCKED before ever resolving/invoking anything -- no real name is needed.

applicationId is written explicitly as the current env's (dev) app_id for readability/review, even
though lib.workflow_runner.read_xlsx_rows would auto-derive the same value from the test_case tag
alone. Termination test cases are intentionally NOT included here -- see
scripts/run_termination_tests.py / test-files/termination/termination_requests.csv, which already
auto-covers every app's two termination ids per disposable test user row, no per-row tagging
needed or possible.

Usage:
    python -m scripts.generate_full_workflow_fixtures
"""

import json
from pathlib import Path

from openpyxl import Workbook

REGISTRY_PATH = Path("config/test_case_registry.json")
DB_TARGET_SYSTEM_PATH = Path("config/db-target-system.json")
ENV = "dev"

ASSIGN_PATH = Path("test-files/workflow/assign_requests_full.xlsx")
UNASSIGN_PATH = Path("test-files/workflow/unassign_requests_full.xlsx")

ASSIGN_HEADER = [
    "user_email", "applicationId", "item_type", "requestableItem",
    "expirationTime", "timeZone", "referenceId", "comment", "test_case",
]
UNASSIGN_HEADER = [
    "user_email", "applicationId", "item_type", "requestableItem",
    "referenceId", "comment", "test_case",
]

SELF_USER = "Ranjan.Khadka@dellteam.com"
OTHER_USER = "sagar.shrestha@dellteam.com"

# Only apps this repo already has real bundle/entitlement names for (see
# test-files/bundle/*.csv, test-files/entitlement/*.csv, and the hand-tagged
# assign_requests.xlsx/unassign_requests.xlsx). Every other app gets a TODO placeholder.
KNOWN_ITEMS = {
    "CSTool (CIS)": {"single": "WRITE_USER", "multi": ["WRITE_USER", "READ_ONLY"]},
    "CDMassive": {"single": "23", "multi": ["23", "36"]},
}


def _items_for(app_name: str, multiple: bool) -> str:
    known = KNOWN_ITEMS.get(app_name)
    if known:
        return ";".join(known["multi"]) if multiple else known["single"]
    return "TODO_ENTITLEMENT_VALUE_1;TODO_ENTITLEMENT_VALUE_2" if multiple else "TODO_ENTITLEMENT_VALUE"


def _classify_add_access(entry: dict) -> dict:
    multiple = "MULTIPLE" in entry["description"]
    if entry["execution"] == "blocked":
        return {"user_email": SELF_USER, "item_type": "collection",
                "requestable_item": f"TODO_COLLECTION_ID_{entry['_id']}", "expiration_time": ""}
    other_user = entry["blocked_reason"] is not None  # "for someone (another user)" variant
    return {
        "user_email": OTHER_USER if other_user else SELF_USER,
        "item_type": "entitlement",
        "requestable_item": _items_for(entry["app_name"], multiple),
        "expiration_time": "",
    }


def _classify_sunset_date(entry: dict) -> dict:
    present = "sunset_present" in entry["checks"]
    return {
        "user_email": SELF_USER,
        "item_type": "entitlement",
        "requestable_item": _items_for(entry["app_name"], multiple=False),
        "expiration_time": "2026-12-31T23:59:59.000Z" if present else "",
    }


def _classify_remove_access(entry: dict) -> dict:
    if entry["execution"] == "blocked":
        return {"user_email": SELF_USER, "item_type": "collection",
                "requestable_item": f"TODO_COLLECTION_ID_{entry['_id']}"}
    other_user = entry["blocked_reason"] is not None  # "for someone (another user)" variant
    return {
        "user_email": OTHER_USER if other_user else SELF_USER,
        "item_type": "entitlement",
        "requestable_item": _items_for(entry["app_name"], multiple=False),
    }


def _classify_add_remove(entry: dict) -> dict:
    if entry["execution"] == "blocked":
        return {"user_email": SELF_USER, "item_type": "collection",
                "requestable_item": f"TODO_COLLECTION_ID_{entry['_id']}", "expiration_time": ""}
    return {
        "user_email": SELF_USER,
        "item_type": "entitlement",
        "requestable_item": _items_for(entry["app_name"], multiple=False),
        "expiration_time": "",
    }


def _classify_servicenow_form(entry: dict) -> dict:
    return {"user_email": SELF_USER, "item_type": "collection",
            "requestable_item": f"TODO_COLLECTION_ID_{entry['_id']}"}


_ASSIGN_MODULES = {"Add Access": _classify_add_access, "Sunset Date": _classify_sunset_date, "Add/Remove": _classify_add_remove}
_UNASSIGN_MODULES = {"Remove Access": _classify_remove_access, "ServiceNow form (App Owner)": _classify_servicenow_form}


def _rows_for(modules: dict, name_to_id: dict, registry: dict) -> list:
    rows = []
    for atc_id, entry in sorted(registry.items(), key=lambda kv: kv[1]["order"]):
        classify = modules.get(entry["module"])
        if not classify:
            continue
        entry = {**entry, "_id": atc_id}
        fields = classify(entry)
        app_id = name_to_id.get(entry["app_name"])
        if not app_id:
            raise SystemExit(f"No {ENV} app_id configured for app '{entry['app_name']}' (test case {atc_id})")
        rows.append({
            "user_email": fields["user_email"],
            "applicationId": app_id,
            "item_type": fields["item_type"],
            "requestableItem": fields["requestable_item"],
            "expirationTime": fields.get("expiration_time", ""),
            "timeZone": "America/New_York" if fields.get("expiration_time") else "",
            "referenceId": f"RITM_{atc_id}",
            "comment": entry["description"][:120],
            "test_case": atc_id,
        })
    return rows


def _write_xlsx(path: Path, header: list, rows: list) -> None:
    wb = Workbook()
    ws = wb.active
    ws.append(header)
    for row in rows:
        ws.append([row.get(col, "") for col in header])
    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)


def main() -> None:
    registry = json.loads(REGISTRY_PATH.read_text())
    apps = json.loads(DB_TARGET_SYSTEM_PATH.read_text())[ENV]
    name_to_id = {cfg["name"]: app_id for app_id, cfg in apps.items()}

    assign_rows = _rows_for(_ASSIGN_MODULES, name_to_id, registry)
    unassign_rows = _rows_for(_UNASSIGN_MODULES, name_to_id, registry)

    _write_xlsx(ASSIGN_PATH, ASSIGN_HEADER, assign_rows)
    _write_xlsx(UNASSIGN_PATH, UNASSIGN_HEADER, unassign_rows)

    print(f"[INFO] Wrote {len(assign_rows)} row(s) to {ASSIGN_PATH}")
    print(f"[INFO] Wrote {len(unassign_rows)} row(s) to {UNASSIGN_PATH}")
    print("[INFO] Termination test cases are not included -- see test-files/termination/termination_requests.csv "
          "(every app's two termination ids are auto-covered per disposable test user row already).")


if __name__ == "__main__":
    main()
