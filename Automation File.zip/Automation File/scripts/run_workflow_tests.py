"""Workflow Access-Request test runner: invokes the Okta Workflows assign/unassign webhook for
each row of a test-files/workflow/*.xlsx file, waits ~10-15s for the change to propagate, then
verifies the downstream target system, and writes summary/detail/csv reports to reports/.

Usage:
    python scripts/run_workflow_tests.py assign
    python scripts/run_workflow_tests.py unassign
    python scripts/run_workflow_tests.py assign --file test-files/workflow/assign_requests.xlsx
"""

import config.env_bootstrap  # noqa: F401,E402 -- must load the right .env before anything else imports app.settings

import argparse
import asyncio
import sys
import time
from pathlib import Path

from app.concurrency import run_limited
from lib.grant_runner import fetch_app_name
from lib.workflow_reporting import print_app_summary, print_summary, write_reports
from lib.workflow_runner import group_resolved_by_row, process_row_group, read_xlsx_rows, resolve_rows

DEFAULT_FILE = "test-files/workflow/{action}_requests_scim_full.xlsx"


async def run_all(rows: list) -> list:
    if not rows:
        print("[WARN] No rows to run.")
        return []

    app_ids = sorted({r.application_id for r in rows if r.application_id})
    app_names = {}
    for app_id in app_ids:
        app_names[app_id] = await fetch_app_name(app_id)

    resolved_rows = await resolve_rows(rows)
    for resolved in resolved_rows:
        if resolved.error:
            print(f"[WARN] {resolved.row.action}:{resolved.row.line_no} ({resolved.row.user_email}): {resolved.error}")

    groups = group_resolved_by_row(resolved_rows)
    tasks = [(lambda group=group: process_row_group(group, app_names)) for group in groups]
    print(f"[INFO] Running {len(tasks)} workflow row(s) with concurrency=5...")
    per_row_results = await run_limited(tasks, limit=5)
    # process_row_group returns a list per row (one WorkflowResult per test_case_id tagged on that
    # row, or a single untagged result) -- flatten so callers keep seeing one flat list of results.
    return [result for row_results in per_row_results for result in row_results]


def main() -> None:
    parser = argparse.ArgumentParser(description="Run Okta Workflows Access-Request assign/unassign test cases.")
    parser.add_argument("action", nargs="?", choices=["assign", "unassign"], default=None,
                         help="Which workflow to invoke.")
    parser.add_argument("--action", dest="action_flag", choices=["assign", "unassign"], default=None,
                         help="Same as the positional 'action' argument.")
    parser.add_argument("--file", dest="file_path", default=None,
                         help="Override the default test-files/workflow/{action}_requests.xlsx path.")
    parser.add_argument("--env", choices=["dev", "qa"], default="dev",
                         help="Environment to target (default: dev). Already applied by config.env_bootstrap.")
    args = parser.parse_args()
    assert args.env == config.env_bootstrap.CURRENT_ENV
    action = args.action_flag or args.action
    if not action:
        parser.error("an action is required: assign | unassign")

    file_path = args.file_path or DEFAULT_FILE.format(action=action)

    print(f"[INFO] Loading {action} test file: {file_path}")
    rows = read_xlsx_rows(file_path, action)
    print(f"[INFO] Loaded {len(rows)} row(s).")

    try:
        results = asyncio.run(run_all(rows))
    except SystemExit:
        raise
    except Exception as exc:  # noqa: BLE001 - top-level guard so the CLI exits cleanly
        print(f"[FATAL] {exc}", file=sys.stderr)
        sys.exit(1)

    if not results:
        return

    timestamp = time.strftime("%Y%m%d_%H%M%S")
    app_summary_path, summary_path, detail_path, csv_path = write_reports(
        results, Path("reports"), generated_at=time.strftime("%Y-%m-%d %H:%M:%S"), timestamp=timestamp
    )
    print_app_summary(results)
    print_summary(results)
    print(f"[INFO] App summary report: {app_summary_path}")
    print(f"[INFO] Summary report:     {summary_path}")
    print(f"[INFO] Detail report:      {detail_path}")
    print(f"[INFO] CSV report:         {csv_path}")


if __name__ == "__main__":
    main()
