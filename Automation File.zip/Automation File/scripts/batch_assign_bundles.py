"""Batch-assign Okta entitlement bundles to users from a CSV, then verify the grant
in Okta and the downstream target system, replacing the manual assign-and-verify workflow.

Reuses this app's existing service layer (app.services.*) exactly the way the interactive
UI does it (see app/ui/actions.py::_execute_one and app/services/entitlements_service.py::
create_grant) -- i.e. it POSTs an ENTITLEMENT-BUNDLE grant directly, without first checking
or requiring Okta app assignment, matching the app's actual behavior.

It does NOT import app.ui.actions or app.ui.state, since both depend on nicegui's
per-session `app.storage.user`, which only exists inside a running NiceGUI request. This
script calls app.services.* directly, which only depend on app.settings (.env) + app.m2m
(module-level token cache) and are safe to use standalone.

Usage:
    python -m scripts.batch_assign_bundles --app-id 0oaXXXXXXXXXXXX --file-path users.csv

CSV format:
    user_email,bundles
    jane@example.com,Bundle_A;Bundle_B
    john@example.com,Bundle_C
"""

import config.env_bootstrap  # noqa: F401,E402 -- must load the right .env before anything else imports app.settings

import argparse
import asyncio
import csv
import sys
import textwrap
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Optional
from urllib.parse import quote

import httpx

# Importing any app.services module triggers app.settings' module-level load_dotenv(),
# so .env is loaded automatically -- no extra setup needed.
from app.concurrency import run_limited
from app.okta_client import OktaApiError, api_base, expect_list, m2m_headers, raise_for_okta_error
from app.services import connectors_service, entitlements_service, target_systems_service

REQUIRED_COLUMNS = {"user_email", "bundles"}
USER_SEARCH_BATCH_SIZE = 20  # Okta recommends keeping OR'd filter clauses small; 15-20 is a safe ceiling.
USER_PROCESSING_CONCURRENCY = 5  # matches this app's existing run_limited(..., limit=5) convention
MAX_RETRIES = 4
INITIAL_BACKOFF_SECONDS = 1.0


# --------------------------------------------------------------------------------------
# Data model
# --------------------------------------------------------------------------------------

@dataclass
class InputRow:
    line_no: int
    email: str
    bundle_names: list


@dataclass
class RowResult:
    user_email: str
    requested_bundles: str
    okta_status: str = "FAILED"
    target_system_status: str = "SKIPPED"
    overall_status: str = "FAILED"
    failure_reason: str = ""


# --------------------------------------------------------------------------------------
# CSV input handling
# --------------------------------------------------------------------------------------

def read_input_csv(file_path: str) -> list:
    path = Path(file_path)
    if not path.exists():
        raise SystemExit(f"Input file not found: {file_path}")
    if not path.is_file():
        raise SystemExit(f"Input path is not a file: {file_path}")

    try:
        with path.open(newline="", encoding="utf-8-sig") as fh:
            reader = csv.DictReader(fh)
            if reader.fieldnames is None:
                raise SystemExit("Input CSV is empty (no header row found).")
            header = {h.strip() for h in reader.fieldnames}
            missing = REQUIRED_COLUMNS - header
            if missing:
                raise SystemExit(
                    f"Input CSV is missing required column(s): {', '.join(sorted(missing))}. "
                    f"Found columns: {', '.join(reader.fieldnames)}"
                )

            rows = []
            for line_no, raw_row in enumerate(reader, start=2):  # header is line 1
                email = (raw_row.get("user_email") or "").strip()
                bundles_raw = (raw_row.get("bundles") or "").strip()
                if not email:
                    print(f"[WARN] Skipping line {line_no}: missing user_email")
                    continue
                bundle_names = [b.strip() for b in bundles_raw.split(";") if b.strip()]
                if not bundle_names:
                    print(f"[WARN] Skipping line {line_no} ({email}): no bundles listed")
                    continue
                rows.append(InputRow(line_no=line_no, email=email, bundle_names=bundle_names))
    except csv.Error as exc:
        raise SystemExit(f"Failed to parse CSV ({file_path}): {exc}")

    if not rows:
        raise SystemExit("No valid rows found in input CSV -- nothing to process.")
    return rows


# --------------------------------------------------------------------------------------
# Retry helper (handles Okta 429 rate limiting and transient 5xx errors)
# --------------------------------------------------------------------------------------

async def call_with_retry(coro_fn, *args, **kwargs):
    """Runs an async Okta call, retrying on 429 (honoring Retry-After) and 5xx with
    exponential backoff. `coro_fn` must be a zero-arg-safe callable that returns a fresh
    coroutine each call (pass a lambda), since a coroutine object can't be awaited twice."""
    attempt = 0
    while True:
        try:
            return await coro_fn(*args, **kwargs)
        except OktaApiError as exc:
            attempt += 1
            if attempt > MAX_RETRIES or (exc.status != 429 and exc.status < 500):
                raise
            delay = INITIAL_BACKOFF_SECONDS * (2 ** (attempt - 1))
            print(f"[RATE-LIMIT] Okta returned {exc.status}, retrying in {delay:.1f}s (attempt {attempt}/{MAX_RETRIES})")
            await asyncio.sleep(delay)


# --------------------------------------------------------------------------------------
# Step 1: batch-fetch users via /api/v1/users?search=...
# --------------------------------------------------------------------------------------
#
# Okta's /api/v1/users endpoint supports a `search` query parameter using SCIM-ish
# filter expressions, e.g.:
#     search=profile.email eq "user@example.com"
# Multiple emails can be OR'd into a single request:
#     search=profile.email eq "a@x.com" or profile.email eq "b@x.com"
# This lets us resolve a whole batch of emails to Okta user objects in ONE API call
# instead of one call per user. Okta's guidance (and this script's default) is to keep
# each OR'd batch to roughly 15-20 clauses -- larger filter strings risk hitting Okta's
# max URL/query length and become harder to debug when a single email is malformed.
#
# URL encoding: the raw filter string contains characters (spaces, quotes) that are not
# valid in a URL query string as-is. We do NOT hand-build the query string ourselves --
# httpx's `params=` argument takes care of percent-encoding every value automatically
# (e.g. a space becomes %20, a double-quote becomes %22) when it serializes the request.
# If you ever need to construct this URL manually (e.g. for curl/Postman), the equivalent
# encoding is `urllib.parse.quote(filter_string, safe="")`, which is what httpx does
# internally -- shown here only for reference/documentation, not used in the actual call:
#     quote('profile.email eq "user@example.com"', safe="")
#     -> 'profile.email%20eq%20%22user%40example.com%22'

def _build_email_search_filter(emails: list) -> str:
    clauses = [f'profile.email eq "{email}"' for email in emails]
    return " or ".join(clauses)


def _chunk(items: list, size: int) -> list:
    return [items[i:i + size] for i in range(0, len(items), size)]


async def fetch_users_by_email(all_emails: list) -> dict:
    """Fetches users in batches of USER_SEARCH_BATCH_SIZE via GET /api/v1/users?search=...
    Returns a dict keyed by lowercased email -> Okta user object (missing emails are
    simply absent from the dict, so callers can detect not-found users)."""
    unique_emails = sorted({e.strip() for e in all_emails if e.strip()})
    users_by_email = {}

    for batch in _chunk(unique_emails, USER_SEARCH_BATCH_SIZE):
        search = _build_email_search_filter(batch)

        async def _do_search(search=search):
            headers = await m2m_headers()
            async with httpx.AsyncClient(timeout=30) as client:
                resp = await client.get(f"{api_base()}/users", params={"search": search, "limit": 200}, headers=headers)
            raise_for_okta_error(resp)
            return expect_list(resp.json(), "GET /api/v1/users?search=...")

        users = await call_with_retry(_do_search)
        for user in users:
            email = (user.get("profile", {}) or {}).get("email", "")
            if email:
                users_by_email[email.strip().lower()] = user

    return users_by_email


# --------------------------------------------------------------------------------------
# Step 2: resolve bundle names -> bundle records for the target app
# --------------------------------------------------------------------------------------

async def fetch_bundles_by_name(app_id: str) -> dict:
    """GET .../entitlement-bundles?filter=target.externalId eq "{app_id}" once, and index
    by bundle name. There is no cached bundle file in this app (bundle data normally lives
    only in the NiceGUI session's app.storage.user, refreshed live via batch_load), so this
    is the equivalent fresh lookup a standalone script must do itself."""
    bundles = await call_with_retry(lambda: connectors_service.get_app_bundles(app_id))
    by_name = {}
    for bundle in bundles:
        name = bundle.get("name")
        if not name:
            continue
        if name in by_name:
            print(f"[WARN] Duplicate bundle name '{name}' for app {app_id} -- using the first match")
            continue
        by_name[name] = bundle
    return by_name


def extract_entitlement_codes(bundle: dict) -> list:
    """Mirrors app/ui/actions.py::resolve_entitlement_value_codes's bundle branch: pulls the
    external/verifiable code for each entitlement value inside a bundle, for use as the
    `entitlement_values` argument to target_systems_service.validate(). get_app_bundles()
    is called with include=full_entitlements, so values are already expanded inline."""
    codes = []
    for ent in bundle.get("entitlements", []) or []:
        for value in ent.get("values", []) or []:
            if isinstance(value, dict):
                code = value.get("externalId") or value.get("name") or value.get("id")
            else:
                code = value
            if code:
                codes.append(code)
    return codes


# --------------------------------------------------------------------------------------
# Step 3: per-user assign + verify (Okta grant, then target-system check)
# --------------------------------------------------------------------------------------

def _build_bundle_grant_body(app_id: str, user_id: str, bundle_id: str) -> dict:
    """Same shape as app/ui/actions.py::_build_grant_body for grantType == "bundle"."""
    return {
        "grantType": "ENTITLEMENT-BUNDLE",
        "target": {"externalId": app_id, "type": "APPLICATION"},
        "targetPrincipal": {"externalId": user_id, "type": "OKTA_USER"},
        "entitlementBundleId": bundle_id,
    }


async def process_row(row: InputRow, app_id: str, users_by_email: dict, bundles_by_name: dict) -> RowResult:
    result = RowResult(user_email=row.email, requested_bundles=";".join(row.bundle_names))

    user = users_by_email.get(row.email.strip().lower())
    if not user:
        result.failure_reason = "User not found in Okta for this email"
        result.okta_status = "FAILED"
        result.target_system_status = "SKIPPED"
        result.overall_status = "FAILED"
        return result

    user_id = user["id"]
    user_login = (user.get("profile", {}) or {}).get("login") or row.email

    granted_bundles = []
    grant_errors = []
    for bundle_name in row.bundle_names:
        bundle = bundles_by_name.get(bundle_name)
        if not bundle:
            grant_errors.append(f"Bundle '{bundle_name}' not found for app {app_id}")
            continue
        body = _build_bundle_grant_body(app_id, user_id, bundle["id"])
        try:
            await call_with_retry(lambda body=body: entitlements_service.create_grant(body))
            granted_bundles.append(bundle)
        except OktaApiError as exc:
            grant_errors.append(f"Bundle '{bundle_name}' grant failed: {exc}")
        except Exception as exc:  # noqa: BLE001 - a single user's failure must not abort the batch
            grant_errors.append(f"Bundle '{bundle_name}' grant failed: {exc}")

    if granted_bundles and not grant_errors:
        result.okta_status = "SUCCESS"
    elif granted_bundles and grant_errors:
        result.okta_status = "PARTIAL"
    else:
        result.okta_status = "FAILED"

    if grant_errors:
        result.failure_reason = "; ".join(grant_errors)

    if not granted_bundles:
        result.target_system_status = "SKIPPED"
        result.overall_status = "FAILED"
        return result

    entitlement_codes = []
    for bundle in granted_bundles:
        entitlement_codes.extend(extract_entitlement_codes(bundle))

    if not entitlement_codes:
        result.target_system_status = "SKIPPED"
    else:
        try:
            verification = await target_systems_service.validate(
                app_id=app_id, user_login=user_login, entitlement_values=entitlement_codes, user_id=user_id
            )
            result.target_system_status = "SUCCESS" if verification.get("hasAccess") else "FAILED"
            if not verification.get("hasAccess"):
                failed_checks = [r for r in verification.get("results", []) if not r.get("hasAccess")]
                reason = f"Target system verification failed for: {failed_checks}" if failed_checks else "Target system verification returned hasAccess=False"
                result.failure_reason = f"{result.failure_reason}; {reason}".strip("; ")
        except LookupError:
            # No target-system connector configured for this app -- there is nothing to verify.
            result.target_system_status = "SKIPPED"
        except Exception as exc:  # noqa: BLE001 - a single user's failure must not abort the batch
            result.target_system_status = "FAILED"
            result.failure_reason = f"{result.failure_reason}; Target system check errored: {exc}".strip("; ")

    result.overall_status = "SUCCESS" if result.okta_status == "SUCCESS" and result.target_system_status in ("SUCCESS", "SKIPPED") else "FAILED"
    return result


# --------------------------------------------------------------------------------------
# Step 4: reporting
# --------------------------------------------------------------------------------------

def write_report(results: list, output_path: Path) -> None:
    fieldnames = ["user_email", "requested_bundles", "okta_status", "target_system_status", "overall_status", "failure_reason"]
    with output_path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()
        for r in results:
            writer.writerow({
                "user_email": r.user_email,
                "requested_bundles": r.requested_bundles,
                "okta_status": r.okta_status,
                "target_system_status": r.target_system_status,
                "overall_status": r.overall_status,
                "failure_reason": r.failure_reason,
            })


SUMMARY_WIDTH = 70
DETAIL_COL_WIDTHS = {
    "user_email": 30,
    "requested_bundles": 22,
    "okta_status": 10,
    "target_system_status": 14,
    "overall_status": 10,
    "failure_reason": 50,
}


def build_summary_lines(results: list, generated_at: Optional[str] = None) -> list:
    """Builds the plain-text summary block shared by console output and the .txt report,
    so both stay in sync (single source of truth for the numbers)."""
    total = len(results)
    successes = sum(1 for r in results if r.overall_status == "SUCCESS")
    failures = total - successes
    okta_ok = sum(1 for r in results if r.okta_status == "SUCCESS")
    okta_partial = sum(1 for r in results if r.okta_status == "PARTIAL")
    okta_failed = sum(1 for r in results if r.okta_status == "FAILED")
    target_ok = sum(1 for r in results if r.target_system_status == "SUCCESS")
    target_failed = sum(1 for r in results if r.target_system_status == "FAILED")
    target_skipped = sum(1 for r in results if r.target_system_status == "SKIPPED")

    lines = []
    lines.append("=" * SUMMARY_WIDTH)
    lines.append("BATCH BUNDLE ASSIGNMENT SUMMARY".center(SUMMARY_WIDTH))
    if generated_at:
        lines.append(f"Generated: {generated_at}".center(SUMMARY_WIDTH))
    lines.append("=" * SUMMARY_WIDTH)
    lines.append(f"{'Total Processed':<28}: {total}")
    lines.append(f"{'Total Successes':<28}: {successes}")
    lines.append(f"{'Total Failures':<28}: {failures}")
    lines.append("-" * SUMMARY_WIDTH)
    lines.append("Okta Grant Status".center(SUMMARY_WIDTH))
    lines.append(f"{'  SUCCESS':<28}: {okta_ok}/{total}")
    lines.append(f"{'  PARTIAL':<28}: {okta_partial}/{total}")
    lines.append(f"{'  FAILED':<28}: {okta_failed}/{total}")
    lines.append("-" * SUMMARY_WIDTH)
    lines.append("Target System Status".center(SUMMARY_WIDTH))
    lines.append(f"{'  SUCCESS':<28}: {target_ok}/{total}")
    lines.append(f"{'  FAILED':<28}: {target_failed}/{total}")
    lines.append(f"{'  SKIPPED (no config)':<28}: {target_skipped}/{total}")
    lines.append("=" * SUMMARY_WIDTH)
    return lines


def build_detail_lines(results: list) -> list:
    """Builds an aligned, fixed-width detail table (one row per user) for the .txt report.
    Long values (bundle lists, failure reasons) wrap onto continuation lines rather than
    stretching the table, so the whole report stays readable in a plain text viewer."""
    headers = ["user_email", "requested_bundles", "okta_status", "target_system_status", "overall_status", "failure_reason"]
    lines = []
    header_row = "  ".join(f"{h.upper():<{DETAIL_COL_WIDTHS[h]}}" for h in headers)
    lines.append(header_row)
    lines.append("-" * len(header_row))

    for r in results:
        wrapped = {
            "user_email": textwrap.wrap(r.user_email, DETAIL_COL_WIDTHS["user_email"]) or [""],
            "requested_bundles": textwrap.wrap(r.requested_bundles, DETAIL_COL_WIDTHS["requested_bundles"]) or [""],
            "okta_status": [r.okta_status],
            "target_system_status": [r.target_system_status],
            "overall_status": [r.overall_status],
            "failure_reason": textwrap.wrap(r.failure_reason, DETAIL_COL_WIDTHS["failure_reason"]) or [""],
        }
        row_height = max(len(v) for v in wrapped.values())
        for i in range(row_height):
            cells = []
            for h in headers:
                col_values = wrapped[h]
                cell = col_values[i] if i < len(col_values) else ""
                cells.append(f"{cell:<{DETAIL_COL_WIDTHS[h]}}")
            lines.append("  ".join(cells))
        lines.append("")  # blank line between users for readability

    return lines


def print_summary(results: list) -> None:
    print("\n" + "\n".join(build_summary_lines(results)) + "\n")


def write_text_report(results: list, output_path: Path, generated_at: str) -> None:
    """Writes a human-readable .txt report: summary block at the top, detailed per-user
    results below -- a plain-text companion to the machine-readable CSV report."""
    lines = build_summary_lines(results, generated_at=generated_at)
    lines.append("")
    lines.append("DETAILED RESULTS".center(SUMMARY_WIDTH))
    lines.append("=" * SUMMARY_WIDTH)
    lines.append("")
    lines.extend(build_detail_lines(results))
    output_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


# --------------------------------------------------------------------------------------
# Orchestration
# --------------------------------------------------------------------------------------

async def run(app_id: str, file_path: str) -> list:
    rows = read_input_csv(file_path)

    print(f"[INFO] Loaded {len(rows)} row(s) from {file_path}")
    print(f"[INFO] Resolving {len(rows)} user(s) via Okta search (batches of {USER_SEARCH_BATCH_SIZE})...")
    users_by_email = await fetch_users_by_email([r.email for r in rows])
    print(f"[INFO] Resolved {len(users_by_email)}/{len({r.email.lower() for r in rows})} unique email(s) to Okta users")

    print(f"[INFO] Fetching bundles for app {app_id}...")
    bundles_by_name = await fetch_bundles_by_name(app_id)
    print(f"[INFO] Found {len(bundles_by_name)} bundle(s) for app {app_id}")

    print(f"[INFO] Processing {len(rows)} row(s) with concurrency={USER_PROCESSING_CONCURRENCY}...")
    results = await run_limited(
        [lambda row=row: process_row(row, app_id, users_by_email, bundles_by_name) for row in rows],
        limit=USER_PROCESSING_CONCURRENCY,
    )
    return results


def main() -> None:
    parser = argparse.ArgumentParser(description="Batch-assign Okta entitlement bundles to users and verify the grant.")
    parser.add_argument("--app-id", required=True, help="Target Okta application ID (external ID used as grant target)")
    parser.add_argument("--file-path", required=True, help="Path to the input CSV (columns: user_email, bundles)")
    parser.add_argument("--env", choices=["dev", "qa"], default="dev",
                         help="Environment to target (default: dev). Already applied by config.env_bootstrap.")
    args = parser.parse_args()
    assert args.env == config.env_bootstrap.CURRENT_ENV

    try:
        results = asyncio.run(run(args.app_id, args.file_path))
    except SystemExit:
        raise
    except Exception as exc:  # noqa: BLE001 - top-level guard so the CLI exits cleanly with a message
        print(f"[FATAL] {exc}", file=sys.stderr)
        sys.exit(1)

    timestamp = time.strftime("%Y%m%d_%H%M%S")
    csv_report_path = Path(f"execution_report_{timestamp}.csv")
    txt_report_path = Path(f"execution_report_{timestamp}.txt")
    write_report(results, csv_report_path)
    write_text_report(results, txt_report_path, generated_at=time.strftime("%Y-%m-%d %H:%M:%S"))
    print_summary(results)
    print(f"[INFO] CSV report written to  {csv_report_path}")
    print(f"[INFO] Text report written to {txt_report_path}")


if __name__ == "__main__":
    main()
