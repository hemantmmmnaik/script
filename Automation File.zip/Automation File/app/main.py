from fastapi import FastAPI
from nicegui import ui
from starlette.middleware.sessions import SessionMiddleware

from app import settings
from app.ui.guards import require_auth
# Importing these registers their routes: auth_routes registers plain /auth/* routes directly
# on nicegui's own app (see that module for why), the rest register their @ui.page routes.
import app.auth_routes  # noqa: F401
from app.ui.pages import connector_detail_page, connectors_page, setup_page  # noqa: F401

app = FastAPI()
# Authlib's OAuth client needs Starlette's own request.session (PKCE code_verifier + state
# during the OIDC handshake) — this is separate from NiceGUI's app.storage.user, which uses
# its own cookie/session mechanism and does not populate request.session.
app.add_middleware(SessionMiddleware, secret_key=settings.SESSION_SECRET, same_site="lax")


@ui.page("/")
def root():
    if not require_auth():
        return
    ui.navigate.to("/connectors")


ui.run_with(app, storage_secret=settings.SESSION_SECRET, title="Multi-Connector Tester")

if __name__ in {"__main__", "__mp_main__"}:
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=settings.PORT)
