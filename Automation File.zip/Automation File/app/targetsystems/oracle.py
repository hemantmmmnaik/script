from typing import Optional

import oracledb

from app import settings

oracledb.defaults.fetch_lobs = False


async def _get_connection():
    if not settings.ORACLE_CONNECT_STRING or not settings.ORACLE_USER or not settings.ORACLE_PASSWORD:
        raise RuntimeError("Missing ORACLE_CONNECT_STRING, ORACLE_USER, or ORACLE_PASSWORD in .env")
    return await oracledb.connect_async(
        dsn=settings.ORACLE_CONNECT_STRING,
        user=settings.ORACLE_USER,
        password=settings.ORACLE_PASSWORD,
    )


async def check_access(
    user_login: str,
    entitlement_value: str,
    query: Optional[str] = None,
    procedure: Optional[str] = None,
) -> dict:
    if not query and not procedure:
        raise ValueError("Oracle connector config must define a query or a procedure")

    connection = await _get_connection()
    try:
        cursor = connection.cursor()
        if procedure:
            has_access_var = cursor.var(oracledb.NUMBER)
            await cursor.execute(
                f"BEGIN {procedure}(:userLogin, :entitlementValue, :hasAccess); END;",
                userLogin=user_login,
                entitlementValue=entitlement_value,
                hasAccess=has_access_var,
            )
            raw = has_access_var.getvalue()
            has_access = int(raw) == 1
            return {"hasAccess": has_access, "detail": f"Procedure {procedure} returned {raw}"}

        await cursor.execute(query, {"userLogin": user_login, "entitlementValue": entitlement_value})
        rows = await cursor.fetchall()
        has_access = len(rows) > 0
        return {
            "hasAccess": has_access,
            "rowCount": len(rows),
            "detail": f"Query returned {len(rows)} row(s)" if has_access else "Query returned no rows",
        }
    finally:
        await connection.close()
