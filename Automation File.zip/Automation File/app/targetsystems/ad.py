import asyncio
import re

import ldap3
from ldap3.core.exceptions import LDAPException

from app import settings


def escape_ldap_filter(value: str) -> str:
    """RFC 4515 escaping of \\, *, (, ), NUL — matches the original ldapjs-based escaping exactly."""
    return re.sub(
        r"[\\*()\x00]",
        lambda m: "\\" + format(ord(m.group(0)), "02x"),
        str(value),
    )


def cn_from_dn(dn: str) -> str:
    match = re.match(r"^CN=([^,]+)", dn, re.IGNORECASE)
    return match.group(1) if match else dn


def _connect() -> ldap3.Connection:
    if not settings.AD_URL:
        raise RuntimeError("Missing AD_URL in .env")
    if not settings.AD_BIND_DN or not settings.AD_BIND_PASSWORD:
        raise RuntimeError("Missing AD_BIND_DN or AD_BIND_PASSWORD in .env")

    tls = None
    if settings.AD_CA_CERT_PATH:
        tls = ldap3.Tls(ca_certs_file=settings.AD_CA_CERT_PATH)

    server = ldap3.Server(settings.AD_URL, tls=tls, connect_timeout=10)
    connection = ldap3.Connection(
        server,
        user=settings.AD_BIND_DN,
        password=settings.AD_BIND_PASSWORD,
        receive_timeout=10,
    )
    if not connection.bind():
        raise LDAPException(f"AD bind failed: {connection.result}")
    return connection


def _check_group_membership_sync(user_login: str, group_name: str) -> dict:
    if not settings.AD_BASE_DN:
        raise RuntimeError("Missing AD_BASE_DN in .env")
    search_attr = settings.AD_USER_SEARCH_ATTR or "sAMAccountName"

    connection = _connect()
    try:
        filter_ = f"({search_attr}={escape_ldap_filter(user_login)})"
        connection.search(
            settings.AD_BASE_DN,
            filter_,
            search_scope=ldap3.SUBTREE,
            attributes=["memberOf", search_attr],
        )
        entries = connection.entries

        if not entries:
            return {
                "hasAccess": False,
                "found": False,
                "groups": [],
                "detail": f"No AD account found for {search_attr}={user_login}",
            }

        member_of = list(entries[0]["memberOf"].values) if "memberOf" in entries[0] else []
        groups = [cn_from_dn(dn) for dn in member_of]
        has_access = any(g.lower() == str(group_name).lower() for g in groups)

        return {
            "hasAccess": has_access,
            "found": True,
            "groups": groups,
            "detail": f"Member of {group_name}" if has_access else f"Not a member of {group_name}",
        }
    finally:
        connection.unbind()


async def check_group_membership(user_login: str, group_name: str) -> dict:
    return await asyncio.to_thread(_check_group_membership_sync, user_login, group_name)
