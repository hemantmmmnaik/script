import time
from typing import Optional
from urllib.parse import quote

import httpx

from app import settings

_cached_token: Optional[str] = None
_token_expires_at: float = 0.0


async def _get_graph_token() -> str:
    global _cached_token, _token_expires_at

    now_ms = time.time() * 1000
    if _cached_token and now_ms < _token_expires_at - 60_000:
        return _cached_token

    if not settings.ENTRAID_TENANT_ID or not settings.ENTRAID_CLIENT_ID or not settings.ENTRAID_CLIENT_SECRET:
        raise RuntimeError("Missing ENTRAID_TENANT_ID, ENTRAID_CLIENT_ID, or ENTRAID_CLIENT_SECRET in .env")

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(
            f"https://login.microsoftonline.com/{settings.ENTRAID_TENANT_ID}/oauth2/v2.0/token",
            data={
                "grant_type": "client_credentials",
                "client_id": settings.ENTRAID_CLIENT_ID,
                "client_secret": settings.ENTRAID_CLIENT_SECRET,
                "scope": "https://graph.microsoft.com/.default",
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
    resp.raise_for_status()
    body = resp.json()
    _cached_token = body["access_token"]
    _token_expires_at = time.time() * 1000 + body["expires_in"] * 1000
    return _cached_token


async def check_group_membership(user_login: str, group_name: str) -> dict:
    match_attr = settings.ENTRAID_USER_MATCH_ATTR or "userPrincipalName"
    token = await _get_graph_token()
    headers = {"Authorization": f"Bearer {token}", "Accept": "application/json"}

    escaped_login = str(user_login).replace("'", "''")
    user_filter = quote(f"{match_attr} eq '{escaped_login}'")

    async with httpx.AsyncClient(timeout=30) as client:
        user_resp = await client.get(
            f"https://graph.microsoft.com/v1.0/users?$filter={user_filter}&$select=id,{match_attr}",
            headers=headers,
        )
        user_resp.raise_for_status()
        users = user_resp.json().get("value") or []
        if not users:
            return {
                "hasAccess": False,
                "found": False,
                "groups": [],
                "detail": f"No EntraID user found for {match_attr}={user_login}",
            }
        user = users[0]

        groups: list[str] = []
        url = f"https://graph.microsoft.com/v1.0/users/{user['id']}/memberOf?$select=displayName"
        while url:
            member_resp = await client.get(url, headers=headers)
            member_resp.raise_for_status()
            data = member_resp.json()
            groups.extend(g["displayName"] for g in data.get("value") or [] if g.get("displayName"))
            url = data.get("@odata.nextLink")

    has_access = any(g.lower() == str(group_name).lower() for g in groups)
    return {
        "hasAccess": has_access,
        "found": True,
        "groups": groups,
        "detail": f"Member of {group_name}" if has_access else f"Not a member of {group_name}",
    }
