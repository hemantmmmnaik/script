import asyncio
from typing import Optional

import pytds

from app import settings

_pool_kwargs: Optional[dict] = None


def _connection_kwargs() -> dict:
    global _pool_kwargs
    if _pool_kwargs is not None:
        return _pool_kwargs

    if not settings.MSSQL_SERVER or not settings.MSSQL_DATABASE or not settings.MSSQL_USER or not settings.MSSQL_PASSWORD:
        raise RuntimeError("Missing MSSQL_SERVER, MSSQL_DATABASE, MSSQL_USER, or MSSQL_PASSWORD in .env")

    _pool_kwargs = {
        "server": settings.MSSQL_SERVER,
        "database": settings.MSSQL_DATABASE,
        "user": settings.MSSQL_USER,
        "password": settings.MSSQL_PASSWORD,
        "port": settings.MSSQL_PORT,
        "autocommit": True,
    }
    return _pool_kwargs


def _check_access_sync(user_login: str, entitlement_value: str, query: Optional[str], procedure: Optional[str]) -> dict:
    if not query and not procedure:
        raise ValueError("MSSQL connector config must define a query or a procedure")

    with pytds.connect(**_connection_kwargs()) as connection:
        with connection.cursor() as cursor:
            if procedure:
                params = cursor.callproc(procedure, (user_login, entitlement_value, pytds.output(value=0)))
                raw = params[2]
                has_access = bool(raw)
                return {"hasAccess": has_access, "detail": f"Procedure {procedure} returned {raw}"}

            # Admin-facing contract (CLAUDE.md) uses raw T-SQL @name binds, matching the original
            # tedious-based driver; pytds' DB-API layer expects pyformat %(name)s, so translate here.
            pyformat_query = query.replace("@userLogin", "%(userLogin)s").replace("@entitlementValue", "%(entitlementValue)s")
            cursor.execute(pyformat_query, {"userLogin": user_login, "entitlementValue": entitlement_value})
            rows = cursor.fetchall()
            has_access = len(rows) > 0
            return {
                "hasAccess": has_access,
                "rowCount": len(rows),
                "detail": f"Query returned {len(rows)} row(s)" if has_access else "Query returned no rows",
            }


async def check_access(
    user_login: str,
    entitlement_value: str,
    query: Optional[str] = None,
    procedure: Optional[str] = None,
) -> dict:
    return await asyncio.to_thread(_check_access_sync, user_login, entitlement_value, query, procedure)
