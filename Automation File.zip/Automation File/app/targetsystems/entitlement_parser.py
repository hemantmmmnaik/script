import re
from typing import Optional

# "auto" replicates the original shape-based detection (list / bool / scalar).
# The others let a target system config force a specific interpretation of the
# value found at responsePath, regardless of its runtime shape.
PARSER_TYPES = {"auto", "list", "bool", "scalar", "userRoleList", "compositeList"}

DEFAULT_COMPOSITE_FIELDS = ["region", "groupName"]
DEFAULT_COMPOSITE_SEPARATOR = "-"

# A dotted-path segment is a key optionally followed by a list index, e.g. "content[0]".
_PATH_SEGMENT_RE = re.compile(r"^(\w+)((?:\[\d+\])*)$")
_INDEX_RE = re.compile(r"\[(\d+)\]")


def _apply_segment(current, segment: str):
    """Resolves one '.'-separated path segment -- a bare key ("content"), a key with one or more
    trailing list indices ("content[0]", "items[0][1]"), looked up via dict.get then indexed into
    with normal list indexing. Returns None if the segment doesn't parse, the key is missing, or
    an index is out of range/not applicable to a non-list."""
    match = _PATH_SEGMENT_RE.match(segment)
    if not match:
        return None
    key, index_suffix = match.group(1), match.group(2)
    current = current.get(key) if isinstance(current, dict) else None
    for index in _INDEX_RE.findall(index_suffix):
        if not isinstance(current, list):
            return None
        idx = int(index)
        if not (-len(current) <= idx < len(current)):
            return None
        current = current[idx]
    return current


def get_path(obj, path: Optional[str]):
    if not path:
        return obj
    current = obj
    for segment in path.split("."):
        if current is None:
            return None
        current = _apply_segment(current, segment)
    return current


def values_equal(a, b) -> bool:
    try:
        return float(a) == float(b)
    except (TypeError, ValueError):
        str_a, str_b = str(a).lower(), str(b).lower()
        tokens_a = {t.strip() for t in str_a.split(",")}
        tokens_b = {t.strip() for t in str_b.split(",")}
        return bool(tokens_a & tokens_b)


def _resolve_parser_type(value, parser_type: Optional[str]) -> str:
    if parser_type and parser_type != "auto":
        if parser_type not in PARSER_TYPES:
            raise ValueError(f"Unknown entitlement parser type: {parser_type}")
        return parser_type
    if isinstance(value, list):
        return "list"
    if isinstance(value, bool):
        return "bool"
    return "scalar"

def _resolve_dotted_path(current, parts: list):
    """Like get_path, but a list encountered partway through the path is expanded instead of
    treated as a dead end: the remaining path is applied to each item and the results are
    flattened. E.g. parts=["abc","xyz"] against {"abc": [{"xyz": 1}, {"xyz": 2}]} loops through
    "abc"'s list and collects each item's "xyz" -> [1, 2]. A plain single-key path (no list along
    the way) behaves exactly like dict.get."""
    if not parts:
        return current
    if current is None:
        return None
    if isinstance(current, list):
        results = []
        for item in current:
            resolved = _resolve_dotted_path(item, parts)
            if isinstance(resolved, list):
                results.extend(resolved)
            elif resolved is not None:
                results.append(resolved)
        return results
    if isinstance(current, dict):
        return _resolve_dotted_path(current.get(parts[0]), parts[1:])
    return None


def _find_user_record(records: list, user_login: Optional[str], user_match_field: str) -> Optional[dict]:
    login = str(user_login or "").lower()
    for record in records:
        if isinstance(record, dict) and str(record.get(user_match_field, "")).lower() == login:
            return record
    return None


def split_composite_value(value, fields: list, separator: str) -> dict:
    """Splits 'us-agent' into {"region": "us", "groupName": "agent"} given fields=["region","groupName"]."""
    parts = str(value).split(separator, len(fields) - 1)
    return dict(zip(fields, parts))


def extract_entitlement(
    data,
    response_path: Optional[str] = None,
    role_id_field: Optional[str] = None,
    parser_type: Optional[str] = None,
    user_login: Optional[str] = None,
    user_match_field: Optional[str] = None,
    roles_field: Optional[str] = None,
) -> dict:
    """Pulls the raw entitlement value(s) out of a downstream response, without judging access."""
    value = get_path(data, response_path)
    effective_type = _resolve_parser_type(value, parser_type)

    if effective_type == "list":
        effective_role_id_field = role_id_field or "RoleId"
        items = value if isinstance(value, list) else []
        entitlement_values = [get_path(item,effective_role_id_field) if isinstance(item, dict) else item for item in items]
        return {"parserType": "list", "value": value, "entitlementValues": entitlement_values}

    if effective_type == "compositeList":
        # Root value is a list of objects, each carrying several fields (e.g. region + groupName)
        # that together make up one composite entitlement value like "us-agent".
        items = value if isinstance(value, list) else []
        return {"parserType": "compositeList", "value": value, "entitlementValues": items}

    if effective_type == "userRoleList":
        # Root value is a list of user records (e.g. [{"userName": ..., "userRoles": [...]}, ...]);
        # the user must first be filtered out of that list via userMatchField before any role can
        # be read off of it — an unmatched user is not the same as a matched user lacking the role.
        records = value if isinstance(value, list) else []
        effective_match_field = user_match_field or "userName"
        effective_roles_field = roles_field or "userRoles"
        record = _find_user_record(records, user_login, effective_match_field)
        roles = _resolve_dotted_path(record, effective_roles_field.split(".")) if record else None
        entitlement_values = list(roles) if isinstance(roles, list) else roles
        return {
            "parserType": "userRoleList",
            "value": record,
            "entitlementValues": entitlement_values,
            "found": record is not None,
            "matchField": effective_match_field,
        }

    if effective_type == "bool":
        return {"parserType": "bool", "value": value, "entitlementValues": [value]}

    return {"parserType": "scalar", "value": value, "entitlementValues": [value] if value is not None else []}


def match(
    data,
    entitlement_value: str,
    response_path: Optional[str] = None,
    expected=None,
    role_id_field: Optional[str] = None,
    parser_type: Optional[str] = None,
    user_login: Optional[str] = None,
    user_match_field: Optional[str] = None,
    roles_field: Optional[str] = None,
    composite_fields: Optional[list] = None,
    composite_separator: Optional[str] = None,
) -> dict:
    """Extracts the entitlement from a downstream response and decides whether it matches the target value."""
    extracted = extract_entitlement(
        data,
        response_path,
        role_id_field,
        parser_type,
        user_login=user_login,
        user_match_field=user_match_field,
        roles_field=roles_field,
    )
    target = expected if expected is not None else entitlement_value

    if extracted["parserType"] == "userRoleList" and not extracted["found"]:
        return {
            "hasAccess": False,
            "value": extracted["value"],
            "entitlementValues": extracted["entitlementValues"],
            "parserType": extracted["parserType"],
            "found": False,
            "detail": f"No user found with {extracted['matchField']}={user_login}",
        }

    if extracted["parserType"] == "compositeList":
        fields = composite_fields or DEFAULT_COMPOSITE_FIELDS
        separator = composite_separator or DEFAULT_COMPOSITE_SEPARATOR
        target_fields = split_composite_value(target, fields, separator)
        items = extracted["entitlementValues"] if isinstance(extracted["entitlementValues"], list) else []
        has_access = any(
            isinstance(item, dict) and all(values_equal(item.get(field), val) for field, val in target_fields.items())
            for item in items
        )
        path_label = response_path or "(root)"
        fields_label = ", ".join(f"{field}={val}" for field, val in target_fields.items())
        detail = (
            f"Matched {fields_label} at {path_label}" if has_access else f"No match for {fields_label} at {path_label}"
        )
        return {
            "hasAccess": has_access,
            "value": extracted["value"],
            "entitlementValues": extracted["entitlementValues"],
            "parserType": extracted["parserType"],
            "detail": detail,
        }

    if extracted["parserType"] in ("list", "userRoleList"):
        if isinstance(extracted["entitlementValues"], list):
            has_access = any(values_equal(v, target) for v in extracted["entitlementValues"])
        else:
            has_access = values_equal(extracted["entitlementValues"], target)
    elif extracted["parserType"] == "bool":
        has_access = extracted["value"] is True
    else:
        raw = extracted["value"]
        has_access = raw is not None and str(raw).lower() == str(target).lower()

    path_label = response_path or "(root)"
    detail = f"Matched {target} at {path_label}" if has_access else f"No match for {target} at {path_label}"
    result = {
        "hasAccess": has_access,
        "value": extracted["value"],
        "entitlementValues": extracted["entitlementValues"],
        "parserType": extracted["parserType"],
        "detail": detail,
    }
    if "found" in extracted:
        result["found"] = extracted["found"]
    return result
