from typing import Optional

from app.services import connectors_service, db_automation_service
from app.targetsystems import ad, entitlement_parser, entraid, webservice

DB_AUTOMATION_TYPES = {"ORACLE", "MSSQL", "POSTGRES", "MYSQL"}


async def _fetch_access_rows(app_id: str, user_login: str) -> dict:
    """The single DB round trip for a (app_id, user_login) pair -- hoisted above the per-
    entitlement loop in validate_many() so N requested entitlement/bundle codes cost one query,
    not N. Most check_access queries return the user's full role/group/privilege list rather than
    filtering by a specific entitlement, so fetching once and matching locally (see
    _evaluate_db_access/_matches_entitlement) is both cheaper and more correct than looping."""
    if not app_id:
        raise ValueError("DB target-system check requires an app_id")
    response = await db_automation_service.execute_action(app_id, "check_access", {"userLogin": user_login})
    return response.get("result") or {}


def _matches_entitlement(row: dict, entitlement_value: str, entitlement_column: str = None) -> bool:
    target = str(entitlement_value).strip().lower()
    if entitlement_column:
        return str(row.get(entitlement_column, "")).strip().lower() == target
    return any(str(value).strip().lower() == target for value in row.values() if value is not None)


def _rows_from_outputs(outputs: dict) -> Optional[list]:
    """A procedure's OUT SYS_REFCURSOR param is materialized by the driver as a list[dict] of
    rows (see app/dbautomation/drivers/oracle.py::_execute_procedure_sync). Auto-detect it: if
    exactly one OUT param's value is a list of dicts, treat that as the row-set -- no config
    needed to name which OUT param holds it."""
    list_values = [v for v in outputs.values() if isinstance(v, list)]
    if len(list_values) == 1:
        return list_values[0]
    return None


def _evaluate_db_access(fetch_result: dict, entitlement_value: str, entitlement_column: str = None) -> bool:
    if "rows" in fetch_result:
        return any(_matches_entitlement(row, entitlement_value, entitlement_column) for row in fetch_result["rows"])
    if "outputs" in fetch_result:
        rows = _rows_from_outputs(fetch_result["outputs"])
        if rows is not None:
            return any(_matches_entitlement(row, entitlement_value, entitlement_column) for row in rows)
    return fetch_result.get("rowCount", 0) > 0


async def _check_via_db_automation(
    app_id: str, type_: str, user_login: str, entitlement_value: str, entitlement_column: str = None
) -> dict:
    fetch_result = await _fetch_access_rows(app_id, user_login)
    return {"system": type_, "hasAccess": _evaluate_db_access(fetch_result, entitlement_value, entitlement_column)}
from app.services import connectors_service
from app.targetsystems import ad, entitlement_parser, entraid, mssql, oracle, webservice


async def validate_one(
    connector_config: dict,
    user_login: str,
    entitlement_value: str,
    scim_external_id: str = None,
    app_id: str = None,
    user_id: str = None,
) -> dict:
    type_ = (connector_config or {}).get("type")

    if type_ == "AD":
        return {"system": "AD", **await ad.check_group_membership(user_login, entitlement_value)}
    if type_ == "ENTRAID":
        return {"system": "ENTRAID", **await entraid.check_group_membership(user_login, entitlement_value)}
    if type_ in DB_AUTOMATION_TYPES:
        db_login = user_login
        if app_id and user_id:
            db_login = await _get_app_username(app_id, user_id) or user_login
        return await _check_via_db_automation(
            app_id, type_, db_login, entitlement_value,
            entitlement_column=db_automation_service.get_entitlement_column(app_id),
        )
    if type_ == "WEBSERVICE":
        return {
            "system": "WEBSERVICE",
            **await webservice.check_access(
                user_login,
                entitlement_value,
                endpoint_template=connector_config.get("endpointTemplate"),
                response_path=connector_config.get("responsePath"),
                expected=connector_config.get("expected"),
                proxy_url=connector_config.get("proxyUrl"),
                base_url=connector_config.get("baseUrl"),
                auth_type=connector_config.get("authType"),
                auth_token=connector_config.get("authToken"),
                auth_user=connector_config.get("authUser"),
                auth_password=connector_config.get("authPassword"),
                auth_header_name=connector_config.get("authHeaderName"),
                scim_external_id=scim_external_id,
                client_id=connector_config.get("clientId"),
                client_secret=connector_config.get("clientSecret"),
                role_id_field=connector_config.get("roleIdField"),
                parser_type=connector_config.get("parserType"),
                user_match_field=connector_config.get("userMatchField"),
                roles_field=connector_config.get("rolesField"),
                scim_token_url=connector_config.get("scimTokenUrl"),
                composite_fields=connector_config.get("compositeFields"),
                composite_separator=connector_config.get("compositeSeparator"),
                archer_login_url=connector_config.get("archerLoginUrl"),
                archer_instance_name=connector_config.get("archerInstanceName"),
                archer_user_domain=connector_config.get("archerUserDomain"),
            ),
        }

    raise ValueError(f"Unknown or unset target-system type: {type_}")


async def _get_scim_external_id(app_id: str, user_id: str, external_id_field: str = "externalId") -> str:
    try:
        assignment = await connectors_service.get_app_user_assignment(app_id, user_id)
    except Exception:
        return None
    if not assignment.get("assigned"):
        return None
    app_user = assignment.get("appUser") or {}
    # Supports dotted paths (e.g. "profile.email") in addition to top-level fields (e.g. "externalId").
    return entitlement_parser.get_path(app_user, external_id_field)


async def _get_app_username(app_id: str, user_id: str) -> str:
    """DB target systems persist their own per-app username, which is frequently different from
    the Okta core user's profile.login -- resolve it via Okta's Get Application User API
    (credentials.userName on the AppUser object) so check_access queries run against the login the
    target database actually has on file."""
    try:
        assignment = await connectors_service.get_app_user_assignment(app_id, user_id)
    except Exception:
        return None
    if not assignment.get("assigned"):
        return None
    return ((assignment.get("appUser") or {}).get("credentials") or {}).get("userName")


async def _get_app_username(app_id: str, user_id: str) -> str:
    """DB target systems persist their own per-app username, which is frequently different from
    the Okta core user's profile.login -- resolve it via Okta's Get Application User API
    (credentials.userName on the AppUser object) so check_access queries run against the login the
    target database actually has on file."""
    try:
        assignment = await connectors_service.get_app_user_assignment(app_id, user_id)
    except Exception:
        return None
    if not assignment.get("assigned"):
        return None
    return ((assignment.get("appUser") or {}).get("credentials") or {}).get("userName")


async def validate_many(
    connector_config: dict,
    user_login: str,
    entitlement_values: list,
    app_id: str = None,
    user_id: str = None,
) -> dict:
    scim_external_id = None
    if connector_config.get("type") == "WEBSERVICE" and app_id and user_id:
        external_id_field = connector_config.get("externalIdField") or "externalId"
        scim_external_id = await _get_scim_external_id(app_id, user_id, external_id_field)

    type_ = (connector_config or {}).get("type")
    entitlement_column = db_automation_service.get_entitlement_column(app_id) if type_ in DB_AUTOMATION_TYPES else None

    # DB target systems persist their own per-app username (distinct from the Okta core user's
    # profile.login) -- resolve it via the AppUser API before querying, falling back to
    # profile.login if no AppUser record/credentials.userName exists for this assignment.
    db_login = user_login
    if type_ in DB_AUTOMATION_TYPES and app_id and user_id:
        db_login = await _get_app_username(app_id, user_id) or user_login

    # DB-automation types: fetch the user's access rows ONCE here (not once per entitlement_value
    # below) since most check_access queries return the user's full row/role/group list regardless
    # of which entitlement was requested -- see _fetch_access_rows/_evaluate_db_access.
    shared_fetch, fetch_error = None, None
    if type_ in DB_AUTOMATION_TYPES:
        try:
            shared_fetch = await _fetch_access_rows(app_id, db_login)
        except Exception as exc:  # noqa: BLE001 - surfaced per entitlement_value below
            fetch_error = exc

    type_ = (connector_config or {}).get("type")
    entitlement_column = db_automation_service.get_entitlement_column(app_id) if type_ in DB_AUTOMATION_TYPES else None

    # DB target systems persist their own per-app username (distinct from the Okta core user's
    # profile.login) -- resolve it via the AppUser API before querying, falling back to
    # profile.login if no AppUser record/credentials.userName exists for this assignment.
    db_login = user_login
    if type_ in DB_AUTOMATION_TYPES and app_id and user_id:
        db_login = await _get_app_username(app_id, user_id) or user_login

    # DB-automation types: fetch the user's access rows ONCE here (not once per entitlement_value
    # below) since most check_access queries return the user's full row/role/group list regardless
    # of which entitlement was requested -- see _fetch_access_rows/_evaluate_db_access.
    shared_fetch, fetch_error = None, None
    if type_ in DB_AUTOMATION_TYPES:
        try:
            shared_fetch = await _fetch_access_rows(app_id, db_login)
        except Exception as exc:  # noqa: BLE001 - surfaced per entitlement_value below
            fetch_error = exc

    results = []
    for entitlement_value in entitlement_values:
        try:
            if type_ in DB_AUTOMATION_TYPES:
                if fetch_error is not None:
                    raise fetch_error
                result = {
                    "system": type_,
                    "hasAccess": _evaluate_db_access(shared_fetch, entitlement_value, entitlement_column),
                }
            else:
                result = await validate_one(
                    connector_config, user_login, entitlement_value, scim_external_id, app_id=app_id, user_id=user_id,
                )
            results.append({"entitlementValue": entitlement_value, **result})
        except Exception as exc:
            results.append(
                {
                    "entitlementValue": entitlement_value,
                    "system": type_,
                    "hasAccess": False,
                    "error": str(exc),
                }
            )

    has_access = len(results) > 0 and all(r["hasAccess"] for r in results)
    return {"hasAccess": has_access, "results": results}
