import base64
import re
import time
from typing import Optional
from urllib.parse import quote

import httpx

from app import settings
from app.targetsystems import entitlement_parser

_token_cache: dict = {}  # clientId -> {"token": str, "expiresAt": float}
_archer_session_cache: dict = {}  # loginUrl:instanceName:username -> {"token": str, "expiresAt": float}

ARCHER_SESSION_TTL_MS = 20 * 60 * 1000  # Archer sessions expire after ~20 min of inactivity


async def _get_scim_bearer_token(client_id: str, client_secret: str, token_url: Optional[str] = None) -> str:
    effective_token_url = token_url or settings.SCIM_TOKEN_URL
    if not effective_token_url:
        raise RuntimeError("Missing scimTokenUrl (connector config) or SCIM_TOKEN_URL (.env)")

    cache_key = f"{effective_token_url}:{client_id}"
    now_ms = time.time() * 1000
    cached = _token_cache.get(cache_key)
    if cached and now_ms < cached["expiresAt"] - 60_000:
        return cached["token"]

    async with httpx.AsyncClient(timeout=30,verify=False) as client:
        resp = await client.post(
            effective_token_url,
            data={
                "grant_type": "client_credentials",
                "client_id": client_id,
                "client_secret": client_secret,
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
    resp.raise_for_status()
    body = resp.json()
    _token_cache[cache_key] = {"token": body["access_token"], "expiresAt": time.time() * 1000 + body["expires_in"] * 1000}
    return _token_cache[cache_key]["token"]


async def _get_archer_session_token(
    login_url: str,
    instance_name: str,
    username: str,
    password: str,
    user_domain: str = "",
) -> str:
    """Logs in to Archer GRC's authentication API with
    {InstanceName, Username, Password, UserDomain} and returns the session token found at
    response.RequestObject.SessionToken. Cached per (loginUrl, instanceName, username) for
    ARCHER_SESSION_TTL_MS, since Archer sessions are reusable until they expire/idle out."""
    if not login_url:
        raise RuntimeError("Missing archerLoginUrl (connector config) or ARCHER_LOGIN_URL (.env)")

    cache_key = f"{login_url}:{instance_name}:{username}"
    now_ms = time.time() * 1000
    cached = _archer_session_cache.get(cache_key)
    if cached and now_ms < cached["expiresAt"]:
        return cached["token"]

    async with httpx.AsyncClient(timeout=30, verify=False) as client:
        resp = await client.post(
            login_url,
            json={
                "InstanceName": instance_name,
                "Username": username,
                "Password": password,
                "UserDomain": user_domain,
            },
            headers={"Content-Type": "application/json", "Accept": "application/json"},
        )
    resp.raise_for_status()
    body = resp.json()
    token = ((body.get("RequestedObject") or {}).get("SessionToken"))
    if not token:
        raise RuntimeError(f"Archer login response missing RequestObject.SessionToken: {body}")
    _archer_session_cache[cache_key] = {"token": token, "expiresAt": now_ms + ARCHER_SESSION_TTL_MS}
    return token


async def build_auth_headers(
    auth_type: Optional[str] = None,
    auth_token: Optional[str] = None,
    auth_user: Optional[str] = None,
    auth_password: Optional[str] = None,
    auth_header_name: Optional[str] = None,
    client_id: Optional[str] = None,
    client_secret: Optional[str] = None,
    scim_token_url: Optional[str] = None,
    archer_login_url: Optional[str] = None,
    archer_instance_name: Optional[str] = None,
    archer_user_domain: Optional[str] = None,
) -> dict:
    effective_type = (auth_type or settings.WEBSERVICE_AUTH_TYPE or "none").lower()
    effective_token = auth_token if auth_token is not None else settings.WEBSERVICE_AUTH_TOKEN

    if effective_type == "bearer":
        if client_id and client_secret:
            token = await _get_scim_bearer_token(client_id, client_secret, scim_token_url)
        else:
            token = effective_token
        return {"Authorization": f"Bearer {token}"}
    if effective_type == "apikey":
        header_name = auth_header_name or settings.WEBSERVICE_AUTH_HEADER_NAME or "X-API-Key"
        return {header_name: effective_token}
    if effective_type == "basic":
        effective_user = auth_user if auth_user is not None else settings.WEBSERVICE_AUTH_USER
        effective_password = auth_password if auth_password is not None else settings.WEBSERVICE_AUTH_PASSWORD
        token = base64.b64encode(f"{effective_user}:{effective_password}".encode()).decode()
        return {"Authorization": f"Basic {token}"}
    if effective_type == "archer":
        effective_login_url = archer_login_url or settings.ARCHER_LOGIN_URL
        effective_instance_name = archer_instance_name if archer_instance_name is not None else settings.ARCHER_INSTANCE_NAME
        effective_user = auth_user if auth_user is not None else settings.ARCHER_USERNAME
        effective_password = auth_password if auth_password is not None else settings.ARCHER_PASSWORD
        effective_user_domain = archer_user_domain if archer_user_domain is not None else settings.ARCHER_USER_DOMAIN
        token = await _get_archer_session_token(
            effective_login_url, effective_instance_name, effective_user, effective_password, effective_user_domain
        )
        return {"Authorization": f'Archer session-Id="{token}"'}
    return {}


def fill_template(template: str, params: dict) -> str:
    return re.sub(r"\{(\w+)\}", lambda m: quote(str(params.get(m.group(1)) or "")), template)


async def check_access(
    user_login: str,
    entitlement_value: str,
    endpoint_template: Optional[str] = None,
    response_path: Optional[str] = None,
    expected=None,
    proxy_url: Optional[str] = None,
    base_url: Optional[str] = None,
    auth_type: Optional[str] = None,
    auth_token: Optional[str] = None,
    auth_user: Optional[str] = None,
    auth_password: Optional[str] = None,
    auth_header_name: Optional[str] = None,
    scim_external_id: Optional[str] = None,
    client_id: Optional[str] = None,
    client_secret: Optional[str] = None,
    role_id_field: Optional[str] = None,
    parser_type: Optional[str] = None,
    user_match_field: Optional[str] = None,
    roles_field: Optional[str] = None,
    scim_token_url: Optional[str] = None,
    composite_fields: Optional[list] = None,
    composite_separator: Optional[str] = None,
    archer_login_url: Optional[str] = None,
    archer_instance_name: Optional[str] = None,
    archer_user_domain: Optional[str] = None,
) -> dict:
    effective_base_url = base_url or settings.WEBSERVICE_BASE_URL
    if not effective_base_url:
        raise RuntimeError("Missing baseUrl (connector config) or WEBSERVICE_BASE_URL (.env)")
    if not endpoint_template:
        raise RuntimeError("Web service connector config must define an endpointTemplate")

    effective_login = scim_external_id or user_login
    filled = fill_template(endpoint_template, {"userLogin": effective_login, "entitlementValue": entitlement_value})
    url = f"{effective_base_url.rstrip('/')}/{filled.lstrip('/')}"

    effective_proxy = proxy_url or settings.WEBSERVICE_PROXY_URL or None
    headers = {
        "Accept": "application/json",
        **await build_auth_headers(
            auth_type, auth_token, auth_user, auth_password, auth_header_name, client_id, client_secret, scim_token_url,
            archer_login_url, archer_instance_name, archer_user_domain,
        ),
    }

    async with httpx.AsyncClient(timeout=30, proxy=effective_proxy,verify=False) as client:
        resp = await client.get(url, headers=headers)

    if resp.status_code >= 400:
        return {"hasAccess": False, "status": resp.status_code, "detail": f"HTTP {resp.status_code} from {url}"}

    try:
        data = resp.json()
    except Exception:
        data = None

    result = entitlement_parser.match(
        data,
        entitlement_value,
        response_path=response_path,
        expected=expected,
        role_id_field=role_id_field,
        parser_type=parser_type,
        user_login=effective_login,
        user_match_field=user_match_field,
        roles_field=roles_field,
        composite_fields=composite_fields,
        composite_separator=composite_separator,
    )
    return {**result, "status": resp.status_code, "scimExternalId": scim_external_id}
