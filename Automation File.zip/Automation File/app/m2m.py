import base64
import time
import uuid
from typing import Optional

import httpx
import jwt

from app import settings

_cached_token: Optional[str] = None
_token_expires_at: float = 0.0


async def get_m2m_token() -> str:
    global _cached_token, _token_expires_at

    now_ms = time.time() * 1000
    if _cached_token and now_ms < _token_expires_at - 60_000:
        return _cached_token

    if not settings.OKTA_ISSUER_URL or not settings.OKTA_M2M_CLIENT_ID or not settings.OKTA_PRIVATE_KEY_BASE64:
        raise RuntimeError(
            "Missing OKTA_ISSUER_URL, OKTA_M2M_CLIENT_ID, or OKTA_PRIVATE_KEY_BASE64 for M2M auth"
        )

    org_url = settings.okta_org_url()
    token_url = f"{org_url}/oauth2/v1/token"

    private_key_pem = base64.b64decode(settings.OKTA_PRIVATE_KEY_BASE64).decode("utf-8")

    now = int(time.time())
    claims = {
        "iss": settings.OKTA_M2M_CLIENT_ID,
        "sub": settings.OKTA_M2M_CLIENT_ID,
        "aud": token_url,
        "iat": now,
        "exp": now + 5 * 60,
        "jti": str(uuid.uuid4()),
    }
    headers = {"kid": settings.OKTA_KEY_ID} if settings.OKTA_KEY_ID else None
    client_assertion = jwt.encode(claims, private_key_pem, algorithm="RS256", headers=headers)

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(
            token_url,
            data={
                "grant_type": "client_credentials",
                "scope": settings.M2M_SCOPES,
                "client_assertion_type": "urn:ietf:params:oauth:client-assertion-type:jwt-bearer",
                "client_assertion": client_assertion,
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )

    if resp.status_code >= 400:
        raise RuntimeError(f"M2M token request failed ({resp.status_code}): {resp.text}")

    body = resp.json()
    _cached_token = body["access_token"]
    _token_expires_at = time.time() * 1000 + body["expires_in"] * 1000
    return _cached_token
