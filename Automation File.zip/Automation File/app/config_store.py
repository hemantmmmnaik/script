import json
from typing import Optional

from app.settings import DATA_DIR

CONFIG_PATH = DATA_DIR / "config.json"


def has_config() -> bool:
    return CONFIG_PATH.exists()


def get_config() -> Optional[dict]:
    if not CONFIG_PATH.exists():
        return None
    return json.loads(CONFIG_PATH.read_text())


def save_config(data: dict) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(data, indent=2))


def clear_config() -> None:
    if CONFIG_PATH.exists():
        CONFIG_PATH.unlink()
