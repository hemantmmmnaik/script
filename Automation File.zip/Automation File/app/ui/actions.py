import time
from typing import Awaitable, Callable, Optional

from nicegui import app as nicegui_app

from app.services import connectors_service, entitlements_service, report_service, target_systems_service, users_service
from app.services.grant_logic import (
    GRANT_ACTION_LABELS,
    GRANT_TYPE_MAP,
    assigned_entitlement_ids,
    build_grant_body,
    grant_action_label,
    resolve_entitlement_value_codes,
)
from app.ui import state

__all__ = [
    "GRANT_ACTION_LABELS",
    "GRANT_TYPE_MAP",
    "assigned_entitlement_ids",
    "build_grant_body",
    "grant_action_label",
    "resolve_entitlement_value_codes",
    "run_target_system_check",
    "revalidate_target_system",
    "write_with_verification",
    "run_queue",
]


async def run_target_system_check(entry_id: str, app_id: str, verify: dict) -> None:
    state.update_log_entry(entry_id, {"targetSystemCheck": {"status": "checking"}})
    try:
        result = await target_systems_service.validate(
            app_id, verify["userLogin"], verify["entitlementValueCodes"], user_id=verify.get("userId")
        )
        state.update_log_entry(entry_id, {"targetSystemCheck": {"status": "done", **result}})
    except Exception as exc:
        state.update_log_entry(entry_id, {"targetSystemCheck": {"status": "error", "error": str(exc)}})


async def revalidate_target_system(entry_id: str) -> None:
    entry = next((e for e in state.get_activity_log() if e["id"] == entry_id), None)
    if not entry:
        return
    verify = entry.get("verify")
    if not verify or not verify.get("userLogin") or not verify.get("entitlementValueCodes"):
        return
    await run_target_system_check(entry_id, entry["appId"], verify)


async def write_with_verification(
    action: str,
    app_id: str,
    app_name: Optional[str],
    target: Optional[str],
    api_call: Callable[[], Awaitable],
    request_info: Optional[dict] = None,
    verify: Optional[dict] = None,
    expires_at: Optional[str] = None,
):
    entry_id = state.new_id()
    entry = {
        "id": entry_id,
        "ts": int(time.time() * 1000) - 5000,
        "action": action,
        "appName": app_name,
        "appId": app_id,
        "target": target,
        "expiresAt": expires_at,
        "status": "pending",
        "requestInfo": request_info,
        "apiResponse": None,
        "error": None,
        "verify": verify,
        "targetSystemCheck": None,
    }
    state.append_log(entry)

    try:
        result = await api_call()
        state.update_log_entry(entry_id, {"status": "success", "apiResponse": result})
        configs = state.get_target_system_configs()
        if verify and verify.get("userLogin") and verify.get("entitlementValueCodes") and configs.get(app_id):
            await run_target_system_check(entry_id, app_id, verify)
        return result
    except Exception as exc:
        state.update_log_entry(entry_id, {"status": "error", "error": str(exc)})
        raise


async def _execute_one(action: dict) -> None:
    app_id = action["appId"]
    app_name = action.get("appName")
    user_id = action.get("userId")
    action_type = action.get("actionType")

    if action_type == "revoke-all":
        await write_with_verification(
            action="revoke-all",
            app_id=app_id,
            app_name=app_name,
            target=action.get("userDisplay"),
            api_call=lambda: entitlements_service.revoke_all(user_id, app_id),
            request_info={"method": "POST", "url": "/revoke-all", "body": {"userId": user_id, "appId": app_id}},
        )
        return

    if action_type == "revoke-grant":
        await write_with_verification(
            action=f"revoke-{action.get('revokeGrantType')}",
            app_id=app_id,
            app_name=app_name,
            target=action.get("targetName"),
            api_call=lambda: entitlements_service.delete_grant(
                action["grantId"],
                grant_type=action.get("revokeGrantType"),
                app_id=app_id,
                user_id=user_id,
                entitlement_bundle_id=action.get("entitlementBundleId"),
                hard_delete=True,
            ),
            request_info={"method": "DELETE", "url": f"/grants/{action['grantId']}"},
        )
        return

    if action_type == "lifecycle":
        lifecycle_action = action.get("lifecycleAction")
        if lifecycle_action == "remove-from-app":
            api_call = lambda: connectors_service.remove_user_from_app(app_id, user_id)
        elif lifecycle_action == "assign-app-custom":
            api_call = lambda: connectors_service.assign_user_to_app(app_id, user_id)
        elif lifecycle_action == "assign-app-group":
            api_call = lambda: connectors_service.assign_user_to_group(app_id, action.get("groupId"), user_id)
        else:
            api_call = lambda: users_service.run_lifecycle_action(user_id, lifecycle_action)

        await write_with_verification(
            action=lifecycle_action,
            app_id=app_id,
            app_name=app_name,
            target=action.get("userDisplay"),
            api_call=api_call,
            request_info={"method": "POST", "url": f"/lifecycle/{lifecycle_action}"},
        )
        return

    # grant actions: bundle / value / custom-ent / additive-ent / revert-policy
    body = build_grant_body(action)
    connector = state.get_connectors().get(app_id)
    codes = resolve_entitlement_value_codes(connector, action)
    verify = (
        {"userLogin": action.get("userLogin"), "userId": action.get("userId"), "entitlementValueCodes": codes}
        if action.get("userLogin")
        else None
    )

    await write_with_verification(
        action=grant_action_label(action),
        app_id=app_id,
        app_name=app_name,
        target=action.get("targetName"),
        expires_at=action.get("expiresAt"),
        api_call=lambda: entitlements_service.create_grant(body),
        request_info={"method": "POST", "url": "/grants", "body": body},
        verify=verify,
    )


async def run_queue() -> Optional[dict]:
    storage = nicegui_app.storage.user
    if storage.get("queue_running") or not state.get_action_queue():
        return None

    actions = list(state.get_action_queue())
    state.clear_queue()
    storage["queue_running"] = True
    results = []
    try:
        for action in actions:
            try:
                await _execute_one(action)
                ok, error = True, None
            except Exception as exc:
                ok, error = False, str(exc)  # already recorded by write_with_verification

            log = state.get_activity_log()
            entry = log[0] if log else {}
            tsc = entry.get("targetSystemCheck") or None
            if tsc and tsc.get("status") == "done":
                tsc_status, tsc_error = ("verified" if tsc.get("hasAccess") else "mismatch"), None
            elif tsc and tsc.get("status") == "error":
                tsc_status, tsc_error = "error", tsc.get("error")
            else:
                tsc_status, tsc_error = None, None

            results.append({
                "app": action.get("appName") or action.get("appId"),
                "action": entry.get("action") or action.get("actionType") or action.get("grantType"),
                "target": entry.get("target") or action.get("targetName"),
                "user": action.get("userDisplay") or action.get("userLogin"),
                "status": "success" if ok else "error",
                "error": error,
                "targetSystemCheck": tsc_status,
                "targetSystemCheckError": tsc_error,
            })
    finally:
        storage["queue_running"] = False

    if not results:
        return None
    report_path = report_service.write_queue_report(results)
    summary = {
        "path": str(report_path),
        "total": len(results),
        "succeeded": sum(1 for r in results if r["status"] == "success"),
        "failed": sum(1 for r in results if r["status"] != "success"),
    }
    return summary
