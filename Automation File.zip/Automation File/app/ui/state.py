import time
import uuid
from typing import Optional

from nicegui import app as nicegui_app

from app.services import target_systems_service

MAX_LOG_ENTRIES = 200


def new_id(prefix: str = "") -> str:
    stamp = int(time.time() * 1000)
    suffix = uuid.uuid4().hex[:6]
    return f"{prefix}{stamp}-{suffix}" if prefix else f"{stamp}-{suffix}"


def _storage() -> dict:
    return nicegui_app.storage.user


def get_user() -> Optional[dict]:
    return _storage().get("user")


def get_access_token() -> Optional[str]:
    return _storage().get("access_token")


def is_authenticated() -> bool:
    return get_user() is not None


def get_connectors() -> dict:
    return _storage().setdefault("connectors", {})


def get_connector_order() -> list:
    return _storage().setdefault("connector_order", [])


def get_selected_user() -> Optional[dict]:
    return _storage().get("selected_user")


def set_selected_user(user: Optional[dict]) -> None:
    _storage()["selected_user"] = user


def get_activity_log() -> list:
    return _storage().setdefault("activity_log", [])


def get_action_queue() -> list:
    return _storage().setdefault("action_queue", [])


def is_queue_running() -> bool:
    return bool(_storage().get("queue_running"))


def get_target_system_configs() -> dict:
    """target_systems.json is a shared server-side file, not per-browser-session data — always
    read it fresh rather than caching in app.storage.user (a per-session cache here would go
    stale: a new browser session, or the same one before ever opening the config modal, would
    see {} even though configs already exist on disk)."""
    return target_systems_service.read_all()


def refresh_target_system_configs() -> dict:
    return target_systems_service.read_all()


def add_connector(app: dict, skip_values: bool = False, skip_bundles: bool = False,
                   default_user: Optional[dict] = None) -> None:
    connectors = get_connectors()
    app_id = app["id"]
    if app_id in connectors:
        return
    connectors[app_id] = {
        "app": app,
        "status": "idle",
        "error": None,
        "entitlements": [],
        "bundles": [],
        "userGrants": [],
        "grantsStatus": "idle",
        "skipValues": skip_values,
        "skipBundles": skip_bundles,
        "defaultUser": default_user,
    }
    order = get_connector_order()
    if app_id not in order:
        order.append(app_id)


def remove_connector(app_id: str) -> None:
    get_connectors().pop(app_id, None)
    order = get_connector_order()
    if app_id in order:
        order.remove(app_id)


def update_connector(app_id: str, updates: dict) -> None:
    connectors = get_connectors()
    if app_id not in connectors:
        return
    connectors[app_id].update(updates)


def clear_all_connectors() -> None:
    _storage()["connectors"] = {}
    _storage()["connector_order"] = []


def append_log(entry: dict) -> dict:
    log = get_activity_log()
    log.insert(0, entry)
    del log[MAX_LOG_ENTRIES:]
    return entry


def update_log_entry(entry_id: str, updates: dict) -> None:
    for entry in get_activity_log():
        if entry["id"] == entry_id:
            entry.update(updates)
            return


def clear_activity_log() -> None:
    _storage()["activity_log"] = []


def clear_app_log(app_id: str) -> None:
    _storage()["activity_log"] = [e for e in get_activity_log() if e.get("appId") != app_id]


def add_to_queue(action: dict) -> dict:
    action = {**action, "id": new_id("q-")}
    get_action_queue().append(action)
    return action


def remove_from_queue(action_id: str) -> None:
    _storage()["action_queue"] = [a for a in get_action_queue() if a["id"] != action_id]


def clear_queue() -> None:
    _storage()["action_queue"] = []
