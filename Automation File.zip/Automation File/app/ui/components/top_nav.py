from typing import Callable, Optional

from nicegui import ui

from app.ui import state


def top_nav(right_content: Optional[Callable[[], None]] = None) -> None:
    with ui.row().classes("w-full items-center justify-between px-4 py-2 bg-white shadow-sm"):
        with ui.row().classes("items-center gap-2 cursor-pointer").on("click", lambda: ui.navigate.to("/connectors")):
            ui.icon("hub", color="indigo").classes("text-2xl")
            ui.label("Multi-Connector Tester").classes("font-bold text-lg")

        with ui.row().classes("items-center gap-4"):
            if right_content:
                right_content()
            user = state.get_user()
            if user:
                ui.label(user.get("email") or user.get("name") or "").classes("text-sm text-gray-600")
                ui.link("Sign out", "/auth/logout").classes("text-sm text-indigo-600")
