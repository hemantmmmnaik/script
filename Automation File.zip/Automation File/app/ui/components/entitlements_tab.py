from nicegui import ui

from app.ui import state
from app.ui.components.grant_modals import add_value_modal


@ui.refreshable
def entitlements_tab(app_id: str) -> None:
    connector = state.get_connectors().get(app_id)
    if not connector or connector.get("status") != "loaded":
        ui.label("Loading entitlements…" if connector and connector.get("status") == "loading" else "Connector not loaded.").classes(
            "text-gray-400 text-center py-8 w-full"
        )
        return

    entitlements = connector.get("entitlements", [])
    if not entitlements:
        ui.label("No entitlements found for this app.").classes("text-gray-400 text-center py-8 w-full")
        return

    def handle_created(entitlement_id: str, new_value: dict) -> None:
        updated = [
            {**e, "values": [*(e.get("values", []) or []), new_value]} if e["id"] == entitlement_id else e
            for e in connector["entitlements"]
        ]
        state.update_connector(app_id, {"entitlements": updated})
        entitlements_tab.refresh()

    for ent in entitlements:
        with ui.expansion().classes("w-full border rounded mb-2") as exp:
            with exp.add_slot("header"):
                with ui.row().classes("items-center justify-between w-full pr-2"):
                    with ui.column().classes("gap-0"):
                        ui.label(ent.get("name")).classes("font-semibold")
                        if ent.get("description"):
                            ui.label(ent["description"]).classes("text-xs text-gray-500")
                    ui.button(
                        "+ Add Value",
                        on_click=lambda e=ent: add_value_modal(e, lambda v, eid=e["id"]: handle_created(eid, v)),
                    ).props("size=sm outline").on("click.stop", lambda: None)

            values = ent.get("values", []) or []
            if not values:
                ui.label("No values yet").classes("text-xs text-gray-400 py-2")
            else:
                with ui.row().classes("gap-2 flex-wrap py-2"):
                    for v in values:
                        ui.chip(v.get("name")).props("dense")
