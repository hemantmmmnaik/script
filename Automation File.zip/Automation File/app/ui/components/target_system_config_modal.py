from typing import Callable

from nicegui import ui

from app import settings
from app.services import target_systems_service
from app.ui import state

TYPE_LABELS = {
    "": "Not configured",
    "AD": "Active Directory (LDAPS group membership)",
    "ENTRAID": "EntraID (Graph group membership)",
    "ORACLE": "Oracle DB",
    "MSSQL": "MSSQL DB",
    "WEBSERVICE": "Web Service (generic REST)",
}

PARSER_TYPE_LABELS = {
    "auto": "Auto-detect (default)",
    "list": "List of objects",
    "bool": "Boolean flag",
    "scalar": "Scalar value",
    "userRoleList": "List of users with roles",
    "compositeList": "List of objects, composite value (e.g. region-groupName)",
}


def target_system_config_modal(app_id: str, app_name: str, on_saved: Callable[[], None]) -> None:
    existing = target_systems_service.get_for_app(app_id) or {}
    fields = {
        "type": existing.get("type", ""),
        "query": existing.get("query", ""),
        "procedure": existing.get("procedure", ""),
        "endpointTemplate": existing.get("endpointTemplate", ""),
        "responsePath": existing.get("responsePath", ""),
        "expected": existing.get("expected", ""),
        "proxyUrl": existing.get("proxyUrl", ""),
        "baseUrl": existing.get("baseUrl", ""),
        "authType": existing.get("authType", ""),
        "authToken": existing.get("authToken", ""),
        "authUser": existing.get("authUser", ""),
        "authPassword": existing.get("authPassword", ""),
        "authHeaderName": existing.get("authHeaderName", ""),
        "clientId": existing.get("clientId", ""),
        "clientSecret": existing.get("clientSecret", ""),
        "roleIdField": existing.get("roleIdField", ""),
        "parserType": existing.get("parserType", "auto"),
        "userMatchField": existing.get("userMatchField", ""),
        "rolesField": existing.get("rolesField", ""),
        "compositeFields": ",".join(existing.get("compositeFields") or []),
        "compositeSeparator": existing.get("compositeSeparator", ""),
        "scimTokenUrl": existing.get("scimTokenUrl", ""),
        "externalIdField": existing.get("externalIdField", ""),
        "archerLoginUrl": existing.get("archerLoginUrl", ""),
        "archerInstanceName": existing.get("archerInstanceName", ""),
        "archerUserDomain": existing.get("archerUserDomain", ""),
    }

    dialog = ui.dialog()
    with dialog, ui.card().classes("w-full max-w-xl"):
        ui.label(f"Target System — {app_name}").classes("text-lg font-bold")
        error_label = ui.label("").classes("text-red-600")
        error_label.visible = False

        body_container = ui.column().classes("w-full gap-2")

        def bind(key: str, widget) -> None:
            widget.on_value_change(lambda e, k=key: fields.__setitem__(k, e.value))

        def render_body() -> None:
            body_container.clear()
            with body_container:
                type_select = ui.select(TYPE_LABELS, value=fields["type"], label="Target System Type").classes("w-full")

                def on_type_change(e) -> None:
                    fields["type"] = e.value
                    render_body()

                type_select.on_value_change(on_type_change)

                t = fields["type"]
                if t in ("AD", "ENTRAID"):
                    attr = "AD_USER_SEARCH_ATTR" if t == "AD" else "ENTRAID_USER_MATCH_ATTR"
                    ui.label(
                        f"No extra fields needed — the Okta user's login is matched against {attr}, "
                        "and the entitlement's raw value is matched against the group name."
                    ).classes("text-xs text-gray-500")
                elif t in ("ORACLE", "MSSQL"):
                    bind("procedure", ui.input("Stored Procedure (optional)", value=fields["procedure"]).classes("w-full"))
                    bind("query", ui.textarea("SQL Query (used if no procedure is set)", value=fields["query"]).classes("w-full"))
                    bind_prefix = ":" if t == "ORACLE" else "@"
                    ui.label(
                        f"Procedure contract: IN (userLogin, entitlementValue), OUT hasAccess "
                        f"({'NUMBER 1/0' if t == 'ORACLE' else 'BIT'}). Query contract: named binds "
                        f"{bind_prefix}userLogin/{bind_prefix}entitlementValue — a matching row means access exists."
                    ).classes("text-xs text-gray-400")
                elif t == "WEBSERVICE":
                    ui.label(
                        "Every field below is per-connector. Leave blank to fall back to WEBSERVICE_* in .env."
                    ).classes("text-xs text-gray-400")
                    bind("baseUrl", ui.input("Base URL (optional)", value=fields["baseUrl"], placeholder="https://api.example.com").classes("w-full"))
                    bind("endpointTemplate", ui.input("Endpoint Template *", value=fields["endpointTemplate"], placeholder="users/{userLogin}/entitlements").classes("w-full"))
                    bind("responsePath", ui.input("Response JSON Path", value=fields["responsePath"], placeholder="data.roles").classes("w-full"))
                    bind("expected", ui.input("Expected Value (optional)", value=fields["expected"]).classes("w-full"))
                    bind(
                        "parserType",
                        ui.select(PARSER_TYPE_LABELS, value=fields["parserType"] or "auto", label="Entitlement Parser").classes("w-full"),
                    )
                    ui.label(
                        "Controls how the value at the response path is read as an entitlement: a list of role "
                        "objects, a single true/false flag, or a single scalar value. Auto-detect infers this from "
                        "the response's shape."
                    ).classes("text-xs text-gray-400")
                    bind("roleIdField", ui.input("Role ID Field (default: RoleId)", value=fields["roleIdField"], placeholder="RoleId").classes("w-full"))
                    ui.label(
                        "Only used when the entitlement parser resolves to a list of role objects — the key read "
                        "off each object and compared against the Okta entitlement value."
                    ).classes("text-xs text-gray-400")
                    bind(
                        "externalIdField",
                        ui.input(
                            "SCIM External ID Field (default: externalId)",
                            value=fields["externalIdField"],
                            placeholder="externalId or profile.email",
                        ).classes("w-full"),
                    )
                    ui.label(
                        "The field read off the Okta SCIM app-user assignment to identify this user in the "
                        "downstream system; used in place of the Okta login when calling the endpoint, if present. "
                        "Supports dotted paths into nested fields, e.g. profile.email."
                    ).classes("text-xs text-gray-400")
                    bind("userMatchField", ui.input("User Match Field (default: userName)", value=fields["userMatchField"], placeholder="userName").classes("w-full"))
                    bind("rolesField", ui.input("Roles Field (default: userRoles)", value=fields["rolesField"], placeholder="userRoles").classes("w-full"))
                    ui.label(
                        "Only used for the \"List of users with roles\" parser — the response path resolves to a "
                        "list of user records; the record whose User Match Field equals this user's login is found, "
                        "then its Roles Field is checked for the Okta entitlement value."
                    ).classes("text-xs text-gray-400")
                    bind(
                        "compositeFields",
                        ui.input(
                            "Composite Fields (default: region,groupName)",
                            value=fields["compositeFields"],
                            placeholder="region,groupName",
                        ).classes("w-full"),
                    )
                    bind(
                        "compositeSeparator",
                        ui.input("Composite Separator (default: -)", value=fields["compositeSeparator"], placeholder="-").classes("w-full"),
                    )
                    ui.label(
                        "Only used for the \"List of objects, composite value\" parser — the entitlement value "
                        "(e.g. us-agent) is split by the separator into ordered parts and matched against these "
                        "fields on each object in the response path's list (e.g. region=us, groupName=agent)."
                    ).classes("text-xs text-gray-400")
                    auth_select = ui.select(
                        {
                            "": "(use .env default)",
                            "none": "None",
                            "bearer": "Bearer Token (OAuth client credentials)",
                            "apikey": "API Key Header",
                            "basic": "Basic Auth",
                            "archer": "Archer GRC Session Auth",
                        },
                        value=fields["authType"],
                        label="Auth Type",
                    ).classes("w-full")

                    def on_auth_change(e) -> None:
                        fields["authType"] = e.value
                        render_body()

                    auth_select.on_value_change(on_auth_change)

                    if fields["authType"] == "bearer":
                        bind("clientId", ui.input("Client ID", value=fields["clientId"]).classes("w-full"))
                        bind("clientSecret", ui.input("Client Secret", password=True, value=fields["clientSecret"]).classes("w-full"))
                        bind(
                            "scimTokenUrl",
                            ui.input(
                                "SCIM Token URL",
                                value=fields["scimTokenUrl"],
                                placeholder=settings.SCIM_TOKEN_URL or "(SCIM_TOKEN_URL not set in .env)",
                            ).classes("w-full"),
                        )
                        ui.label(
                            "Fetches a bearer token via OAuth client_credentials using these credentials. Leave blank "
                            "to use SCIM_TOKEN_URL from .env."
                        ).classes("text-xs text-gray-400")
                    if fields["authType"] == "apikey":
                        bind("authToken", ui.input("API Key", password=True, value=fields["authToken"]).classes("w-full"))
                        bind("authHeaderName", ui.input("Header Name (default X-API-Key)", value=fields["authHeaderName"]).classes("w-full"))
                    if fields["authType"] == "basic":
                        bind("authUser", ui.input("Username", value=fields["authUser"]).classes("w-full"))
                        bind("authPassword", ui.input("Password", password=True, value=fields["authPassword"]).classes("w-full"))
                    if fields["authType"] == "archer":
                        bind(
                            "archerLoginUrl",
                            ui.input(
                                "Archer Login URL",
                                value=fields["archerLoginUrl"],
                                placeholder=settings.ARCHER_LOGIN_URL or "https://archer.example.com/RSAarcher/api/core/security/login",
                            ).classes("w-full"),
                        )
                        bind("archerInstanceName", ui.input("Instance Name", value=fields["archerInstanceName"]).classes("w-full"))
                        bind("authUser", ui.input("Username", value=fields["authUser"]).classes("w-full"))
                        bind("authPassword", ui.input("Password", password=True, value=fields["authPassword"]).classes("w-full"))
                        bind("archerUserDomain", ui.input("User Domain (optional)", value=fields["archerUserDomain"]).classes("w-full"))
                        ui.label(
                            "Logs in with {InstanceName, Username, Password, UserDomain}, reads the session token off "
                            "response.RequestObject.SessionToken, and sends it as "
                            'Authorization: Archer session-Id="<token>" on every request. Leave a field blank to fall '
                            "back to its ARCHER_* .env default."
                        ).classes("text-xs text-gray-400")
                    bind("proxyUrl", ui.input("Proxy URL (optional)", value=fields["proxyUrl"], placeholder="http://proxy.corp:8080").classes("w-full"))
                    ui.label(
                        "Auth secrets entered here are stored in data/targetSystems.json (gitignored, local to this server) — not in .env."
                    ).classes("text-xs text-gray-400")

        render_body()

        def handle_save() -> None:
            t = fields["type"]
            if not t:
                error_label.text = "Select a type"
                error_label.visible = True
                return
            config = {"type": t}
            if t in ("ORACLE", "MSSQL"):
                if fields["procedure"]:
                    config["procedure"] = fields["procedure"]
                else:
                    config["query"] = fields["query"]
            elif t == "WEBSERVICE":
                for key in ("endpointTemplate", "responsePath", "expected", "roleIdField", "userMatchField", "rolesField", "externalIdField", "proxyUrl", "baseUrl", "authType", "authToken", "authUser", "authPassword", "authHeaderName", "clientId", "clientSecret", "scimTokenUrl", "compositeSeparator", "archerLoginUrl", "archerInstanceName", "archerUserDomain"):
                    if fields[key]:
                        config[key] = fields[key]
                if fields["parserType"] and fields["parserType"] != "auto":
                    config["parserType"] = fields["parserType"]
                if fields["compositeFields"]:
                    config["compositeFields"] = [f.strip() for f in fields["compositeFields"].split(",") if f.strip()]
            try:
                target_systems_service.set_for_app(app_id, config)
                state.refresh_target_system_configs()
                on_saved()
                dialog.close()
            except Exception as exc:
                error_label.text = str(exc)
                error_label.visible = True

        def handle_remove() -> None:
            target_systems_service.remove_for_app(app_id)
            state.refresh_target_system_configs()
            on_saved()
            dialog.close()

        with ui.row().classes("justify-between items-center w-full mt-3"):
            if existing:
                ui.button("Remove Config", on_click=handle_remove).props("flat size=sm")
            else:
                ui.element("span")
            with ui.row().classes("gap-2"):
                ui.button("Cancel", on_click=dialog.close).props("flat")
                ui.button("Save", on_click=handle_save).props("color=primary")

    dialog.open()
