from nicegui import ui

from app.ui import actions, state
from app.ui.components.activity_log import activity_log

BADGE_LABELS = {
    "revoke-grant": "Revoke",
    "bundle": "Bundle",
    "custom-ent": "Custom Ent",
    "additive-ent": "Additive Ent",
}


def _badge_label(action: dict) -> str:
    if action.get("actionType") == "revoke-grant":
        return "Revoke"
    if action.get("actionType") == "lifecycle":
        return action.get("lifecycleAction", "Lifecycle")
    return BADGE_LABELS.get(action.get("grantType"), "Value")


@ui.refreshable
def test_queue() -> None:
    queue = state.get_action_queue()
    running = state.is_queue_running()

    if not queue and not running:
        return

    with ui.card().classes("w-full"):
        with ui.row().classes("items-center justify-between w-full"):
            with ui.row().classes("items-center gap-2"):
                ui.label("Test Queue").classes("font-bold")
                ui.badge(f"{len(queue)} action{'s' if len(queue) != 1 else ''}").props("color=blue")
            with ui.row().classes("gap-2"):
                ui.button("Clear", on_click=lambda: (state.clear_queue(), test_queue.refresh())).props(
                    "flat size=sm"
                ).set_enabled(not running)

                async def run_all() -> None:
                    test_queue.refresh()
                    summary = await actions.run_queue()
                    test_queue.refresh()
                    activity_log.refresh()
                    if summary:
                        ui.notify(
                            f"Queue finished — {summary['succeeded']} succeeded, {summary['failed']} failed. "
                            f"Report saved to {summary['path']}",
                            type="warning" if summary["failed"] else "positive",
                            multi_line=True,
                            timeout=10000,
                        )

                ui.button(
                    "Running…" if running else f"▶ Run All ({len(queue)})",
                    on_click=run_all,
                ).props("color=primary size=sm").set_enabled(not running and len(queue) > 0)

        for i, action in enumerate(queue):
            with ui.row().classes("items-center gap-2 w-full border-t py-1"):
                ui.label(str(i + 1)).classes("text-xs text-gray-400 w-4")
                ui.label(action.get("appName") or "").classes("text-sm w-32 truncate")
                ui.icon("arrow_forward", size="xs")
                with ui.row().classes("items-center gap-1 flex-1 min-w-0"):
                    ui.badge(_badge_label(action)).props("color=grey")
                    ui.label(action.get("targetName") or "").classes("text-sm truncate")
                ui.icon("arrow_forward", size="xs")
                ui.label(f"👤 {action.get('userDisplay') or ''}").classes("text-sm w-40 truncate")
                ui.button(
                    icon="close",
                    on_click=lambda a=action: (state.remove_from_queue(a["id"]), test_queue.refresh()),
                ).props("flat dense round size=sm").set_enabled(not running)
