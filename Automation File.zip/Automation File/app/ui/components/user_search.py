import asyncio
from typing import Callable, Optional

from nicegui import ui

from app.services import connectors_service
from app.ui import state


def user_search(
    on_select: Callable[[Optional[dict]], None],
    initial: Optional[dict] = None,
    placeholder: str = "Search users...",
) -> ui.element:
    """Debounced user typeahead. Renders a selected-user chip once a user is picked."""
    container = ui.column().classes("gap-1")
    box = {"selected": initial, "task": None}

    def select(user: Optional[dict]) -> None:
        box["selected"] = user
        render()
        on_select(user)

    def render() -> None:
        container.clear()
        with container:
            if box["selected"]:
                profile = box["selected"].get("profile", {})
                label = profile.get("login") or profile.get("email") or box["selected"].get("id", "")
                with ui.row().classes("items-center gap-1 bg-indigo-50 rounded px-2 py-1"):
                    ui.label(label).classes("text-sm")
                    ui.button(icon="close", on_click=lambda: select(None)).props("flat dense round size=sm")
                return

            search_input = ui.input(placeholder=placeholder).classes("w-full")
            results = ui.column().classes("gap-0 border rounded max-h-48 overflow-auto bg-white")
            results.visible = False
            spinner = ui.spinner(size="sm")
            spinner.visible = False

            async def do_search(q: str) -> None:
                if len(q) < 2:
                    results.visible = False
                    return
                spinner.visible = True
                try:
                    users = await connectors_service.search_users(state.get_access_token(), q)
                except Exception:
                    users = []
                spinner.visible = False
                results.clear()
                with results:
                    if not users:
                        ui.label("No matches").classes("px-2 py-1 text-sm text-gray-400")
                    for u in users[:10]:
                        profile = u.get("profile", {})
                        label = f"{profile.get('login', '')} — {profile.get('firstName', '')} {profile.get('lastName', '')}"
                        ui.label(label).classes("px-2 py-1 hover:bg-gray-100 cursor-pointer text-sm").on(
                            "click", lambda u=u: select(u)
                        )
                results.visible = True

            async def on_change() -> None:
                if box["task"]:
                    box["task"].cancel()

                async def run() -> None:
                    await asyncio.sleep(0.3)
                    await do_search(search_input.value or "")

                box["task"] = asyncio.create_task(run())

            search_input.on_value_change(lambda e: on_change())

    render()
    return container
