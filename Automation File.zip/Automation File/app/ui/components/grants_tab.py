from typing import Callable, Optional

from nicegui import ui

from app.services import entitlements_service
from app.ui import actions, state
from app.ui.components.activity_log import activity_log
from app.ui.components.grant_modals import grant_modal


def _find_pa_match(principal_access: Optional[dict], grant_id: str) -> Optional[dict]:
    if not principal_access:
        return None
    items = [principal_access.get("base")] + (principal_access.get("additional") or [])
    for item in items:
        if item and item.get("grant", {}).get("id") == grant_id:
            return item
    return None


@ui.refreshable
def grants_tab(app_id: str, principal_access: Optional[dict], on_grant_change: Callable[[], None]) -> None:
    connector = state.get_connectors().get(app_id)
    user = state.get_selected_user()

    if not user:
        with ui.column().classes("items-center w-full py-12 text-gray-400"):
            ui.icon("person", size="2rem")
            ui.label("Select a user from the top bar to view and manage grants.")
        return

    error_label = ui.label("").classes("text-red-600")
    error_label.visible = False

    async def do_grant(grant_body: dict) -> None:
        bundle_id = grant_body.get("entitlementBundleId")
        if bundle_id:
            target_label = next((b.get("name") for b in connector.get("bundles", []) if b["id"] == bundle_id), bundle_id)
            codes = actions.resolve_entitlement_value_codes(connector, {"grantType": "bundle", "targetId": bundle_id})
        else:
            ent_entry = (grant_body.get("entitlements") or [{}])[0]
            value_id = (ent_entry.get("values") or [{}])[0].get("id")
            all_values = [v for e in connector.get("entitlements", []) for v in e.get("values", []) or []]
            target_label = next((v.get("name") for v in all_values if v.get("id") == value_id), value_id)
            codes = actions.resolve_entitlement_value_codes(connector, {"grantType": "custom-ent", "entitlements": grant_body.get("entitlements")})

        verify = (
            {"userLogin": user["profile"]["login"], "userId": user["id"], "entitlementValueCodes": codes}
            if user.get("profile", {}).get("login") and codes
            else None
        )

        try:
            await actions.write_with_verification(
                action="Grant",
                app_id=app_id,
                app_name=connector.get("app", {}).get("label"),
                target=target_label or "Unknown",
                request_info={"method": "POST", "url": "/grants", "body": grant_body},
                verify=verify,
                api_call=lambda: entitlements_service.create_grant(grant_body),
            )
            on_grant_change()
        finally:
            grants_tab.refresh()
            activity_log.refresh()

    with ui.row().classes("justify-end gap-2 w-full mb-3"):
        ui.button(
            "Grant Value",
            on_click=lambda: grant_modal(
                "value", app_id, connector.get("entitlements", []), connector.get("bundles", []), user, do_grant,
                existing_grants=connector.get("userGrants", []),
            ),
        ).props("size=sm outline")
        ui.button(
            "Grant Bundle",
            on_click=lambda: grant_modal(
                "bundle", app_id, connector.get("entitlements", []), connector.get("bundles", []), user, do_grant,
                existing_grants=connector.get("userGrants", []),
            ),
        ).props("size=sm color=primary")

    if connector.get("grantsStatus") == "loading":
        ui.spinner(size="lg").classes("mx-auto my-8")
        return

    grants = connector.get("userGrants", []) or []
    if not grants:
        ui.label("No grants for this user on this app.").classes("text-gray-400 text-center py-8 w-full")
        return

    async def handle_revoke(grant: dict) -> None:
        pa_match = _find_pa_match(principal_access, grant["id"])
        bundle_id = None
        bundle_name = None
        if grant.get("grantType") == "ENTITLEMENT-BUNDLE":
            pa_bundle = next(
                (a for a in (principal_access.get("additional") or []) if a.get("grant", {}).get("id") == grant["id"]),
                None,
            ) if principal_access else None
            bundle_id = (pa_bundle or {}).get("bundle", {}).get("id")
            bundle_name = (pa_bundle or {}).get("bundle", {}).get("name")

        target_label = bundle_name or grant.get("grantType")

        if bundle_id:
            codes = actions.resolve_entitlement_value_codes(connector, {"grantType": "bundle", "targetId": bundle_id})
        else:
            codes = [
                v.get("name")
                for ent in grant.get("entitlements", []) or []
                for v in ent.get("values", []) or []
                if v.get("name")
            ]
        verify = (
            {"userLogin": user["profile"]["login"], "userId": user["id"], "entitlementValueCodes": codes}
            if user.get("profile", {}).get("login") and codes
            else None
        )

        try:
            await actions.write_with_verification(
                action=f"revoke-{target_label}",
                app_id=app_id,
                app_name=connector.get("app", {}).get("label"),
                target=target_label,
                api_call=lambda: entitlements_service.delete_grant(
                    grant["id"],
                    grant_type=grant.get("grantType"),
                    app_id=app_id,
                    user_id=user["id"],
                    entitlement_bundle_id=bundle_id,
                    hard_delete=True,
                ),
                request_info={"method": "DELETE", "url": f"/grants/{grant['id']}"},
                verify=verify,
            )
            on_grant_change()
        except Exception as exc:
            ui.notify(str(exc), type="negative")
        finally:
            grants_tab.refresh()
            activity_log.refresh()

    def revoke_button(grant: dict) -> None:
        ui.button("Revoke", on_click=lambda g=grant: handle_revoke(g)).props("size=sm color=negative outline")

    for grant in grants:
        grant_type = grant.get("grantType")

        if grant_type == "ENTITLEMENT-BUNDLE":
            pa_bundle = next(
                (a for a in (principal_access.get("additional") or []) if a.get("grant", {}).get("id") == grant["id"]),
                None,
            ) if principal_access else None
            bundle_name = (pa_bundle or {}).get("bundle", {}).get("name") or grant["id"]
            bundle_id = (pa_bundle or {}).get("bundle", {}).get("id")
            with ui.row().classes("items-center justify-between w-full border rounded p-2 mb-1"):
                with ui.column().classes("gap-0"):
                    ui.label(f"📦 {bundle_name}").classes("font-semibold text-sm")
                    with ui.row().classes("gap-2 items-center"):
                        if bundle_id:
                            ui.label(bundle_id).classes("text-xs text-gray-400 font-mono")
                        ui.badge("bundle").props("color=blue")
                revoke_button(grant)
            continue

        if grant_type in ("ENTITLEMENT", "CUSTOM"):
            pa_item = _find_pa_match(principal_access, grant["id"])
            ent_list = (pa_item or {}).get("entitlements", []) or []
            icon = "🎯" if grant_type == "CUSTOM" else "🔑"
            badge_label = "Custom" if grant_type == "CUSTOM" else "Additive"
            all_vals = [(v, ent) for ent in ent_list for v in (ent.get("values", []) or [])]
            if not all_vals:
                with ui.row().classes("items-center justify-between w-full border rounded p-2 mb-1"):
                    with ui.column().classes("gap-0"):
                        ui.label(f"{icon} {grant_type}").classes("text-sm text-gray-500")
                        ui.badge(badge_label).props("color=orange" if grant_type == "CUSTOM" else "color=blue")
                    revoke_button(grant)
                continue
            for val, ent in all_vals:
                with ui.row().classes("items-center justify-between w-full border rounded p-2 mb-1"):
                    with ui.column().classes("gap-0"):
                        ui.label(f"{icon} {val.get('name') or val.get('id')}").classes("font-semibold text-sm")
                        with ui.row().classes("gap-2 items-center"):
                            ui.label(val.get("id")).classes("text-xs text-gray-400 font-mono")
                            ui.label(f"· {ent.get('name')}").classes("text-xs text-gray-400")
                            ui.badge(badge_label).props("color=orange" if grant_type == "CUSTOM" else "color=blue")
                    revoke_button(grant)
            continue

        with ui.row().classes("items-center justify-between w-full border rounded p-2 mb-1"):
            with ui.column().classes("gap-0"):
                ui.label("↩️ Policy").classes("font-semibold text-sm")
                ui.label("Policy-driven access").classes("text-xs text-gray-400")
            revoke_button(grant)
