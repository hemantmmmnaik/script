from typing import Callable

from nicegui import ui

from app.ui import state

STATUS_DOT = {
    "idle": "gray",
    "loading": "blue",
    "loaded": "green",
    "error": "red",
}

TARGET_SYSTEM_LABELS = {
    "AD": "Active Directory",
    "ENTRAID": "EntraID",
    "ORACLE": "Oracle",
    "MSSQL": "MSSQL",
    "WEBSERVICE": "Web Service",
}


def connector_card(
    app_id: str,
    on_remove: Callable[[str], None],
    on_stage: Callable[[str], None],
    on_configure_target_system: Callable[[str], None],
) -> None:
    connector = state.get_connectors().get(app_id)
    if not connector:
        return

    app = connector["app"]
    status = connector.get("status", "idle")
    target_type = state.get_target_system_configs().get(app_id, {}).get("type")

    with ui.card().classes("w-72"):
        with ui.row().classes("items-center justify-between w-full"):
            with ui.row().classes("items-center gap-2 cursor-pointer min-w-0").on(
                "click", lambda: ui.navigate.to(f"/connectors/{app_id}")
            ):
                ui.avatar((app.get("label") or "?")[0].upper(), size="sm")
                ui.label(app.get("label")).classes("font-semibold truncate").tooltip(app.get("label"))
            ui.button(icon="close", on_click=lambda: on_remove(app_id)).props("flat dense round size=sm")

        with ui.row().classes("items-center gap-1"):
            ui.icon("circle", color=STATUS_DOT.get(status, "gray")).classes("text-xs")
            ui.label(status.capitalize())
            if status == "loading":
                ui.spinner(size="sm")

        if status == "error":
            ui.label(connector.get("error") or "").classes("text-red-600 text-xs").tooltip(connector.get("error") or "")

        if status == "loaded":
            entitlements = connector.get("entitlements", [])
            bundles = connector.get("bundles", [])
            total_values = sum(len(e.get("values", []) or []) for e in entitlements)

            if connector.get("skipBundles"):
                ui.label("bundles not loaded").classes("text-xs text-gray-400 italic")
            else:
                ui.label(f"{len(bundles)} bundle{'s' if len(bundles) != 1 else ''}").classes("text-xs")

            if connector.get("skipValues"):
                ui.label("values not loaded").classes("text-xs text-gray-400 italic")
            else:
                ui.label(f"{len(entitlements)} ent · {total_values} values").classes("text-xs")

            if connector.get("grantsStatus") == "loaded":
                grants = connector.get("userGrants", [])
                ui.label(f"{len(grants)} grant{'s' if len(grants) != 1 else ''}").classes("text-xs")

            default_user = connector.get("defaultUser")
            if default_user:
                profile = default_user.get("profile", {})
                ui.label(f"★ {profile.get('displayName') or profile.get('login')}").classes("text-xs text-gray-500 truncate")

            ui.button(
                f"🎯 {TARGET_SYSTEM_LABELS.get(target_type, target_type)}" if target_type else "🎯 Configure Target System",
                on_click=lambda: on_configure_target_system(app_id),
            ).props("flat size=sm").classes("w-full")

            ui.button("+ Stage Action", on_click=lambda: on_stage(app_id)).props("color=primary size=sm").classes("w-full")
