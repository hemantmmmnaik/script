import asyncio
from typing import Callable

from nicegui import ui

from app.services import connectors_service
from app.ui.components.user_search import user_search


def add_app_modal(on_add: Callable[[dict, dict], None], loaded_ids: list) -> None:
    """on_add(app, opts) where opts = {skip_values, skip_bundles, default_user}."""
    row_opts: dict = {}
    row_users: dict = {}
    box = {"task": None}

    dialog = ui.dialog()
    with dialog, ui.card().classes("w-full max-w-2xl"):
        ui.label("Add Application").classes("text-lg font-bold")
        search_input = ui.input(placeholder="Search for an Okta app…").classes("w-full")
        results = ui.column().classes("w-full max-h-96 overflow-auto gap-2 mt-2")

        def get_opts(app_id: str) -> dict:
            return row_opts.setdefault(app_id, {"entitlements": True, "bundles": True})

        async def do_search(q: str) -> None:
            results.clear()
            if not q.strip():
                with results:
                    ui.label("Start typing to search apps").classes("text-gray-400 text-sm text-center py-8 w-full")
                return
            try:
                apps = await connectors_service.search_apps(q)
            except Exception:
                apps = []
            results.clear()
            if not apps:
                with results:
                    ui.label("No apps found").classes("text-gray-400 text-sm text-center py-8 w-full")
                return
            with results:
                for app in apps[:12]:
                    already = app["id"] in loaded_ids
                    with ui.card().classes("w-full").style("opacity: 0.55" if already else ""):
                        with ui.row().classes("items-center gap-3 w-full"):
                            ui.avatar((app.get("label") or "?")[0].upper())
                            with ui.column().classes("flex-1 min-w-0 gap-0"):
                                ui.label(app.get("label")).classes("font-semibold text-sm truncate")
                                ui.label("Already added" if already else app.get("name")).classes("text-xs text-gray-400")
                            if not already:
                                opts = get_opts(app["id"])
                                ui.checkbox("Entitlements", value=opts["entitlements"]).on_value_change(
                                    lambda e, aid=app["id"]: get_opts(aid).update({"entitlements": e.value})
                                )
                                ui.checkbox("Bundles", value=opts["bundles"]).on_value_change(
                                    lambda e, aid=app["id"]: get_opts(aid).update({"bundles": e.value})
                                )
                                ui.button("Add →", on_click=lambda a=app: pick(a)).props("size=sm color=primary")
                            else:
                                ui.label("Added").classes("text-xs text-gray-400")
                        if not already:
                            user_search(lambda u, aid=app["id"]: row_users.update({aid: u}), placeholder="Default user for this app (optional)…")

        def pick(app: dict) -> None:
            opts = get_opts(app["id"])
            on_add(
                app,
                {
                    "skip_values": not opts["entitlements"],
                    "skip_bundles": not opts["bundles"],
                    "default_user": row_users.get(app["id"]),
                },
            )
            dialog.close()

        async def on_change() -> None:
            if box["task"]:
                box["task"].cancel()

            async def run() -> None:
                await asyncio.sleep(0.35)
                await do_search(search_input.value or "")

            box["task"] = asyncio.create_task(run())

        search_input.on_value_change(lambda e: on_change())

        with ui.row().classes("justify-between items-center w-full mt-2"):
            ui.label("Uncheck Entitlements to skip values — faster for apps with large catalogs.").classes(
                "text-xs text-gray-400"
            )
            ui.button("Cancel", on_click=dialog.close).props("flat")

    dialog.open()
