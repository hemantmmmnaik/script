import asyncio
from typing import Callable

from nicegui import ui

from app.services import connectors_service


def app_search(on_add: Callable[[dict, bool], None], loaded_ids: list) -> ui.element:
    """Sidebar app search. on_add(app, skip_values) — skip_values=True for the '📦 only' quick-add."""
    container = ui.column().classes("w-full gap-1 relative")
    box = {"task": None}

    with container:
        search_input = ui.input(placeholder="Search apps to add…").classes("w-full")
        results = ui.column().classes("w-full border rounded bg-white absolute z-50 max-h-64 overflow-auto")
        results.visible = False

        async def do_search(q: str) -> None:
            if not q.strip():
                results.visible = False
                return
            try:
                apps = await connectors_service.search_apps(q)
            except Exception:
                apps = []
            results.clear()
            with results:
                for app in apps[:12]:
                    already = app["id"] in loaded_ids
                    with ui.row().classes("items-center justify-between w-full px-2 py-1 hover:bg-gray-100").style(
                        "opacity: 0.5" if already else ""
                    ):
                        with ui.column().classes("gap-0 cursor-pointer flex-1 min-w-0").on(
                            "click", (lambda a=app: on_add(a, False)) if not already else (lambda: None)
                        ):
                            ui.label(app.get("label")).classes("text-sm font-medium truncate")
                            ui.label(f"{app.get('name')}{' · added' if already else ''}").classes("text-xs text-gray-400")
                        if not already:
                            ui.button("📦 only", on_click=lambda a=app: on_add(a, True)).props("dense size=sm outline")
            results.visible = True

        async def on_change() -> None:
            if box["task"]:
                box["task"].cancel()

            async def run() -> None:
                await asyncio.sleep(0.35)
                await do_search(search_input.value or "")

            box["task"] = asyncio.create_task(run())

        search_input.on_value_change(lambda e: on_change())

    return container
