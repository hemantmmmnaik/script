from typing import Callable

from nicegui import ui

from app.services import bulk_grant_service
from app.ui import state


def bulk_upload_modal(on_queued: Callable[[], None]) -> None:
    dialog = ui.dialog()
    with dialog, ui.card().classes("w-full max-w-lg"):
        ui.label("Bulk Upload — Add to Queue").classes("text-lg font-bold")
        ui.label(
            'xlsx with columns "appId", "entitlementValueName" (an entitlement value name or a bundle name), '
            '"userEmail", and optionally "action" (add/grant, or remove/revoke — defaults to add). One row per '
            "(app, name, user) triple. Add rows for the same app+user are grouped into a single queued grant "
            "(one per bundle name, plus one covering all entitlement value names); remove rows look up the "
            "user's existing grant on that app+name and queue a revoke of the whole grant record. Apps must "
            "already be added and loaded."
        ).classes("text-xs text-gray-500")
        error_label = ui.label("").classes("text-red-600 whitespace-pre-line")
        error_label.visible = False
        summary_label = ui.label("").classes("text-sm text-green-700")

        async def handle_upload(e) -> None:
            error_label.visible = False
            error_label.text = ""
            summary_label.text = ""

            try:
                content = await e.file.read()
                rows = bulk_grant_service.parse_rows(content)
            except Exception as exc:
                error_label.text = str(exc)
                error_label.visible = True
                return

            errors = []
            for row in rows:
                if row["action"] not in bulk_grant_service.ADD_ACTIONS and row["action"] not in bulk_grant_service.REMOVE_ACTIONS:
                    errors.append(f"row {row['rowNum']}: unknown action \"{row['action']}\" — skipped")
            rows = [
                r for r in rows
                if r["action"] in bulk_grant_service.ADD_ACTIONS or r["action"] in bulk_grant_service.REMOVE_ACTIONS
            ]

            actions, resolve_errors = await bulk_grant_service.resolve_rows_to_actions(rows, state.get_connectors())
            errors.extend(resolve_errors)
            for action in actions:
                state.add_to_queue(action)

            summary_label.text = f"Queued {len(actions)} action(s)."
            if errors:
                error_label.text = "\n".join(errors)
                error_label.visible = True
            on_queued()

        ui.upload(on_upload=handle_upload, auto_upload=True).props('accept=".xlsx"').classes("w-full")

        with ui.row().classes("justify-end w-full mt-2"):
            ui.button("Close", on_click=dialog.close).props("flat")

    dialog.open()
