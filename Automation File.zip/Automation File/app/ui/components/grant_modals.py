from typing import Awaitable, Callable, Optional

from nicegui import ui

from app.services import entitlements_service
from app.ui.actions import assigned_entitlement_ids


def add_value_modal(entitlement: dict, on_created: Callable[[dict], None]) -> None:
    dialog = ui.dialog()
    with dialog, ui.card().classes("w-full max-w-md"):
        ui.label(f'Add Value to "{entitlement.get("name")}"').classes("text-lg font-bold")
        error_label = ui.label("").classes("text-red-600")
        error_label.visible = False

        value_input = ui.input("Value *", placeholder="e.g. READ").classes("w-full")
        description_input = ui.input("Description", placeholder="optional").classes("w-full")

        async def submit() -> None:
            value = (value_input.value or "").strip()
            if not value:
                error_label.text = "Value is required"
                error_label.visible = True
                return
            try:
                result = await entitlements_service.create_entitlement_value(
                    entitlement["id"],
                    {"name": value, "description": (description_input.value or "").strip()},
                )
                on_created(result)
                dialog.close()
            except Exception as exc:
                error_label.text = str(exc)
                error_label.visible = True

        with ui.row().classes("justify-end w-full gap-2 mt-2"):
            ui.button("Cancel", on_click=dialog.close).props("flat")
            ui.button("Create Value", on_click=submit).props("color=primary")

    dialog.open()


def bundle_modal(
    app_id: str,
    all_values: list,
    on_saved: Callable[[dict], None],
    bundle: Optional[dict] = None,
) -> None:
    is_edit = bundle is not None
    selected: set = set()
    if is_edit:
        for ent in bundle.get("entitlements", []) or []:
            for v in ent.get("values", []) or []:
                if v.get("id"):
                    selected.add(v["id"])

    dialog = ui.dialog()
    with dialog, ui.card().classes("w-full max-w-lg"):
        ui.label(f'Edit Bundle: {bundle.get("name")}' if is_edit else "Create Bundle").classes("text-lg font-bold")
        error_label = ui.label("").classes("text-red-600")
        error_label.visible = False

        name_input = ui.input("Bundle Name *", value=bundle.get("name") if is_edit else "").classes("w-full")

        ui.label(f"Entitlement Values ({len(selected)} selected)").classes("font-semibold mt-2")
        with ui.scroll_area().classes("w-full h-64 border rounded"):
            if not all_values:
                ui.label("No values available").classes("text-gray-400 text-sm p-2")
            for v in all_values:
                label = v.get("name") or v.get("id")
                ent_name = v.get("_entitlementName", "")
                checkbox = ui.checkbox(f"{label} ({ent_name})", value=v.get("id") in selected)

                def on_change(e, value_id=v.get("id")):
                    if e.value:
                        selected.add(value_id)
                    else:
                        selected.discard(value_id)

                checkbox.on_value_change(on_change)

        async def submit() -> None:
            name = (name_input.value or "").strip()
            if not name:
                error_label.text = "Name is required"
                error_label.visible = True
                return
            body = {
                "name": name,
                "target": {"externalId": app_id, "type": "APPLICATION"},
                "entitlementValueIds": list(selected),
            }
            try:
                if is_edit:
                    result = await entitlements_service.update_bundle(bundle["id"], body)
                else:
                    result = await entitlements_service.create_bundle(body)
                on_saved(result)
                dialog.close()
            except Exception as exc:
                error_label.text = str(exc)
                error_label.visible = True

        with ui.row().classes("justify-end w-full gap-2 mt-2"):
            ui.button("Cancel", on_click=dialog.close).props("flat")
            ui.button("Save Changes" if is_edit else "Create Bundle", on_click=submit).props("color=primary")

    dialog.open()


def grant_modal(
    type_: str,
    app_id: str,
    entitlements: list,
    bundles: list,
    user: dict,
    on_granted: Callable[[dict], Awaitable[None]],
    existing_grants: Optional[list] = None,
) -> None:
    box = {"bundle_id": None, "ent_id": None, "value_ids": []}
    assigned_bundle_ids, assigned_value_ids = assigned_entitlement_ids(existing_grants or [])

    dialog = ui.dialog()
    with dialog, ui.card().classes("w-full max-w-lg"):
        ui.label("Grant Bundle" if type_ == "bundle" else "Grant Entitlement Value").classes("text-lg font-bold")
        error_label = ui.label("").classes("text-red-600")
        error_label.visible = False

        values_container = ui.column().classes("w-full")

        def render_values() -> None:
            values_container.clear()
            with values_container:
                if type_ == "bundle":
                    available_bundles = [b for b in bundles if b["id"] not in assigned_bundle_ids]
                    if not bundles:
                        ui.label("No bundles available").classes("text-gray-400 text-sm")
                        return
                    if not available_bundles:
                        ui.label("All bundles are already granted to this user").classes("text-gray-400 text-sm")
                        return

                    def pick_bundle(bundle_id):
                        box["bundle_id"] = bundle_id

                    with ui.column().classes("gap-1"):
                        for b in available_bundles:
                            count = len(b.get("entitlementValues", []) or [])
                            ui.radio(
                                {b["id"]: f'{b.get("name")} ({count} values)'},
                                value=None,
                            ).on_value_change(lambda e, bid=b["id"]: pick_bundle(bid))
                    return

                ent_options = {e["id"]: f'{e.get("name")} ({"multi-value" if e.get("multiValue") else "single-value"})' for e in entitlements}
                ent_select = ui.select(ent_options, label="Step 1: Select Entitlement *").classes("w-full")
                value_picker = ui.column().classes("w-full mt-2")

                def on_ent_change(e) -> None:
                    box["ent_id"] = e.value
                    box["value_ids"] = []
                    value_picker.clear()
                    entitlement = next((x for x in entitlements if x["id"] == e.value), None)
                    if not entitlement:
                        return
                    is_multi = entitlement.get("multiValue") is True
                    all_values = entitlement.get("values", []) or []
                    values = [v for v in all_values if v["id"] not in assigned_value_ids]
                    with value_picker:
                        ui.label(f'Step 2: Select Value{"s" if is_multi else ""} *').classes("font-semibold")
                        if not all_values:
                            ui.label(
                                "No values loaded for this entitlement. Reload entitlements on the connector card first."
                            ).classes("text-amber-700 bg-amber-50 border border-amber-400 rounded p-2 text-sm")
                            return
                        if not values:
                            ui.label("All values for this entitlement are already granted to this user").classes(
                                "text-amber-700 bg-amber-50 border border-amber-400 rounded p-2 text-sm"
                            )
                            return
                        if is_multi:
                            for v in values:
                                label = v.get("name") or v.get("id")

                                def on_check(ev, vid=v["id"]):
                                    if ev.value:
                                        box["value_ids"].append(vid)
                                    else:
                                        box["value_ids"] = [x for x in box["value_ids"] if x != vid]

                                ui.checkbox(label).on_value_change(on_check)
                        else:
                            group = {v["id"]: (v.get("name") or v.get("id")) for v in values}
                            ui.radio(group, value=None).on_value_change(lambda ev: box.__setitem__("value_ids", [ev.value]))

                ent_select.on_value_change(on_ent_change)

        render_values()

        async def submit() -> None:
            target = {"externalId": app_id, "type": "APPLICATION"}
            target_principal = {"externalId": user["id"], "type": "OKTA_USER"}
            if type_ == "bundle":
                if not box["bundle_id"]:
                    error_label.text = "Please select a bundle"
                    error_label.visible = True
                    return
                body = {
                    "grantType": "ENTITLEMENT-BUNDLE",
                    "target": target,
                    "targetPrincipal": target_principal,
                    "entitlementBundleId": box["bundle_id"],
                }
            else:
                if not box["ent_id"] or not box["value_ids"]:
                    error_label.text = "Please select a value"
                    error_label.visible = True
                    return
                body = {
                    "grantType": "ENTITLEMENT",
                    "target": target,
                    "targetPrincipal": target_principal,
                    "entitlements": [{"id": box["ent_id"], "values": [{"id": vid} for vid in box["value_ids"]]}],
                }
            try:
                # on_granted performs the actual API call (wrapped in write_with_verification
                # for activity-log tracking) — this modal only builds the request body.
                await on_granted(body)
                dialog.close()
            except Exception as exc:
                error_label.text = str(exc)
                error_label.visible = True

        with ui.row().classes("justify-end w-full gap-2 mt-3"):
            ui.button("Cancel", on_click=dialog.close).props("flat")
            ui.button("Grant Access", on_click=submit).props("color=primary")

    dialog.open()
