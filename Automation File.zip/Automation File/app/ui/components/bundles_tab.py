from nicegui import ui

from app.services import entitlements_service
from app.ui import state
from app.ui.components.grant_modals import bundle_modal


@ui.refreshable
def bundles_tab(app_id: str) -> None:
    connector = state.get_connectors().get(app_id)
    if not connector:
        return

    all_values = [
        {**v, "_entitlementName": e.get("name")}
        for e in connector.get("entitlements", []) or []
        for v in e.get("values", []) or []
    ]

    def on_bundle_change(op: str, bundle: dict) -> None:
        bundles = connector.get("bundles", [])
        if op == "create":
            bundles = [*bundles, bundle]
        elif op == "update":
            bundles = [bundle if b["id"] == bundle["id"] else b for b in bundles]
        elif op == "delete":
            bundles = [b for b in bundles if b["id"] != bundle["id"]]
        state.update_connector(app_id, {"bundles": bundles})
        bundles_tab.refresh()

    with ui.row().classes("justify-end w-full mb-3"):
        ui.button("+ Create Bundle", on_click=lambda: bundle_modal(app_id, all_values, lambda b: on_bundle_change("create", b))).props(
            "color=primary size=sm"
        )

    bundles = connector.get("bundles", []) or []
    if not bundles:
        ui.label("No bundles yet. Create one to group entitlement values.").classes("text-gray-400 text-center py-8 w-full")
        return

    for b in bundles:
        with ui.row().classes("items-center justify-between w-full border rounded p-3 mb-2"):
            with ui.column().classes("gap-0"):
                ui.label(b.get("name")).classes("font-semibold")
                entitlements = b.get("entitlements")
                if entitlements is None:
                    ui.label("values not loaded").classes("text-xs text-gray-400")
                else:
                    count = sum(len(e.get("values", []) or []) for e in entitlements)
                    if count == 0:
                        ui.label("⚠ Empty — no entitlement values").classes(
                            "text-xs text-amber-800 bg-amber-100 border border-amber-500 rounded px-2 py-0.5"
                        )
                    else:
                        all_vals = [v for e in entitlements for v in (e.get("values", []) or [])]
                        names = ", ".join(v.get("name") or v.get("displayName") or v.get("id") for v in all_vals[:3])
                        more = f" +{len(all_vals) - 3} more" if len(all_vals) > 3 else ""
                        ui.label(f"{count} value{'s' if count != 1 else ''} · {names}{more}").classes("text-xs text-gray-500")

            with ui.row().classes("gap-2"):
                ui.button("Edit", on_click=lambda b=b: bundle_modal(
                    app_id, all_values, lambda saved: on_bundle_change("update", saved), bundle=b
                )).props("flat size=sm")

                def confirm_delete(bundle=b) -> None:
                    confirm = ui.dialog()
                    with confirm, ui.card():
                        ui.label(f'Delete "{bundle.get("name")}"? This cannot be undone.')
                        with ui.row().classes("justify-end gap-2 mt-3"):
                            ui.button("Cancel", on_click=confirm.close).props("flat")

                            async def do_delete() -> None:
                                try:
                                    await entitlements_service.delete_bundle(bundle["id"])
                                    on_bundle_change("delete", bundle)
                                    confirm.close()
                                except Exception as exc:
                                    ui.notify(str(exc), type="negative")

                            ui.button("Delete", on_click=do_delete).props("color=negative")
                    confirm.open()

                ui.button("Delete", on_click=confirm_delete).props("flat size=sm color=negative")
