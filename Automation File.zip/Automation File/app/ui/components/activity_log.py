import json
import time

from nicegui import ui

from app.ui import actions, state


def _fmt_time(ts_ms: int) -> str:
    return time.strftime("%H:%M:%S", time.localtime(ts_ms / 1000))


def _target_system_badge(check) -> None:
    if not check:
        return
    if check.get("status") == "checking":
        ui.badge(f"⏳ {check.get('system', '')}").props("color=grey")
        return
    if check.get("status") == "error":
        ui.badge("⚠️ target system").tooltip(check.get("error") or "").props("color=orange")
        return
    has_access = check.get("hasAccess")
    results = check.get("results") or []
    system = results[0].get("system") if results else ""
    tooltip = "; ".join(f"{r.get('entitlementValue')}: {r.get('detail') or r.get('error') or ''}" for r in results)
    ui.badge(f"{'✅' if has_access else '❌'} {system}").tooltip(tooltip).props(
        "color=green" if has_access else "color=red"
    )


@ui.refreshable
def activity_log() -> None:
    log = state.get_activity_log()

    with ui.row().classes("items-center justify-between w-full"):
        with ui.row().classes("items-center gap-2"):
            ui.label("Activity Log").classes("font-bold")
            if log:
                ui.badge(str(len(log)))
        with ui.row().classes("gap-2"):
            if log:
                def clear() -> None:
                    state.clear_activity_log()
                    activity_log.refresh()

                def export_csv() -> None:
                    headers = [
                        "Time", "Action", "App", "Target", "Expires", "Outcome", "Error",
                        "Request Method", "Request URL", "Request Body", "Response",
                        "Target System", "Target System Result", "Target System Detail",
                    ]
                    rows = []
                    for e in log:
                        check = e.get("targetSystemCheck") or {}
                        outcome = {"success": "SUCCESS", "error": "FAILURE"}.get(e.get("status"), "PENDING")
                        ts_result = (
                            ("CONFIRMED" if check.get("hasAccess") else "NOT FOUND")
                            if check.get("status") == "done"
                            else check.get("status", "")
                        )
                        rows.append([
                            e.get("ts"), e.get("action"), e.get("appName") or e.get("appId") or "", e.get("target") or "",
                            e.get("expiresAt") or "", outcome, e.get("error") or "",
                            (e.get("requestInfo") or {}).get("method", ""),
                            (e.get("requestInfo") or {}).get("url", ""),
                            json.dumps((e.get("requestInfo") or {}).get("body")) if (e.get("requestInfo") or {}).get("body") else "",
                            json.dumps(e.get("apiResponse")) if e.get("apiResponse") else "",
                            (check.get("results") or [{}])[0].get("system", "") if check.get("results") else "",
                            ts_result,
                            json.dumps(check.get("results")) if check.get("results") else check.get("error", ""),
                        ])

                    def csv_cell(v) -> str:
                        return '"' + str(v).replace('"', '""') + '"'

                    csv_text = "\n".join(",".join(csv_cell(v) for v in row) for row in [headers, *rows])
                    ui.download(csv_text.encode(), f"activity-{int(time.time() * 1000)}.csv")

                ui.button("Export CSV", on_click=export_csv).props("flat size=sm")
                ui.button("Clear", on_click=clear).props("flat size=sm")

    if not log:
        ui.label("No activity yet. Build a queue and run actions to see events here.").classes("text-gray-400 py-4")
        return

    for entry in log:
        outcome_color = {"success": "green", "error": "red"}.get(entry.get("status"), "orange")
        outcome_label = {"success": "SUCCESS", "error": "FAILURE"}.get(entry.get("status"), "PENDING")

        with ui.expansion().classes("w-full border-b") as exp:
            with exp.add_slot("header"):
                with ui.row().classes("items-center w-full gap-3"):
                    ui.label(_fmt_time(entry["ts"])).classes("text-xs text-gray-500 w-20")
                    ui.label(entry.get("action")).classes("font-medium flex-1")
                    ui.label(entry.get("appName") or entry.get("appId") or "").classes("text-xs w-32 truncate")
                    ui.label(entry.get("target") or "").classes("text-xs w-32 truncate")
                    ui.badge(outcome_label).props(f"color={outcome_color}")
                    _target_system_badge(entry.get("targetSystemCheck"))
                    if entry.get("verify"):
                        checking = (entry.get("targetSystemCheck") or {}).get("status") == "checking"

                        async def revalidate(entry_id=entry["id"]) -> None:
                            await actions.revalidate_target_system(entry_id)
                            activity_log.refresh()

                        ui.button(icon="refresh", on_click=revalidate).props("flat dense round size=sm").set_enabled(not checking)

            if entry.get("error"):
                ui.label(entry["error"]).classes("text-red-600 bg-red-50 p-2 rounded w-full")
            else:
                ui.code(json.dumps(entry.get("apiResponse"), indent=2, default=str)).classes("w-full text-xs")

            check = entry.get("targetSystemCheck")
            if check and check.get("results"):
                ui.label("Target System Check").classes("font-semibold text-xs mt-2")
                ui.code(json.dumps(check["results"], indent=2, default=str)).classes("w-full text-xs")
            if check and check.get("error"):
                ui.label(check["error"]).classes("text-red-600 bg-red-50 p-2 rounded w-full mt-1")
