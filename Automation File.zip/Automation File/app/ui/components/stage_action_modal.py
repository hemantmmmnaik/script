import asyncio
from typing import Optional

from nicegui import ui

from app.services import connectors_service, entitlements_service, users_service
from app.ui import actions, state
from app.ui.components.activity_log import activity_log
from app.ui.components.test_queue import test_queue
from app.ui.components.user_search import user_search

GRANT_ACTIONS = [
    {"key": "bundle", "label": "Grant Bundle", "icon": "📦", "needs_target": True},
    {"key": "custom-ent", "label": "Grant Ent Custom", "icon": "🎯", "needs_target": True},
    {"key": "additive-ent", "label": "Grant Ent Additive", "icon": "🔑", "needs_target": True},
    {"key": "revert-policy", "label": "Revert to Policy", "icon": "↩️", "needs_target": False},
]

LIFECYCLE_ACTIONS = [
    {"key": "activate", "label": "Activate User", "icon": "✅"},
    {"key": "deactivate", "label": "Deactivate User", "icon": "🚫"},
    {"key": "remove-from-app", "label": "Remove from App", "icon": "🗑️"},
    {"key": "assign-app-custom", "label": "Assign to App (Direct)", "icon": "➕"},
    {"key": "assign-app-group", "label": "Assign via Group", "icon": "👥"},
]


def _user_display(user: dict) -> str:
    profile = user.get("profile", {})
    return profile.get("displayName") or profile.get("login") or profile.get("email") or user.get("id")


def stage_action_modal(app_id: str, on_close_callback=None) -> None:
    connector = state.get_connectors().get(app_id)
    if not connector or connector.get("status") != "loaded":
        ui.notify("Connector is not loaded yet", type="warning")
        return

    box = {
        "user": connector.get("defaultUser") or state.get_selected_user(),
        "action_key": "bundle",
        "selected_id": None,
        "selected_ent_id": None,
        "selected_ids": {},  # value_id -> ent_id
        "filter_ent_id": "",
        "expires_at": "",
        "assign_status": None,
        "principal_access": None,
        "assign_loading": False,
        "local_grants": [],
        "local_grants_status": "idle",
        "app_groups": [],
        "selected_group_id": None,
        "error": "",
    }

    dialog = ui.dialog().props("maximized")

    def reset_selection() -> None:
        box["selected_id"] = None
        box["selected_ent_id"] = None
        box["selected_ids"] = {}
        box["filter_ent_id"] = ""
        box["selected_group_id"] = None
        box["expires_at"] = ""
        box["error"] = ""

    async def check_status() -> None:
        user = box["user"]
        if not user:
            box["assign_status"] = None
            return
        box["assign_loading"] = True
        status_panel.refresh()
        try:
            user_data, assign_data, pa_data = await asyncio.gather(
                connectors_service.get_user(state.get_access_token(), user["id"]),
                connectors_service.get_app_user_assignment(app_id, user["id"]),
                connectors_service.get_principal_access(app_id, user["id"]),
                return_exceptions=True,
            )
            box["assign_status"] = {
                "user": user_data if not isinstance(user_data, Exception) else {},
                "assigned": assign_data.get("assigned") if not isinstance(assign_data, Exception) else False,
                "appUser": assign_data.get("appUser") if not isinstance(assign_data, Exception) else None,
            }
            box["principal_access"] = pa_data if not isinstance(pa_data, Exception) else None
        except Exception:
            pass
        box["assign_loading"] = False
        status_panel.refresh()

    async def refresh_grants() -> None:
        user = box["user"]
        if not user:
            box["local_grants"] = []
            box["local_grants_status"] = "idle"
            return
        box["local_grants_status"] = "loading"
        try:
            result = await connectors_service.batch_grants([app_id], user["id"])
            box["local_grants"] = result[0]["grants"] if result else []
            box["local_grants_status"] = "loaded"
        except Exception:
            box["local_grants_status"] = "idle"
        status_panel.refresh()
        picker_panel.refresh()

    async def on_user_change(user: Optional[dict]) -> None:
        box["user"] = user
        box["assign_status"] = None
        box["principal_access"] = None
        if user:
            await check_status()
            await refresh_grants()
        else:
            status_panel.refresh()

    async def load_groups() -> None:
        box["app_groups"] = []
        try:
            box["app_groups"] = await connectors_service.get_app_groups(app_id)
        except Exception:
            pass
        picker_panel.refresh()

    def set_action_key(key: str) -> None:
        box["action_key"] = key
        reset_selection()
        picker_panel.refresh()
        if key == "assign-app-group":
            asyncio.create_task(load_groups())

    async def handle_execute_now(override_key: Optional[str] = None) -> None:
        user = box["user"]
        if not user:
            return
        key = override_key or box["action_key"]
        if override_key:
            set_action_key(override_key)

        user_display = _user_display(user)
        app_name = connector["app"].get("label")
        connector_ref = state.get_connectors().get(app_id, {})

        action_label = None
        api_call = None
        verify = None

        if key == "remove-all":
            action_label = "Remove All Entitlements"
            api_call = lambda: entitlements_service.revoke_all(user["id"], app_id)
        elif key in ("activate", "deactivate"):
            action_label = "Activate User" if key == "activate" else "Deactivate User"
            api_call = lambda: users_service.run_lifecycle_action(user["id"], key)
        elif key == "remove-from-app":
            action_label = "Remove from App"
            api_call = lambda: connectors_service.remove_user_from_app(app_id, user["id"])
        elif key == "assign-app-custom":
            action_label = "Assign to App (Direct)"
            api_call = lambda: connectors_service.assign_user_to_app(app_id, user["id"], user.get("profile", {}).get("login"))
        elif key == "assign-app-group":
            if not box["selected_group_id"]:
                box["error"] = "Select a group first"
                picker_panel.refresh()
                return
            action_label = "Assign via Group"
            api_call = lambda: connectors_service.assign_user_to_group(app_id, box["selected_group_id"], user["id"])
        elif key in ("bundle", "custom-ent", "additive-ent", "revert-policy"):
            is_multi = key in ("custom-ent", "additive-ent")
            if key == "bundle" and not box["selected_id"]:
                box["error"] = "Select a target first"
                picker_panel.refresh()
                return
            if is_multi and not box["selected_ids"]:
                box["error"] = "Select at least one value"
                picker_panel.refresh()
                return

            grant_target = {"externalId": app_id, "type": "APPLICATION"}
            target_principal = {"externalId": user["id"], "type": "OKTA_USER"}

            if key == "bundle":
                bundle = next((b for b in connector_ref.get("bundles", []) if b["id"] == box["selected_id"]), None)
                action_label = f"Grant Bundle: {bundle.get('name') if bundle else box['selected_id']}"
                body = {"grantType": "ENTITLEMENT-BUNDLE", "target": grant_target, "targetPrincipal": target_principal, "entitlementBundleId": box["selected_id"]}
                codes = actions.resolve_entitlement_value_codes(connector_ref, {"grantType": "bundle", "targetId": box["selected_id"]})
            elif is_multi:
                grouped: dict = {}
                for vid, eid in box["selected_ids"].items():
                    grouped.setdefault(eid, []).append(vid)
                entitlements_body = [{"id": eid, "values": [{"id": vid} for vid in vids]} for eid, vids in grouped.items()]
                action_label = "Grant Custom" if key == "custom-ent" else "Grant Entitlement"
                body = {
                    "grantType": "CUSTOM" if key == "custom-ent" else "ENTITLEMENT",
                    "target": grant_target,
                    "targetPrincipal": target_principal,
                    "entitlements": entitlements_body,
                }
                codes = actions.resolve_entitlement_value_codes(connector_ref, {"grantType": key, "entitlements": entitlements_body})
            else:
                action_label = "Revert to Policy"
                body = {"grantType": "POLICY", "target": grant_target, "targetPrincipal": target_principal}
                codes = []

            if box["expires_at"]:
                body["scheduleSettings"] = {"expirationDate": box["expires_at"]}

            login = user.get("profile", {}).get("login")
            if login and codes:
                verify = {"userLogin": login, "userId": user["id"], "entitlementValueCodes": codes}

            api_call = lambda: entitlements_service.create_grant(body)
        else:
            return

        try:
            await actions.write_with_verification(
                action=action_label,
                app_id=app_id,
                app_name=app_name,
                target=user_display,
                expires_at=box["expires_at"] or None,
                api_call=api_call,
                verify=verify,
            )
        except Exception as exc:
            ui.notify(str(exc), type="negative")
        finally:
            activity_log.refresh()
            app_log_panel.refresh()

        reset_selection()
        set_action_key("bundle")
        await check_status()
        await refresh_grants()

    def handle_add() -> None:
        box["error"] = ""
        user = box["user"]
        if not user:
            box["error"] = "Select a user"
            picker_panel.refresh()
            return

        user_display = _user_display(user)
        action_key = box["action_key"]
        connector_ref = state.get_connectors().get(app_id, {})

        if action_key == "remove-all":
            state.add_to_queue({
                "actionType": "revoke-all", "appId": app_id, "appName": connector_ref["app"].get("label"),
                "userId": user["id"], "userDisplay": user_display,
            })
            test_queue.refresh()
            dialog.close()
            return

        lifecycle_keys = {a["key"] for a in LIFECYCLE_ACTIONS}
        if action_key in lifecycle_keys:
            if action_key == "assign-app-group" and not box["selected_group_id"]:
                box["error"] = "Select a group"
                picker_panel.refresh()
                return
            group = next((g for g in box["app_groups"] if g["id"] == box["selected_group_id"]), None)
            state.add_to_queue({
                "actionType": "lifecycle", "appId": app_id, "appName": connector_ref["app"].get("label"),
                "userId": user["id"], "userDisplay": user_display, "lifecycleAction": action_key,
                "groupId": box["selected_group_id"], "groupName": (group or {}).get("profile", {}).get("name"),
            })
            test_queue.refresh()
            dialog.close()
            return

        is_multi = action_key in ("custom-ent", "additive-ent")
        if is_multi and not box["selected_ids"]:
            box["error"] = "Select at least one value"
            picker_panel.refresh()
            return
        needs_target = next((a["needs_target"] for a in GRANT_ACTIONS if a["key"] == action_key), False)
        if not is_multi and needs_target and not box["selected_id"]:
            box["error"] = "Select a bundle or value" if action_key == "bundle" else "Select a value"
            picker_panel.refresh()
            return

        all_values = [
            {**v, "_entId": e["id"]} for e in connector_ref.get("entitlements", []) for v in e.get("values", []) or []
        ]

        if is_multi:
            if action_key == "custom-ent":
                for grant in box["local_grants"]:
                    if grant.get("grantType") in ("ENTITLEMENT", "ENTITLEMENT-BUNDLE"):
                        bundle_id = grant.get("entitlementBundle", {}).get("id") or grant.get("entitlementBundleId")
                        target_name = (
                            grant.get("entitlementBundle", {}).get("name")
                            or next((b["name"] for b in connector_ref.get("bundles", []) if b["id"] == bundle_id), None)
                            or bundle_id
                            if grant["grantType"] == "ENTITLEMENT-BUNDLE"
                            else (grant.get("entitlements", [{}])[0].get("values", [{}])[0].get("name", "Entitlement Grant"))
                        )
                        state.add_to_queue({
                            "actionType": "revoke-grant", "grantId": grant["id"], "revokeGrantType": grant["grantType"],
                            "appId": app_id, "appName": connector_ref["app"].get("label"), "userId": user["id"],
                            "userDisplay": user_display, "targetName": target_name,
                            "entitlementBundleId": bundle_id if grant["grantType"] == "ENTITLEMENT-BUNDLE" else None,
                        })

            grouped: dict = {}
            for vid, eid in box["selected_ids"].items():
                grouped.setdefault(eid, []).append(vid)
            entitlements_body = [{"id": eid, "values": [{"id": vid} for vid in vids]} for eid, vids in grouped.items()]
            names = ", ".join(
                next((v.get("name") or v.get("externalValue") or vid for v in all_values if v["id"] == vid), vid)
                for vid in box["selected_ids"]
            )
            state.add_to_queue({
                "appId": app_id, "appName": connector_ref["app"].get("label"), "userId": user["id"],
                "userDisplay": user_display, "userLogin": user.get("profile", {}).get("login"),
                "grantType": action_key, "targetName": names, "entitlements": entitlements_body,
                "expiresAt": box["expires_at"] or None,
            })
            test_queue.refresh()
            dialog.close()
            return

        target = next((v for v in (connector_ref.get("bundles", []) if action_key == "bundle" else all_values) if v["id"] == box["selected_id"]), None)
        target_name = (
            (target or {}).get("name") if action_key == "bundle"
            else ((target or {}).get("name") or (target or {}).get("externalValue") or box["selected_id"])
            if action_key in ("value", "custom-ent", "additive-ent")
            else "Policy Revert"
        )
        state.add_to_queue({
            "appId": app_id, "appName": connector_ref["app"].get("label"), "userId": user["id"],
            "userDisplay": user_display, "userLogin": user.get("profile", {}).get("login"),
            "grantType": action_key, "targetId": box["selected_id"], "targetName": target_name,
            "entitlementId": box["selected_ent_id"] if action_key in ("value", "custom-ent", "additive-ent") else None,
            "expiresAt": box["expires_at"] if box["expires_at"] and action_key in ("bundle", "custom-ent", "additive-ent") else None,
        })
        test_queue.refresh()
        dialog.close()

    async def handle_remove_grant(grant: dict, target_name: str, bundle_id: Optional[str] = None) -> None:
        user = box["user"]
        if not user:
            return
        connector_ref = state.get_connectors().get(app_id, {})
        if bundle_id:
            codes = actions.resolve_entitlement_value_codes(connector_ref, {"grantType": "bundle", "targetId": bundle_id})
        else:
            codes = [
                v.get("name")
                for ent in grant.get("entitlements", []) or []
                for v in ent.get("values", []) or []
                if v.get("name")
            ]
        verify = (
            {"userLogin": user["profile"]["login"], "userId": user["id"], "entitlementValueCodes": codes}
            if user.get("profile", {}).get("login") and codes
            else None
        )

        try:
            await actions.write_with_verification(
                action=f"revoke-{grant.get('grantType')}",
                app_id=app_id,
                app_name=connector_ref.get("app", {}).get("label"),
                target=target_name,
                api_call=lambda: entitlements_service.delete_grant(
                    grant["id"],
                    grant_type=grant.get("grantType"),
                    app_id=app_id,
                    user_id=user["id"],
                    entitlement_bundle_id=bundle_id,
                    hard_delete=True,
                ),
                request_info={"method": "DELETE", "url": f"/grants/{grant['id']}"},
                verify=verify,
            )
        except Exception as exc:
            ui.notify(str(exc), type="negative")
        finally:
            activity_log.refresh()
            app_log_panel.refresh()
            await check_status()
            await refresh_grants()

    @ui.refreshable
    def status_panel() -> None:
        user = box["user"]
        if not user:
            return
        if box["assign_loading"]:
            ui.spinner(size="sm")
            ui.label("Checking status…").classes("text-xs text-gray-400")
            return

        assign_status = box["assign_status"]
        if assign_status:
            with ui.row().classes("items-center gap-2 flex-wrap bg-gray-50 border rounded p-2"):
                user_status = assign_status.get("user", {}).get("status")
                if user_status:
                    ui.label("User:").classes("text-xs text-gray-500")
                    ui.badge(user_status)
                ui.label("App:").classes("text-xs text-gray-500")
                if assign_status.get("assigned"):
                    ui.badge("Assigned").props("color=green")
                else:
                    ui.badge("Not Assigned").props("color=red")
                pa = box["principal_access"]
                if pa and pa.get("base", {}).get("grantType"):
                    ui.label("Mode:").classes("text-xs text-gray-500")
                    ui.badge(pa["base"]["grantType"])

        if box["local_grants_status"] == "loading":
            ui.spinner(size="sm")
        elif box["local_grants_status"] == "loaded" and box["local_grants"]:
            connector_ref = state.get_connectors().get(app_id, {})
            all_values = [v for e in connector_ref.get("entitlements", []) for v in e.get("values", []) or []]
            pa = box["principal_access"] or {}
            pa_items = [pa.get("base"), *(pa.get("additional") or [])]
            pa_items = [item for item in pa_items if item]

            with ui.column().classes("bg-gray-50 border rounded p-2 gap-1 w-full"):
                ui.label("CURRENT GRANTS").classes("text-xs font-bold text-gray-500")
                for grant in box["local_grants"]:
                    gtype = grant.get("grantType")
                    if gtype == "ENTITLEMENT-BUNDLE":
                        pa_bundle = next(
                            (item for item in (pa.get("additional") or []) if item.get("grant", {}).get("id") == grant["id"]),
                            None,
                        )
                        name = (
                            (pa_bundle or {}).get("bundle", {}).get("name")
                            or grant.get("entitlementBundle", {}).get("name")
                            or grant["id"]
                        )
                        bundle_ref_id = grant.get("entitlementBundleId") or grant.get("entitlementBundle", {}).get("id")
                        with ui.row().classes("items-center justify-between w-full"):
                            ui.label(f"📦 {name}").classes("text-sm")
                            ui.button(
                                icon="delete",
                                on_click=lambda g=grant, n=name, bid=bundle_ref_id: asyncio.create_task(
                                    handle_remove_grant(g, n, bid)
                                ),
                            ).props("flat dense round size=sm color=negative").tooltip("Remove this grant")
                    elif gtype in ("ENTITLEMENT", "CUSTOM"):
                        pa_item = next((item for item in pa_items if item.get("grant", {}).get("id") == grant["id"]), None)
                        ent_list = (pa_item or {}).get("entitlements", []) or []
                        all_vals = [(v, ent) for ent in ent_list for v in (ent.get("values", []) or [])]
                        icon = "🎯" if gtype == "CUSTOM" else "🔑"
                        if not all_vals:
                            with ui.row().classes("items-center justify-between w-full"):
                                ui.label(f"{icon} {gtype}").classes("text-sm text-gray-500")
                                ui.button(
                                    icon="delete",
                                    on_click=lambda g=grant, n=gtype: asyncio.create_task(handle_remove_grant(g, n)),
                                ).props("flat dense round size=sm color=negative").tooltip("Remove this grant")
                        multi = len(all_vals) > 1
                        for v, ent in all_vals:
                            known_val = next((kv for kv in all_values if kv.get("id") == v.get("id")), None)
                            label = (
                                (known_val or {}).get("name")
                                or v.get("name")
                                or v.get("id")
                            )
                            with ui.row().classes("items-center justify-between w-full"):
                                ui.label(f"{icon} {label} · {ent.get('name')}").classes("text-sm")
                                remove_btn = ui.button(
                                    icon="delete",
                                    on_click=lambda g=grant, n=label: asyncio.create_task(handle_remove_grant(g, n)),
                                ).props("flat dense round size=sm color=negative")
                                remove_btn.tooltip(
                                    "Removes the whole grant (also removes its other values)" if multi
                                    else "Remove this grant"
                                )
                    elif gtype == "POLICY":
                        ui.label("↩️ Policy (automatic)").classes("text-sm text-gray-500")

    @ui.refreshable
    def app_log_panel() -> None:
        ui.label("ACTIVITY LOG").classes("text-xs font-bold text-gray-500")
        app_entries = [e for e in state.get_activity_log() if e.get("appId") == app_id][:30]
        if not app_entries:
            ui.label("No activity for this app yet").classes("text-xs text-gray-400")
        for entry in app_entries:
            color = {"success": "green", "error": "red"}.get(entry.get("status"), "amber")
            with ui.card().classes(f"w-full p-2 border-l-4 border-{color}-500"):
                ui.label(entry.get("action")).classes("text-xs font-semibold")
                ui.label(entry.get("target") or "").classes("text-xs text-gray-500")

    @ui.refreshable
    def picker_panel() -> None:
        connector_ref = state.get_connectors().get(app_id, {})
        action_key = box["action_key"]
        assigned_bundle_ids, assigned_value_ids = actions.assigned_entitlement_ids(box["local_grants"])

        if action_key == "assign-app-group":
            if not box["app_groups"]:
                ui.label("No groups assigned to this app, or still loading…").classes("text-xs text-gray-400")
            else:
                options = {g["id"]: (g.get("profile", {}).get("name") or g["id"]) for g in box["app_groups"]}
                ui.radio(options, value=box["selected_group_id"]).on_value_change(
                    lambda e: box.__setitem__("selected_group_id", e.value)
                )

        grant_action = next((a for a in GRANT_ACTIONS if a["key"] == action_key), None)
        if grant_action and grant_action["needs_target"]:
            if action_key == "bundle":
                all_bundles = connector_ref.get("bundles", [])
                bundles = [b for b in all_bundles if b["id"] not in assigned_bundle_ids]
                if not all_bundles:
                    ui.label("No bundles found for this app").classes("text-xs text-gray-400")
                elif not bundles:
                    ui.label("All bundles for this app are already granted to this user").classes("text-xs text-gray-400")
                else:
                    options = {b["id"]: b.get("name") or b["id"] for b in bundles}
                    ui.radio(options, value=box["selected_id"]).on_value_change(
                        lambda e: box.__setitem__("selected_id", e.value)
                    )
            elif action_key in ("custom-ent", "additive-ent"):
                entitlements = connector_ref.get("entitlements", [])
                ent_options = {e["id"]: f'{e.get("name")} ({"multi-value" if e.get("multiValue") else "single-value"})' for e in entitlements}

                def on_ent_select(e) -> None:
                    box["filter_ent_id"] = e.value
                    box["selected_ids"] = {}
                    picker_panel.refresh()

                ui.select(ent_options, value=box["filter_ent_id"] or None, label="Entitlement").classes("w-full").on_value_change(on_ent_select)

                if box["filter_ent_id"]:
                    entitlement = next((e for e in entitlements if e["id"] == box["filter_ent_id"]), None)
                    all_values_for_ent = (entitlement or {}).get("values", []) or []
                    values = [v for v in all_values_for_ent if v["id"] not in assigned_value_ids]
                    is_multi_value = (entitlement or {}).get("multiValue") is True
                    if not all_values_for_ent:
                        ui.label("No values loaded. Click Reload Entitlements and try again.").classes(
                            "text-xs text-red-600 bg-red-50 p-2 rounded"
                        )
                    elif not values:
                        ui.label("All values for this entitlement are already granted to this user").classes(
                            "text-xs text-gray-400"
                        )
                    elif is_multi_value:
                        for v in values:
                            label = v.get("name") or v["id"]

                            def on_check(e, vid=v["id"]) -> None:
                                if e.value:
                                    box["selected_ids"][vid] = box["filter_ent_id"]
                                else:
                                    box["selected_ids"].pop(vid, None)

                            ui.checkbox(label, value=v["id"] in box["selected_ids"]).on_value_change(on_check)
                    else:
                        options = {v["id"]: (v.get("name") or v["id"]) for v in values}
                        current = next(iter(box["selected_ids"].keys()), None)
                        ui.radio(options, value=current).on_value_change(
                            lambda e: box["selected_ids"].__setitem__(e.value, box["filter_ent_id"])
                            if e.value else None
                        )

            if action_key in ("bundle", "custom-ent", "additive-ent"):
                with ui.row().classes("items-center gap-2"):
                    ui.label("Expires").classes("text-xs")
                    expires_input = ui.input(value=box["expires_at"]).props("type=datetime-local").classes("w-56")
                    expires_input.on_value_change(lambda e: box.__setitem__("expires_at", e.value or ""))
                    ui.label("optional — leave blank for no expiry").classes("text-xs text-gray-400")

        if box["error"]:
            ui.label(box["error"]).classes("text-red-600 text-sm")

    with dialog, ui.card().classes("w-full h-full"):
        with ui.row().classes("items-center justify-between w-full"):
            ui.label(f"Stage Action — {connector['app'].get('label')}").classes("text-lg font-bold")
            ui.button(icon="close", on_click=dialog.close).props("flat dense round")

        with ui.row(wrap=False).classes("w-full gap-4 flex-1"):
            # LEFT: action buttons
            with ui.column().classes("w-56 gap-3"):
                with ui.column().classes("border rounded gap-1 p-2 bg-blue-50"):
                    ui.label("+ ADD ENTITLEMENTS").classes("text-xs font-bold text-blue-800")
                    for a in GRANT_ACTIONS:
                        ui.button(f'{a["icon"]} {a["label"]}', on_click=lambda a=a: set_action_key(a["key"])).props("flat align=left").classes("w-full")

                with ui.column().classes("border rounded gap-1 p-2 bg-amber-50"):
                    ui.label("⚡ EXECUTE IMMEDIATELY").classes("text-xs font-bold text-amber-800")
                    for a in LIFECYCLE_ACTIONS:
                        ui.button(f'{a["icon"]} {a["label"]}', on_click=lambda a=a: asyncio.create_task(handle_execute_now(a["key"]))).props(
                            "flat align=left"
                        ).classes("w-full")

                with ui.column().classes("border rounded gap-1 p-2 bg-red-50"):
                    ui.label("⚠ DANGER").classes("text-xs font-bold text-red-800")
                    ui.button(
                        "⚠️ Remove All Entitlements",
                        on_click=lambda: asyncio.create_task(handle_execute_now("remove-all")),
                    ).props("flat align=left").classes("w-full text-red-700")

                async def reload_bundles() -> None:
                    try:
                        bundles = await connectors_service.get_app_bundles(app_id)
                        state.update_connector(app_id, {"bundles": bundles})
                        picker_panel.refresh()
                    except Exception as exc:
                        ui.notify(str(exc), type="negative")

                async def reload_entitlements() -> None:
                    try:
                        entitlements = await connectors_service.get_app_entitlements(app_id)
                        state.update_connector(app_id, {"entitlements": entitlements})
                        picker_panel.refresh()
                    except Exception as exc:
                        ui.notify(str(exc), type="negative")

                ui.button("↻ Reload Bundles", on_click=reload_bundles).props("flat size=sm align=left")
                ui.button("↻ Reload Entitlements", on_click=reload_entitlements).props("flat size=sm align=left")

            # MIDDLE: user + status + picker
            with ui.column().classes("flex-1 gap-3 overflow-auto"):
                with ui.row().classes("items-center gap-2 w-full"):
                    user_search(lambda u: asyncio.create_task(on_user_change(u)), initial=box["user"], placeholder="Search for test user…")
                    ui.button(icon="refresh", on_click=lambda: asyncio.create_task(check_status())).props("flat dense round size=sm")

                status_panel()
                picker_panel()

            # RIGHT: per-app activity log
            with ui.column().classes("w-64 gap-1 overflow-auto border-l pl-3"):
                app_log_panel()

        with ui.row().classes("justify-end gap-2 w-full border-t pt-2"):
            ui.button("Cancel", on_click=dialog.close).props("flat")
            ui.button("⚡ Execute Now", on_click=lambda: asyncio.create_task(handle_execute_now())).props("outline")
            ui.button("+ Add to Queue", on_click=handle_add).props("color=primary")

    dialog.open()

    if box["user"]:
        asyncio.create_task(check_status())
        asyncio.create_task(refresh_grants())
