from nicegui import ui

from app import config_store
from app.ui import state


def require_auth() -> bool:
    """Call at the top of a @ui.page handler. Navigates away and returns False if the
    caller should not render this page (setup incomplete / not logged in)."""
    if not config_store.has_config():
        ui.navigate.to("/setup")
        return False
    if not state.is_authenticated():
        ui.navigate.to("/auth/login")
        return False
    return True
