import asyncio

from nicegui import ui

from app.services import connectors_service
from app.ui import state
from app.ui.components.bundles_tab import bundles_tab
from app.ui.components.entitlements_tab import entitlements_tab
from app.ui.components.grants_tab import grants_tab
from app.ui.components.top_nav import top_nav
from app.ui.guards import require_auth


@ui.page("/connectors/{app_id}")
async def connector_detail_page(app_id: str):
    if not require_auth():
        return

    connector = state.get_connectors().get(app_id)
    top_nav()

    if not connector:
        with ui.column().classes("max-w-lg mx-auto mt-8 gap-2"):
            ui.label("Connector not found.").classes("text-red-600")
            ui.link("← Back to connectors", "/connectors")
        return

    principal_access_box = {"value": None}

    async def refresh_grants() -> None:
        user = state.get_selected_user()
        if not user:
            return
        state.update_connector(app_id, {"grantsStatus": "loading"})
        grants_result, pa_result = await asyncio.gather(
            connectors_service.batch_grants([app_id], user["id"]),
            connectors_service.get_principal_access(app_id, user["id"]),
            return_exceptions=True,
        )
        grants = grants_result[0]["grants"] if isinstance(grants_result, list) and grants_result else []
        state.update_connector(app_id, {"userGrants": grants, "grantsStatus": "loaded"})
        principal_access_box["value"] = pa_result if not isinstance(pa_result, Exception) else None
        grants_tab.refresh(app_id, principal_access_box["value"], refresh_grants)

    with ui.column().classes("max-w-5xl mx-auto w-full p-4 gap-3"):
        with ui.row().classes("items-center gap-3"):
            ui.button("← Back", on_click=lambda: ui.navigate.to("/connectors")).props("flat size=sm")
            app_info = connector.get("app", {})
            with ui.row().classes("items-center gap-2"):
                ui.avatar((app_info.get("label") or "?")[0].upper())
                with ui.column().classes("gap-0"):
                    ui.label(app_info.get("label")).classes("text-2xl font-bold")
                    ui.label(app_info.get("name")).classes("text-xs text-gray-500")

            user = state.get_selected_user()
            if user:
                profile = user.get("profile", {})
                display = profile.get("displayName") or profile.get("login") or user.get("email")
                ui.badge(f"👤 {display}").classes("ml-auto")

        with ui.tabs().classes("w-full") as tabs:
            tab_entitlements = ui.tab("Entitlements & Values")
            tab_bundles = ui.tab(f'Bundles ({len(connector.get("bundles", []))})')
            grants_count = f' ({len(connector.get("userGrants", []))})' if state.get_selected_user() else ""
            tab_grants = ui.tab(f"Grants{grants_count}")

        with ui.tab_panels(tabs, value=tab_entitlements).classes("w-full"):
            with ui.tab_panel(tab_entitlements):
                entitlements_tab(app_id)
            with ui.tab_panel(tab_bundles):
                bundles_tab(app_id)
            with ui.tab_panel(tab_grants):
                grants_tab(app_id, principal_access_box["value"], refresh_grants)

        async def on_tab_change(e) -> None:
            if e.value == tab_grants and state.get_selected_user():
                await refresh_grants()

        tabs.on_value_change(on_tab_change)

        if state.get_selected_user():
            await refresh_grants()
