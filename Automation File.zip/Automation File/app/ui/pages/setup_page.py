from nicegui import ui

from app.services import setup_service


@ui.page("/setup")
def setup_page():
    domain = setup_service.get_tenant().get("domain")

    with ui.column().classes("w-full max-w-md mx-auto mt-16 gap-4"):
        ui.label("Initial Setup").classes("text-2xl font-bold")
        ui.label("Connect to your Okta tenant using credentials configured in .env.").classes("text-gray-600")

        error_label = ui.label("").classes("text-red-600")
        error_label.visible = False

        with ui.card().classes("w-full"):
            ui.label("Okta Tenant").classes("font-semibold")
            ui.label(domain or "Not configured — set OKTA_ISSUER_URL in .env").classes(
                "p-2 bg-gray-100 rounded" if domain else "p-2 bg-gray-100 rounded text-gray-400"
            )
            ui.label("Read from OKTA_ISSUER_URL in .env.").classes("text-xs text-gray-500")

            connect_button = ui.button("Connect & Continue to Login").classes("w-full mt-2")
            if not domain:
                connect_button.disable()

            async def handle_connect():
                error_label.visible = False
                connect_button.disable()
                connect_button.text = "Connecting…"
                try:
                    await setup_service.run_setup(reset=True)
                    ui.navigate.to("/auth/login")
                except Exception as exc:
                    error_label.text = str(exc)
                    error_label.visible = True
                    connect_button.enable()
                    connect_button.text = "Connect & Continue to Login"

            connect_button.on_click(handle_connect)
