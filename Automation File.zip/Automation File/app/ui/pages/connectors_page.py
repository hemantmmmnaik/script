import asyncio

from nicegui import ui

from app.services import connectors_service
from app.ui import state
from app.ui.components.activity_log import activity_log
from app.ui.components.add_app_modal import add_app_modal
from app.ui.components.app_search import app_search
from app.ui.components.bulk_upload_modal import bulk_upload_modal
from app.ui.components.connector_card import connector_card
from app.ui.components.stage_action_modal import stage_action_modal
from app.ui.components.target_system_config_modal import target_system_config_modal
from app.ui.components.test_queue import test_queue
from app.ui.components.top_nav import top_nav
from app.ui.components.user_search import user_search
from app.ui.guards import require_auth


async def _load_connector(app_id: str, skip_values: bool = False, skip_bundles: bool = False) -> None:
    state.update_connector(app_id, {"status": "loading"})
    try:
        results = await connectors_service.batch_load([app_id], skip_values, skip_bundles)
        result = results[0]
        state.update_connector(app_id, {
            "status": result["status"],
            "entitlements": result.get("entitlements", []),
            "bundles": result.get("bundles", []),
            "error": result.get("error"),
            "skipValues": skip_values,
            "skipBundles": skip_bundles,
        })
    except Exception as exc:
        state.update_connector(app_id, {"status": "error", "error": str(exc)})


@ui.page("/connectors")
async def connectors_page():
    if not require_auth():
        return

    @ui.refreshable
    def sidebar() -> None:
        order = state.get_connector_order()
        connectors = state.get_connectors()
        with ui.row().classes("items-center w-full"):
            ui.label("Apps").classes("font-bold")
            ui.badge(str(len(order)))
            if order:
                def clear_all() -> None:
                    state.clear_all_connectors()
                    sidebar.refresh()
                    card_grid.refresh()

                ui.button("Clear all", on_click=clear_all).props("flat size=sm color=negative").classes("ml-auto")

        ui.button("+ Add App", on_click=lambda: open_add_app_modal()).props("color=primary size=sm").classes("w-full")
        ui.button("📤 Bulk Upload", on_click=lambda: open_bulk_upload_modal()).props("flat size=sm").classes("w-full")

        if not order:
            ui.label("Search above to add apps").classes("text-xs text-gray-400 py-2")
        for app_id in order:
            connector = connectors.get(app_id)
            if not connector:
                continue
            color = {"idle": "grey", "loading": "blue", "loaded": "green", "error": "red"}.get(connector["status"], "grey")
            with ui.row().classes("items-center gap-2 py-1"):
                ui.icon("circle", color=color).classes("text-xs")
                ui.label(connector["app"].get("label")).classes("text-sm truncate").tooltip(connector["app"].get("label"))

    @ui.refreshable
    def card_grid() -> None:
        order = state.get_connector_order()
        if not order:
            with ui.column().classes("items-center text-center py-16 gap-2 w-full"):
                ui.label("🔌").classes("text-4xl")
                ui.label("Add apps to get started").classes("text-xl font-bold")
                ui.label(
                    'Search for Okta apps in the sidebar or click "+ Add App". Once loaded, hit "+ Stage Action" '
                    "on each card to build your test queue."
                ).classes("text-gray-500 max-w-md")
                ui.button("+ Add App", on_click=lambda: open_add_app_modal()).props("color=primary")
            return

        connectors = state.get_connectors()
        loaded_count = sum(1 for aid in order if connectors.get(aid, {}).get("status") == "loaded")
        selected_user = state.get_selected_user()

        with ui.row().classes("items-center gap-4 w-full"):
            if loaded_count:
                extra = f" · user: {selected_user['profile'].get('displayName') or selected_user['profile'].get('login')}" if selected_user else ""
                ui.label(f"{loaded_count} of {len(order)} app{'s' if len(order) != 1 else ''} loaded{extra}").classes(
                    "text-xs text-gray-500"
                )
            ui.button("+ Add App", on_click=lambda: open_add_app_modal()).props("flat size=sm").classes("ml-auto")

        with ui.row().classes("gap-4 flex-wrap w-full"):
            for app_id in order:
                connector_card(app_id, on_remove=remove_connector, on_stage=open_stage_modal, on_configure_target_system=open_target_system_modal)

    def remove_connector(app_id: str) -> None:
        state.remove_connector(app_id)
        sidebar.refresh()
        card_grid.refresh()

    def open_stage_modal(app_id: str) -> None:
        stage_action_modal(app_id)

    def open_target_system_modal(app_id: str) -> None:
        connector = state.get_connectors().get(app_id, {})
        target_system_config_modal(app_id, connector.get("app", {}).get("label", ""), lambda: card_grid.refresh())

    def open_bulk_upload_modal() -> None:
        bulk_upload_modal(lambda: test_queue.refresh())

    def open_add_app_modal() -> None:
        def on_add(app: dict, opts: dict) -> None:
            state.add_connector(
                app,
                skip_values=opts.get("skip_values", False),
                skip_bundles=opts.get("skip_bundles", False),
                default_user=opts.get("default_user"),
            )
            sidebar.refresh()
            card_grid.refresh()
            asyncio.create_task(_load_and_refresh(app["id"], opts.get("skip_values", False), opts.get("skip_bundles", False)))

        add_app_modal(on_add, state.get_connector_order())

    async def _load_and_refresh(app_id: str, skip_values: bool, skip_bundles: bool) -> None:
        await _load_connector(app_id, skip_values, skip_bundles)
        sidebar.refresh()
        card_grid.refresh()

    async def handle_select_user(user) -> None:
        state.set_selected_user(user)
        order = state.get_connector_order()
        connectors = state.get_connectors()
        if not user:
            for app_id in order:
                state.update_connector(app_id, {"userGrants": [], "grantsStatus": "idle"})
            card_grid.refresh()
            return

        loaded_ids = [aid for aid in order if connectors.get(aid, {}).get("status") == "loaded"]
        if not loaded_ids:
            return
        for app_id in loaded_ids:
            state.update_connector(app_id, {"grantsStatus": "loading"})
        try:
            results = await connectors_service.batch_grants(loaded_ids, user["id"])
            for result in results:
                state.update_connector(result["appId"], {"userGrants": result.get("grants", []), "grantsStatus": "loaded"})
        except Exception:
            for app_id in loaded_ids:
                state.update_connector(app_id, {"grantsStatus": "idle"})
        card_grid.refresh()

    def top_right() -> None:
        queue = state.get_action_queue()
        if queue:
            ui.label(f"{len(queue)} action{'s' if len(queue) != 1 else ''} queued").classes("text-xs text-gray-500")
        user_search(lambda u: asyncio.create_task(handle_select_user(u)), initial=state.get_selected_user(), placeholder="Default test user…")

    top_nav(top_right)

    with ui.row(wrap=False).classes("w-full gap-4 p-4"):
        with ui.column().classes("w-56 gap-2"):
            sidebar()
        with ui.column().classes("flex-1 gap-3"):
            test_queue()
            card_grid()

    with ui.column().classes("w-full p-4"):
        activity_log()

    # Auto-reload any persisted connectors still sitting idle.
    for app_id in list(state.get_connector_order()):
        connector = state.get_connectors().get(app_id)
        if connector and connector.get("status") == "idle":
            await _load_connector(app_id, connector.get("skipValues", False), connector.get("skipBundles", False))
    sidebar.refresh()
    card_grid.refresh()
