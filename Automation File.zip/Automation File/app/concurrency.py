import asyncio
from typing import Awaitable, Callable, List, TypeVar

T = TypeVar("T")


async def run_limited(fns: List[Callable[[], Awaitable[T]]], limit: int = 5) -> List[T]:
    """Run zero-arg async callables with at most `limit` running concurrently.

    Mirrors the original server/pLimit.js usage: results are returned in the
    same order as `fns`, regardless of completion order.
    """
    semaphore = asyncio.Semaphore(limit)

    async def _run(fn: Callable[[], Awaitable[T]]) -> T:
        async with semaphore:
            return await fn()

    return await asyncio.gather(*(_run(fn) for fn in fns))
