from typing import Optional

from app import settings
from app.m2m import get_m2m_token


class OktaApiError(Exception):
    def __init__(self, status: int, error: Optional[str] = None, error_code: Optional[str] = None,
                 error_causes: Optional[list] = None):
        self.status = status
        self.error = error or f"Okta API error ({status})"
        self.error_code = error_code
        self.error_causes = error_causes or []
        super().__init__(self._format())

    def _format(self) -> str:
        msg = self.error
        if self.error_code:
            msg += f" [{self.error_code}]"
        if self.error_causes:
            causes = "; ".join(c.get("errorSummary", str(c)) for c in self.error_causes)
            msg += f": {causes}"
        return msg


def raise_for_okta_error(resp) -> None:
    if resp.status_code < 400:
        return
    try:
        data = resp.json()
    except Exception:
        data = {}
    raise OktaApiError(
        status=resp.status_code,
        error=data.get("errorSummary") or data.get("error_description") or data.get("message"),
        error_code=data.get("errorCode"),
        error_causes=data.get("errorCauses"),
    )


def unwrap_page(data):
    """Governance API (v1/v2) list endpoints wrap results as {"data": [...], "_links": {...}},
    unlike the classic Management API (/api/v1/...) which returns bare arrays. Unwrap the
    governance envelope if present; otherwise pass through unchanged."""
    if isinstance(data, dict) and isinstance(data.get("data"), list):
        return data["data"]
    return data


def unwrap_single(data):
    """Same governance {"data": ...} envelope as unwrap_page, but for endpoints that return a
    single filtered object (e.g. principal-access) rather than a collection. If "data" is a
    list (one result per matching filter), take the first entry."""
    if isinstance(data, dict) and "data" in data:
        inner = data["data"]
        if isinstance(inner, list):
            return inner[0] if inner else {}
        return inner
    return data


def expect_list(data, label: str) -> list:
    """Raise a diagnosable error instead of a downstream AttributeError when an endpoint
    that's expected to return a bare JSON array returns something else (e.g. a 200 response
    whose body is an error/envelope object rather than a list)."""
    data = unwrap_page(data)
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        for key in ("errorSummary", "errorCode", "error", "error_description", "message"):
            if key in data:
                raise OktaApiError(status=200, error=f"{label} returned an error body", error_code=data.get("errorCode"))
    raise OktaApiError(
        status=200,
        error=f"Expected a list from {label}, got {type(data).__name__}: {str(data)[:300]}",
    )


def api_base() -> str:
    return f"https://{settings.okta_domain()}/api/v1"


def gov_base() -> str:
    return f"https://{settings.okta_domain()}/governance/api/v1"


def gov_v2_base() -> str:
    return f"https://{settings.okta_domain()}/governance/api/v2"


async def m2m_headers() -> dict:
    token = await get_m2m_token()
    return {"Authorization": f"Bearer {token}", "Content-Type": "application/json", "Accept": "application/json"}


async def user_headers(access_token: Optional[str]) -> dict:
    token = access_token or await get_m2m_token()
    return {"Authorization": f"Bearer {token}", "Content-Type": "application/json", "Accept": "application/json"}
