from authlib.integrations.starlette_client import OAuth
from fastapi import Request
from fastapi.responses import PlainTextResponse, RedirectResponse
from nicegui import app as nicegui_app

from app import config_store, settings

oauth = OAuth()
oauth.register(
    name="okta",
    client_id=settings.OKTA_CLIENT_ID,
    client_secret=settings.OKTA_CLIENT_SECRET,
    server_metadata_url=f"{settings.OKTA_ISSUER_URL}/.well-known/openid-configuration",
    client_kwargs={
        "scope": "openid profile email okta.users.read okta.users.manage",
        "code_challenge_method": "S256",
    },
)


async def login(request: Request):
    if not config_store.has_config():
        return RedirectResponse("/setup")
    redirect_uri = f"{settings.APP_URL}/auth/callback"
    return await oauth.okta.authorize_redirect(request, redirect_uri)


async def callback(request: Request):
    if not config_store.has_config():
        return RedirectResponse("/setup")

    error = request.query_params.get("error")
    if error:
        desc = request.query_params.get("error_description", error)
        return PlainTextResponse(f"Authentication failed: {desc}", status_code=401)

    try:
        token = await oauth.okta.authorize_access_token(request)
    except Exception as exc:
        return PlainTextResponse(f"Authentication failed: {exc}", status_code=401)

    claims = token.get("userinfo") or {}
    nicegui_app.storage.user["user"] = {
        "id": claims.get("sub"),
        "email": claims.get("email"),
        "name": claims.get("name"),
    }
    nicegui_app.storage.user["access_token"] = token.get("access_token")
    return RedirectResponse("/")


async def logout():
    nicegui_app.storage.user.pop("user", None)
    nicegui_app.storage.user.pop("access_token", None)
    return RedirectResponse("/")


# Registered directly on nicegui's own app (not our outer FastAPI app) because only requests
# routed into nicegui's mounted sub-app pass through its RequestTrackingMiddleware — which is
# what makes `nicegui_app.storage.user` usable at all. Mounted at both /auth and /api/auth to
# match the original app's dual mount.
for prefix in ("/auth", "/api/auth"):
    nicegui_app.get(f"{prefix}/login")(login)
    nicegui_app.get(f"{prefix}/callback")(callback)
    nicegui_app.get(f"{prefix}/logout")(logout)
