import os
from pathlib import Path
from urllib.parse import urlparse

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")

DATA_DIR = BASE_DIR / "data"
STORAGE_DIR = DATA_DIR / "storage"

PORT = int(os.environ.get("PORT", "3005"))
APP_URL = os.environ.get("APP_URL", "http://localhost:3005")
SESSION_SECRET = os.environ.get("SESSION_SECRET", "dev-secret-change-me")

OKTA_CLIENT_ID = os.environ.get("OKTA_CLIENT_ID", "")
OKTA_CLIENT_SECRET = os.environ.get("OKTA_CLIENT_SECRET", "")
OKTA_ISSUER_URL = os.environ.get("OKTA_ISSUER_URL", "")

OKTA_M2M_CLIENT_ID = os.environ.get("OKTA_M2M_CLIENT_ID", "")
OKTA_PRIVATE_KEY_BASE64 = os.environ.get("OKTA_PRIVATE_KEY_BASE64", "")
OKTA_KEY_ID = os.environ.get("OKTA_KEY_ID", "")

AD_URL = os.environ.get("AD_URL", "")
AD_BASE_DN = os.environ.get("AD_BASE_DN", "")
AD_BIND_DN = os.environ.get("AD_BIND_DN", "")
AD_BIND_PASSWORD = os.environ.get("AD_BIND_PASSWORD", "")
AD_USER_SEARCH_ATTR = os.environ.get("AD_USER_SEARCH_ATTR", "sAMAccountName")
AD_CA_CERT_PATH = os.environ.get("AD_CA_CERT_PATH", "")

ENTRAID_TENANT_ID = os.environ.get("ENTRAID_TENANT_ID", "")
ENTRAID_CLIENT_ID = os.environ.get("ENTRAID_CLIENT_ID", "")
ENTRAID_CLIENT_SECRET = os.environ.get("ENTRAID_CLIENT_SECRET", "")
ENTRAID_USER_MATCH_ATTR = os.environ.get("ENTRAID_USER_MATCH_ATTR", "userPrincipalName")

ORACLE_CONNECT_STRING = os.environ.get("ORACLE_CONNECT_STRING", "")
ORACLE_USER = os.environ.get("ORACLE_USER", "")
ORACLE_PASSWORD = os.environ.get("ORACLE_PASSWORD", "")

MSSQL_SERVER = os.environ.get("MSSQL_SERVER", "")
MSSQL_DATABASE = os.environ.get("MSSQL_DATABASE", "")
MSSQL_USER = os.environ.get("MSSQL_USER", "")
MSSQL_PASSWORD = os.environ.get("MSSQL_PASSWORD", "")
MSSQL_PORT = int(os.environ.get("MSSQL_PORT", "1433"))
MSSQL_ENCRYPT = os.environ.get("MSSQL_ENCRYPT", "true").lower() != "false"

WEBSERVICE_BASE_URL = os.environ.get("WEBSERVICE_BASE_URL", "")
WEBSERVICE_AUTH_TYPE = os.environ.get("WEBSERVICE_AUTH_TYPE", "none")
WEBSERVICE_AUTH_TOKEN = os.environ.get("WEBSERVICE_AUTH_TOKEN", "")
WEBSERVICE_AUTH_HEADER_NAME = os.environ.get("WEBSERVICE_AUTH_HEADER_NAME", "X-API-Key")
WEBSERVICE_AUTH_USER = os.environ.get("WEBSERVICE_AUTH_USER", "")
WEBSERVICE_AUTH_PASSWORD = os.environ.get("WEBSERVICE_AUTH_PASSWORD", "")
WEBSERVICE_PROXY_URL = os.environ.get("WEBSERVICE_PROXY_URL", "")

SCIM_TOKEN_URL = os.environ.get("SCIM_TOKEN_URL", "")

ARCHER_LOGIN_URL = os.environ.get("ARCHER_LOGIN_URL", "")
ARCHER_INSTANCE_NAME = os.environ.get("ARCHER_INSTANCE_NAME", "")
ARCHER_USERNAME = os.environ.get("ARCHER_USERNAME", "")
ARCHER_PASSWORD = os.environ.get("ARCHER_PASSWORD", "")
ARCHER_USER_DOMAIN = os.environ.get("ARCHER_USER_DOMAIN", "")

WORKFLOW_ASSIGN_INVOKE_URL = os.environ.get("WORKFLOW_ASSIGN_INVOKE_URL", "")
WORKFLOW_ASSIGN_CLIENT_TOKEN = os.environ.get("WORKFLOW_ASSIGN_CLIENT_TOKEN", "")
WORKFLOW_UNASSIGN_INVOKE_URL = os.environ.get("WORKFLOW_UNASSIGN_INVOKE_URL", "")
WORKFLOW_UNASSIGN_CLIENT_TOKEN = os.environ.get("WORKFLOW_UNASSIGN_CLIENT_TOKEN", "")
WORKFLOW_TERMINATION_INVOKE_URL = os.environ.get("WORKFLOW_TERMINATION_INVOKE_URL", "")
WORKFLOW_TERMINATION_CLIENT_TOKEN = os.environ.get("WORKFLOW_TERMINATION_CLIENT_TOKEN", "")

M2M_SCOPES = " ".join(
    [
        "okta.governance.labels.read",
        "okta.governance.labels.manage",
        "okta.apps.read",
        "okta.apps.manage",
        "okta.groups.read",
        "okta.groups.manage",
        "okta.orgs.read",
        "okta.governance.collections.read",
        "okta.governance.collections.manage",
        "okta.governance.entitlements.read",
        "okta.governance.entitlements.manage",
        "okta.users.read",
        "okta.users.manage",
        "okta.logs.read",
    ]
)


def okta_org_url() -> str:
    return OKTA_ISSUER_URL.split("/oauth2")[0]


def okta_domain() -> str:
    parsed = urlparse(OKTA_ISSUER_URL)
    return parsed.netloc or OKTA_ISSUER_URL.replace("https://", "").replace("http://", "").split("/")[0]
