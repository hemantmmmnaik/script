"""Runtime credential resolution for app.dbautomation, keyed by app_id.

Credentials are NEVER hardcoded in settings.py/source. This module deliberately depends only on
app.settings (.env), matching the constraint that app.dbautomation must run standalone.

Env var convention (per app_id, per credential field):
    DBAUTO_<SANITIZED_APP_ID>_<FIELD>=<plaintext value>
e.g. for app_id "APP_ORACLE_01":
    DBAUTO_APP_ORACLE_01_HOST=...
    DBAUTO_APP_ORACLE_01_PORT=...
    DBAUTO_APP_ORACLE_01_USERNAME=...
    DBAUTO_APP_ORACLE_01_PASSWORD=...
    DBAUTO_APP_ORACLE_01_SSL_CERT=...        (optional)
    DBAUTO_APP_ORACLE_01_DSN=...             (optional, engine-specific: connect string/DSN)
    DBAUTO_APP_ORACLE_01_DATABASE=...        (optional)

Swapping this whole class for a Vault/AWS Secrets Manager provider later requires zero changes to
config.py, registry.py, drivers/*, or the service layer, since callers only ever see the
SecretsProvider interface below.
"""

import os
import re
from abc import ABC, abstractmethod

CREDENTIAL_FIELDS = ["host", "port", "username", "password", "ssl_cert", "dsn", "database"]

_SANITIZE_RE = re.compile(r"[^A-Za-z0-9]")


def sanitize_app_id(app_id: str) -> str:
    """Okta app IDs (e.g. '0oa10v7gnfmHtqvwt1d8') aren't valid bare env var name segments --
    upper-case and replace every non-alnum char with '_' before building an env var key."""
    return _SANITIZE_RE.sub("_", app_id).upper()


class SecretsProvider(ABC):
    @abstractmethod
    def get_credentials(self, app_id: str) -> dict:
        """Returns a dict of whichever CREDENTIAL_FIELDS are configured for app_id. Raises
        LookupError if no credentials are configured at all for this app_id."""


class EnvSecretsProvider(SecretsProvider):
    def get_credentials(self, app_id: str) -> dict:
        prefix = f"DBAUTO_{sanitize_app_id(app_id)}_"

        credentials = {}
        for field in CREDENTIAL_FIELDS:
            value = os.environ.get(f"{prefix}{field.upper()}")
            if not value:
                continue
            credentials[field] = value

        if not credentials:
            raise LookupError(f"No dbautomation credentials configured for app_id '{app_id}'")
        return credentials


def get_secrets_provider() -> SecretsProvider:
    """Single seam for swapping providers later (Vault, AWS Secrets Manager, ...) without
    touching config.py, registry.py, drivers/*, or the service layer."""
    return EnvSecretsProvider()
