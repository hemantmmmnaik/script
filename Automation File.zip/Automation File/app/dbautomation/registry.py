import importlib

from app.dbautomation.drivers.base import BaseDriver

# connector_type -> (module path, class name). Adding a new dialect is one new drivers/*.py
# file + one line here -- no changes to config.py, secrets.py, errors.py, or the service layer.
CONNECTOR_REGISTRY = {
    "oracle": ("app.dbautomation.drivers.oracle", "OracleDriver"),
    "postgres": ("app.dbautomation.drivers.postgres", "PostgresDriver"),
    "mysql": ("app.dbautomation.drivers.mysql", "MySQLDriver"),
    "mssql": ("app.dbautomation.drivers.mssql", "MSSQLDriver"),
}


def get_driver(connector_type: str) -> type:
    entry = CONNECTOR_REGISTRY.get((connector_type or "").lower())
    if not entry:
        raise ValueError(
            f"Unregistered connector_type '{connector_type}' -- supported types: "
            f"{sorted(CONNECTOR_REGISTRY)}"
        )
    module_path, class_name = entry
    try:
        module = importlib.import_module(module_path)
    except ImportError as exc:
        raise RuntimeError(
            f"Driver package for connector_type '{connector_type}' is not installed ({exc})"
        ) from exc

    driver_cls = getattr(module, class_name)
    if not issubclass(driver_cls, BaseDriver):
        raise TypeError(f"{module_path}.{class_name} does not implement BaseDriver")
    return driver_cls
