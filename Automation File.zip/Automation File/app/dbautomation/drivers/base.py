import asyncio
from abc import ABC, abstractmethod
from typing import Optional


class BaseDriver(ABC):
    """Connection lifecycle (connect/commit/rollback/close) lives once, here. Each concrete
    driver only implements the four dialect-specific primitives below. All parameter binding
    happens via each driver's native DB-API bind mechanism -- never string interpolation."""

    connector_type: str = "base"

    def __init__(self, credentials: dict, config: Optional[dict] = None):
        self.credentials = credentials
        self.config = config or {}

    @abstractmethod
    def _connect_sync(self):
        """Opens and returns a live connection using self.credentials/self.config."""

    @abstractmethod
    def _execute_query_sync(self, conn, sql: str, param_names: list, params: dict) -> dict:
        """Executes a parameterized SELECT/DML statement. `param_names` is the ordered list of
        bind names declared in the action config; `params` is the caller-supplied values dict."""

    @abstractmethod
    def _execute_procedure_sync(self, conn, procedure_name: str, param_defs: list, params: dict) -> dict:
        """Executes a stored procedure. `param_defs` is the action config's list of
        {"name": ..., "type": "IN"|"OUT"} entries."""

    @abstractmethod
    def _close_sync(self, conn) -> None:
        """Closes the connection, releasing any driver-specific resources."""

    def _commit_sync(self, conn) -> None:
        conn.commit()

    def _rollback_sync(self, conn) -> None:
        conn.rollback()

    async def run_action(self, action_cfg: dict, params: dict) -> dict:
        """Public async entry point -- runs the full connect -> execute -> commit/rollback ->
        close lifecycle in a worker thread (asyncio.to_thread), per this repo's existing sync
        driver + to_thread convention (see app/targetsystems/mssql.py)."""
        return await asyncio.to_thread(self._run_action_sync, action_cfg, dict(params or {}))

    def _run_action_sync(self, action_cfg: dict, params: dict) -> dict:
        conn = self._connect_sync()
        try:
            execution_type = action_cfg["execution_type"]
            if execution_type == "query":
                result = self._execute_query_sync(conn, action_cfg["sql"], action_cfg.get("params", []), params)
            elif execution_type == "procedure":
                result = self._execute_procedure_sync(
                    conn, action_cfg["procedure_name"], action_cfg.get("params", []), params
                )
            else:
                raise ValueError(f"Unsupported execution_type: {execution_type}")
            self._commit_sync(conn)
            return result
        except Exception:
            try:
                self._rollback_sync(conn)
            except Exception:
                pass  # connection may already be dead -- the original exception is what matters
            raise
        finally:
            try:
                self._close_sync(conn)
            except Exception:
                pass
