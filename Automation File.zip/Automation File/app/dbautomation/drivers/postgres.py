import re

import psycopg2
import psycopg2.extras

from app.dbautomation.drivers.base import BaseDriver

_POSITIONAL_PLACEHOLDER_RE = re.compile(r"\$\d+")


class PostgresDriver(BaseDriver):
    connector_type = "postgres"

    def _connect_sync(self):
        creds = self.credentials
        if not creds.get("host") or not creds.get("username") or not creds.get("password"):
            raise RuntimeError("Missing Postgres connection details: need 'host', 'username', and 'password'")

        connect_kwargs = {
            "host": creds["host"],
            "port": int(creds.get("port") or 5432),
            "user": creds["username"],
            "password": creds["password"],
            "dbname": creds.get("database") or creds.get("dsn"),
            "connect_timeout": self.config.get("timeout_seconds", 30),
        }
        if creds.get("ssl_cert"):
            connect_kwargs["sslmode"] = "verify-full"
            connect_kwargs["sslrootcert"] = creds["ssl_cert"]
        return psycopg2.connect(**connect_kwargs)

    def _execute_query_sync(self, conn, sql: str, param_names: list, params: dict) -> dict:
        missing = [name for name in param_names if name not in params]
        if missing:
            raise ValueError(f"Missing required param(s) for query: {missing}")

        # Config SQL uses $1/$2/... (per the schema spec's Postgres example); psycopg2's DB-API
        # only understands %s positional placeholders, and binds tuple values to them strictly
        # by position -- so $N ordinal position must match `params` list order, which it does by
        # construction (both are declared left-to-right in the same config entry).
        pyformat_sql = _POSITIONAL_PLACEHOLDER_RE.sub("%s", sql)
        bind_values = tuple(params[name] for name in param_names)

        cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        try:
            cursor.execute(pyformat_sql, bind_values)
            if cursor.description is None:
                return {"rowCount": cursor.rowcount}
            rows = [dict(row) for row in cursor.fetchall()]
            return {"rows": rows, "rowCount": len(rows)}
        finally:
            cursor.close()

    def _execute_procedure_sync(self, conn, procedure_name: str, param_defs: list, params: dict) -> dict:
        if any((p.get("type") or "IN").upper() == "OUT" for p in param_defs):
            raise NotImplementedError(
                "OUT parameters for Postgres procedures are not implemented in this pass "
                "(no Postgres procedure example in the current schema) -- add support in "
                "drivers/postgres.py when a real procedure config is defined."
            )

        call_values = []
        for param_def in param_defs:
            name = param_def["name"]
            if name not in params:
                raise ValueError(f"Missing required IN param '{name}' for procedure {procedure_name}")
            call_values.append(params[name])

        cursor = conn.cursor()
        try:
            cursor.callproc(procedure_name, call_values)
            if cursor.description is None:
                return {"status": "executed"}
            columns = [col[0] for col in cursor.description]
            rows = [dict(zip(columns, row)) for row in cursor.fetchall()]
            return {"rows": rows, "rowCount": len(rows)}
        finally:
            cursor.close()

    def _close_sync(self, conn) -> None:
        conn.close()
