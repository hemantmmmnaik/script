import oracledb

from app.dbautomation.drivers.base import BaseDriver

oracledb.defaults.fetch_lobs = False


class OracleDriver(BaseDriver):
    """Uses oracledb's SYNC client (oracledb.connect), not the async client used by
    app/targetsystems/oracle.py -- this module runs every driver via asyncio.to_thread
    uniformly, so a sync connection is the correct fit here."""

    connector_type = "oracle"

    def _connect_sync(self):
        creds = self.credentials
        dsn = creds.get("dsn") or self._build_dsn(creds)
        if not dsn or not creds.get("username") or not creds.get("password"):
            raise RuntimeError(
                "Missing Oracle connection details: need 'dsn' (or 'host'+'port'+'database'), "
                "'username', and 'password'"
            )
        return oracledb.connect(user=creds["username"], password=creds["password"], dsn=dsn)

    @staticmethod
    def _build_dsn(creds: dict):
        host, port, database = creds.get("host"), creds.get("port"), creds.get("database")
        if not (host and port and database):
            return None
        return f"{host}:{port}/{database}"

    def _execute_query_sync(self, conn, sql: str, param_names: list, params: dict) -> dict:
        missing = [name for name in param_names if name not in params]
        if missing:
            raise ValueError(f"Missing required param(s) for query: {missing}")

        cursor = conn.cursor()
        try:
            # oracledb binds :name placeholders natively from a dict -- no string interpolation.
            bind_values = {name: params[name] for name in param_names}
            cursor.execute(sql, bind_values)
            if cursor.description is None:
                return {"rowCount": cursor.rowcount}
            columns = [col[0] for col in cursor.description]
            rows = [dict(zip(columns, row)) for row in cursor.fetchall()]
            return {"rows": rows, "rowCount": len(rows)}
        finally:
            cursor.close()

    # Maps a param_def's optional "data_type" to the oracledb var type used to bind it. Params
    # with no data_type (every pre-existing config entry) fall back to STRING, matching the old
    # unconditional `cursor.var(oracledb.STRING)` behavior -- fully backward compatible.
    _OUT_VAR_TYPES = {
        "NUMBER": oracledb.NUMBER,
        "VARCHAR2": oracledb.STRING,
        "STRING": oracledb.STRING,
        "SYS_REFCURSOR": oracledb.CURSOR,
    }

    def _execute_procedure_sync(self, conn, procedure_name: str, param_defs: list, params: dict) -> dict:
        cursor = conn.cursor()
        try:
            call_args = []
            out_vars = {}
            cursor_out_names = set()
            for param_def in param_defs:
                name = param_def["name"]
                direction = (param_def.get("type") or "IN").upper()
                data_type = (param_def.get("data_type") or "").upper()
                if direction == "OUT":
                    var = cursor.var(self._OUT_VAR_TYPES.get(data_type, oracledb.STRING))
                    out_vars[name] = var
                    if data_type == "SYS_REFCURSOR":
                        cursor_out_names.add(name)
                    call_args.append(var)
                else:
                    if name not in params:
                        raise ValueError(f"Missing required IN param '{name}' for procedure {procedure_name}")
                    value = params[name]
                    if data_type == "NUMBER" and value is not None:
                        value = int(value)
                    call_args.append(value)

            cursor.callproc(procedure_name, call_args)

            if out_vars:
                outputs = {}
                for name, var in out_vars.items():
                    if name in cursor_out_names:
                        # A SYS_REFCURSOR OUT param comes back as a live cursor -- materialize it
                        # into list[dict] rows here (same shape _execute_query_sync returns for
                        # "rows") so app/targetsystems/__init__.py's entitlement matching works
                        # identically whether check_access is a plain query or a procedure.
                        ref_cursor = var.getvalue()
                        columns = [col[0] for col in ref_cursor.description]
                        outputs[name] = [dict(zip(columns, row)) for row in ref_cursor.fetchall()]
                        ref_cursor.close()
                    else:
                        outputs[name] = var.getvalue()
                return {"outputs": outputs}
            return {"status": "executed"}
        finally:
            cursor.close()

    def _close_sync(self, conn) -> None:
        conn.close()
