import pymysql
import pymysql.cursors

from app.dbautomation.drivers.base import BaseDriver


class MySQLDriver(BaseDriver):
    """Also registered for connector_type "mariadb" -- PyMySQL speaks MariaDB's wire protocol
    without modification."""

    connector_type = "mysql"

    def _connect_sync(self):
        creds = self.credentials
        if not creds.get("host") or not creds.get("username") or not creds.get("password"):
            raise RuntimeError("Missing MySQL connection details: need 'host', 'username', and 'password'")

        connect_kwargs = {
            "host": creds["host"],
            "port": int(creds.get("port") or 3306),
            "user": creds["username"],
            "password": creds["password"],
            "database": creds.get("database"),
            "connect_timeout": self.config.get("timeout_seconds", 30),
            "cursorclass": pymysql.cursors.DictCursor,
            "autocommit": False,
        }
        if creds.get("ssl_cert"):
            connect_kwargs["ssl"] = {"ca": creds["ssl_cert"]}
        return pymysql.connect(**connect_kwargs)

    def _execute_query_sync(self, conn, sql: str, param_names: list, params: dict) -> dict:
        missing = [name for name in param_names if name not in params]
        if missing:
            raise ValueError(f"Missing required param(s) for query: {missing}")

        # Config SQL uses PyMySQL's native %s positional placeholders; `params` list order
        # dictates bind-tuple order -- never interpolated into the SQL string.
        bind_values = tuple(params[name] for name in param_names)

        with conn.cursor() as cursor:
            cursor.execute(sql, bind_values)
            if cursor.description is None:
                return {"rowCount": cursor.rowcount}
            rows = cursor.fetchall()
            return {"rows": rows, "rowCount": len(rows)}

    def _execute_procedure_sync(self, conn, procedure_name: str, param_defs: list, params: dict) -> dict:
        if any((p.get("type") or "IN").upper() == "OUT" for p in param_defs):
            raise NotImplementedError(
                "OUT parameters for MySQL procedures require PyMySQL's session-variable "
                "workaround (@_proc_N) and are not implemented in this pass -- add support in "
                "drivers/mysql.py when a real MySQL procedure config is defined."
            )

        call_values = [params[p["name"]] for p in param_defs if _require_param(p, params)]

        with conn.cursor() as cursor:
            cursor.callproc(procedure_name, call_values)
            if cursor.description is None:
                return {"status": "executed"}
            rows = cursor.fetchall()
            return {"rows": rows, "rowCount": len(rows)}

    def _close_sync(self, conn) -> None:
        conn.close()


def _require_param(param_def: dict, params: dict) -> bool:
    name = param_def["name"]
    if name not in params:
        raise ValueError(f"Missing required IN param '{name}' for procedure call")
    return True
