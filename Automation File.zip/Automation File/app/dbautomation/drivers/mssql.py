import pytds

from app.dbautomation.drivers.base import BaseDriver


class MSSQLDriver(BaseDriver):
    connector_type = "mssql"

    def _connect_sync(self):
        creds = self.credentials
        if not creds.get("host") or not creds.get("username") or not creds.get("password"):
            raise RuntimeError("Missing MSSQL connection details: need 'host', 'username', and 'password'")

        return pytds.connect(
            server=creds["host"],
            database=creds.get("database"),
            user=creds["username"],
            password=creds["password"],
            port=int(creds.get("port") or 1433),
            autocommit=False,
        )

    def _execute_query_sync(self, conn, sql: str, param_names: list, params: dict) -> dict:
        missing = [name for name in param_names if name not in params]
        if missing:
            raise ValueError(f"Missing required param(s) for query: {missing}")

        # Config SQL uses raw T-SQL @name binds (this repo's admin-facing convention, see
        # app/targetsystems/mssql.py); pytds' DB-API layer expects pyformat %(name)s, so translate.
        pyformat_sql = sql
        for name in param_names:
            pyformat_sql = pyformat_sql.replace(f"@{name}", f"%({name})s")
        bind_values = {name: params[name] for name in param_names}

        with conn.cursor() as cursor:
            cursor.execute(pyformat_sql, bind_values)
            if cursor.description is None:
                return {"rowCount": cursor.rowcount}
            columns = [col[0] for col in cursor.description]
            rows = [dict(zip(columns, row)) for row in cursor.fetchall()]
            return {"rows": rows, "rowCount": len(rows)}

    def _execute_procedure_sync(self, conn, procedure_name: str, param_defs: list, params: dict) -> dict:
        call_args = []
        out_positions = {}
        for index, param_def in enumerate(param_defs):
            name = param_def["name"]
            direction = (param_def.get("type") or "IN").upper()
            if direction == "OUT":
                call_args.append(pytds.output(value=0))
                out_positions[name] = index
            else:
                if name not in params:
                    raise ValueError(f"Missing required IN param '{name}' for procedure {procedure_name}")
                call_args.append(params[name])

        with conn.cursor() as cursor:
            result = cursor.callproc(procedure_name, call_args)
            if out_positions:
                return {"outputs": {name: result[index] for name, index in out_positions.items()}}
            return {"status": "executed"}

    def _close_sync(self, conn) -> None:
        conn.close()
