from typing import Optional

from config import apps as apps_config

VALID_EXECUTION_TYPES = {"query", "procedure"}


def get_app_config(app_id: str) -> dict:
    """Reads config/db-target-system.json fresh on every call (no in-process caching), matching
    app.services.target_systems_service.get_for_app()'s "always read the current file" model --
    this file is shared/global config, not per-session state. Scoped to the currently selected
    environment (see config/apps.py, config/env_bootstrap.py)."""
    config = apps_config.get_app_config(app_id)
    if not config.get("connector_type"):
        raise ValueError(f"App '{app_id}' is missing required key 'connector_type'")
    if not isinstance(config.get("actions"), dict) or not config["actions"]:
        raise ValueError(f"App '{app_id}' is missing a non-empty 'actions' object")
    return config


def get_action_config(app_id: str, action_name: str) -> dict:
    app_config = get_app_config(app_id)
    action = app_config["actions"].get(action_name)
    if not action:
        raise LookupError(f"No action '{action_name}' defined for app '{app_id}'")

    execution_type = action.get("execution_type")
    if execution_type not in VALID_EXECUTION_TYPES:
        raise ValueError(
            f"App '{app_id}' action '{action_name}' has invalid execution_type "
            f"'{execution_type}' (expected one of {sorted(VALID_EXECUTION_TYPES)})"
        )

    if execution_type == "query":
        if not action.get("sql"):
            raise ValueError(f"App '{app_id}' action '{action_name}' is a query but has no 'sql'")
        if not isinstance(action.get("params", []), list):
            raise ValueError(f"App '{app_id}' action '{action_name}' 'params' must be a list")
    else:  # procedure
        if not action.get("procedure_name"):
            raise ValueError(f"App '{app_id}' action '{action_name}' is a procedure but has no 'procedure_name'")
        if not isinstance(action.get("params", []), list):
            raise ValueError(f"App '{app_id}' action '{action_name}' 'params' must be a list of param defs")

    return action


def get_connector_type(app_id: str) -> str:
    return get_app_config(app_id)["connector_type"]


def get_pool_settings(app_id: str) -> dict:
    return get_app_config(app_id).get("config", {}) or {}


def get_entitlement_column(app_id: str) -> Optional[str]:
    """Column in the check_access row-set that holds the entitlement/role/group value to match
    against a requested entitlement code -- see app.targetsystems._matches_entitlement. Returns
    None for apps whose check_access has no per-row entitlement granularity (e.g. Solve Engine)."""
    return get_app_config(app_id).get("entitlementColumn")
