"""Multi-database automation engine: executes named, config-defined query/procedure actions
against per-app_id-configured database connectors (Oracle/PostgreSQL/MySQL today; the registry
in app.dbautomation.registry is designed to add more dialects without touching this module).

Public entry point: execute_action(app_id, action_name, params).
"""

from app.dbautomation import config, registry
from app.dbautomation.errors import DBAutomationError, scrub_sensitive
from app.dbautomation.secrets import get_secrets_provider

__all__ = ["execute_action", "DBAutomationError"]


async def execute_action(app_id: str, action_name: str, params: dict) -> dict:
    app_config = config.get_app_config(app_id)
    action_config = config.get_action_config(app_id, action_name)
    connector_type = app_config["connector_type"]

    try:
        driver_cls = registry.get_driver(connector_type)
        credentials = get_secrets_provider().get_credentials(app_id)
        driver = driver_cls(credentials, app_config.get("config", {}))
        result = await driver.run_action(action_config, params or {})
        return {"appId": app_id, "action": action_name, "connectorType": connector_type, "status": "success", "result": result}
    except DBAutomationError:
        raise
    except Exception as exc:
        raise DBAutomationError(
            app_id=app_id,
            action_name=action_name,
            message=scrub_sensitive(str(exc)),
            connector_type=connector_type,
        ) from exc
