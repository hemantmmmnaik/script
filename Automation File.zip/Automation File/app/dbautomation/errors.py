import re
from typing import Optional

_SENSITIVE_PATTERNS = [
    # key=value / key: value style credential fields (password, pwd, secret, token, apikey, ...)
    re.compile(r"(?i)\b(password|pwd|passwd|secret|token|apikey|api_key|access_key)\s*[=:]\s*[^\s,;&]+"),
    # user:password@host connection-string credentials (postgres://user:pw@host, mysql://..., oracle://...)
    re.compile(r"://[^/\s:@]+:[^/\s:@]+@"),
    # Authorization: Bearer <token> / Basic <b64>
    re.compile(r"(?i)\b(Bearer|Basic)\s+[A-Za-z0-9\-_.=]+"),
    # DSN-style connect strings (host=...;port=...;uid=...;pwd=... or "HOST=x;PORT=y;...")
    re.compile(r"(?i)\b(uid|user id)\s*=\s*[^;,\s]+"),
    # Hostname/DSN fragments that leak infrastructure details (Data Source=, Server=, Host=)
    re.compile(r"(?i)\b(data source|server|host)\s*=\s*[^;,\s]+"),
    # bare host:port sequences (e.g. db.internal:5432, oracle-prod:1521) left over after a
    # scheme://user:pass@ prefix has already been redacted above
    re.compile(r"\b[A-Za-z0-9][A-Za-z0-9.\-]*\.[A-Za-z]{2,}:\d{2,5}\b"),
]

_REDACTED = "***REDACTED***"


def scrub_sensitive(text: Optional[str]) -> str:
    """Strips password/secret/token/connection-string credentials out of a message before it's
    allowed into a log line or an API response. Applied at one choke point (DBAutomationError)
    rather than trusted to every individual driver."""
    if not text:
        return ""
    scrubbed = str(text)
    for pattern in _SENSITIVE_PATTERNS:
        scrubbed = pattern.sub(_REDACTED, scrubbed)
    return scrubbed


class DBAutomationError(Exception):
    """Domain-specific exception carrying structured context (app_id/action/connector_type)
    instead of a raw driver message -- mirrors app.okta_client.OktaApiError's pattern of
    structured fields over a bare string. `message` MUST already be scrubbed by the caller
    via scrub_sensitive() before being passed in."""

    def __init__(self, app_id: str, action_name: str, message: str, connector_type: Optional[str] = None):
        self.app_id = app_id
        self.action_name = action_name
        self.message = message
        self.connector_type = connector_type
        super().__init__(self._format())

    def _format(self) -> str:
        prefix = f"[{self.connector_type}] " if self.connector_type else ""
        return f"{prefix}Action '{self.action_name}' failed for app '{self.app_id}': {self.message}"
