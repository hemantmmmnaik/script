from typing import Optional

import httpx

from app.okta_client import api_base, m2m_headers, raise_for_okta_error, user_headers

LIFECYCLE_ACTIONS = {"activate", "deactivate", "suspend", "unsuspend", "reactivate", "unlock"}


class SessionExpiredError(Exception):
    pass


async def search_users(access_token: Optional[str], q: str = "", filter_: str = "") -> list:
    if not access_token:
        raise SessionExpiredError("No access token in session")

    params = {"limit": 50}
    if q:
        params["q"] = q
    if filter_:
        params["filter"] = filter_

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(f"{api_base()}/users", params=params, headers=await user_headers(access_token))
    raise_for_okta_error(resp)
    return resp.json()


async def get_user(access_token: Optional[str], user_id: str) -> dict:
    if not access_token:
        raise SessionExpiredError("No access token in session")

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(f"{api_base()}/users/{user_id}", headers=await user_headers(access_token))
    raise_for_okta_error(resp)
    return resp.json()


async def get_user_by_id(user_id: str) -> dict:
    """M2M-based user lookup — unlike get_user(), doesn't need a caller's OIDC session token."""
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(f"{api_base()}/users/{user_id}", headers=await m2m_headers())
    raise_for_okta_error(resp)
    return resp.json()


async def get_user_by_email(email: str) -> dict:
    """M2M-based user lookup by profile.email; doesn't need a caller's OIDC session token."""
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(
            f"{api_base()}/users",
            params={"search": f'profile.email eq "{email}"', "limit": 1},
            headers=await m2m_headers(),
        )
    raise_for_okta_error(resp)
    results = resp.json()
    if not results:
        raise ValueError(f'No user found with email "{email}"')
    return results[0]


async def run_lifecycle_action(user_id: str, action: str) -> dict:
    if action not in LIFECYCLE_ACTIONS:
        raise ValueError(f"Invalid lifecycle action: {action}")

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(f"{api_base()}/users/{user_id}/lifecycle/{action}", headers=await m2m_headers())
    raise_for_okta_error(resp)
    return resp.json() if resp.content else {"ok": True}
