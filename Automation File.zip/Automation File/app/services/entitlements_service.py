import asyncio
from typing import Optional

import httpx

from app.okta_client import api_base, expect_list, gov_base, gov_v2_base, m2m_headers, raise_for_okta_error

SIGN_ON_MODE_TO_ORN_TYPE = {
    "OPENID_CONNECT": "oidc_client",
    "SAML_2_0": "saml_2_0",
    "SAML_1_1": "saml_1_1",
    "BOOKMARK": "bookmark",
    "AUTO_LOGIN": "auto_login",
    "SWA": "swa",
    "BROWSER_PLUGIN": "browser_plugin",
    "SECURE_PASSWORD_STORE": "secure_password_store",
    "WS_FEDERATION": "ws_federation",
}


def sign_on_mode_to_orn_type(sign_on_mode: Optional[str]) -> str:
    if sign_on_mode in SIGN_ON_MODE_TO_ORN_TYPE:
        return SIGN_ON_MODE_TO_ORN_TYPE[sign_on_mode]
    return sign_on_mode.lower() if sign_on_mode else "okta"


async def logs_since(ts: str, filter_expr: Optional[str] = None, limit: int = 50) -> list:
    """Queries the Okta System Log (https://developer.okta.com/docs/reference/system-log-query/),
    GET /api/v1/logs. `filter_expr` is passed through as the `filter` query param verbatim (e.g.
    'target.id eq "0oaXXXX"') -- Okta's System Log filter grammar, not a local Python filter."""
    if not ts:
        raise ValueError("ts required")
    headers = await m2m_headers()
    params = {"since": ts, "limit": limit}
    if filter_expr:
        params["filter"] = filter_expr
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(f"{api_base()}/logs", params=params, headers=headers)
    raise_for_okta_error(resp)
    data = resp.json()
    return expect_list(data, "GET /api/v1/logs") if data else []


async def create_entitlement_value(entitlement_id: str, body: dict) -> dict:
    """Adds a value to an entitlement.

    Okta has no `POST .../values` endpoint — values are added via a JSON-Patch
    `PATCH` on the entitlement itself, and the entitlement-value resource only
    ever has a `name` field (no separate `value`/`displayName`).
    """
    headers = await m2m_headers()
    patch_value = {"name": body["name"]}
    if body.get("description"):
        patch_value["description"] = body["description"]
    patch_body = [{"op": "ADD", "path": "/values/-", "value": patch_value, "refType": "ENTITLEMENT-VALUE"}]
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.patch(f"{gov_base()}/entitlements/{entitlement_id}", json=patch_body, headers=headers)
    raise_for_okta_error(resp)
    data = resp.json()
    values = data.get("values") or []
    return values[-1] if values else data


async def create_bundle(body: dict) -> dict:
    headers = await m2m_headers()
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(f"{gov_base()}/entitlement-bundles", json=body, headers=headers)
    raise_for_okta_error(resp)
    return resp.json()


async def update_bundle(bundle_id: str, body: dict) -> dict:
    headers = await m2m_headers()
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.put(f"{gov_base()}/entitlement-bundles/{bundle_id}", json=body, headers=headers)
    raise_for_okta_error(resp)
    return resp.json()


async def delete_bundle(bundle_id: str) -> dict:
    headers = await m2m_headers()
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.delete(f"{gov_base()}/entitlement-bundles/{bundle_id}", headers=headers)
    raise_for_okta_error(resp)
    return {"ok": True}


async def create_grant(body: dict) -> dict:
    headers = await m2m_headers()
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(f"{gov_base()}/grants", json=body, headers=headers)
    raise_for_okta_error(resp)
    return resp.json()


async def delete_grant(
    grant_id: str,
    grant_type: Optional[str] = None,
    app_id: Optional[str] = None,
    user_id: Optional[str] = None,
    entitlement_bundle_id: Optional[str] = None,
    hard_delete: bool = False,
) -> dict:
    headers = await m2m_headers()
    async with httpx.AsyncClient(timeout=30) as client:
        if hard_delete:
            resp = await client.delete(f"{gov_base()}/grants/{grant_id}", headers=headers)
        elif grant_type == "CUSTOM":
            resp = await client.post(
                f"{gov_base()}/grants",
                json={
                    "grantType": "POLICY",
                    "target": {"externalId": app_id, "type": "APPLICATION"},
                    "targetPrincipal": {"externalId": user_id, "type": "OKTA_USER"},
                },
                headers=headers,
            )
        else:
            body = {
                "grantType": grant_type,
                "target": {"externalId": app_id, "type": "APPLICATION"},
                "targetPrincipal": {"externalId": user_id, "type": "OKTA_USER"},
                "action": "DENY",
            }
            if entitlement_bundle_id:
                body["entitlementBundleId"] = entitlement_bundle_id
            resp = await client.post(f"{gov_base()}/grants", json=body, headers=headers)
    raise_for_okta_error(resp)
    return {"ok": True}


async def revoke_all(user_id: str, app_id: str) -> dict:
    if not user_id or not app_id:
        raise ValueError("userId and appId required")

    headers = await m2m_headers()
    async with httpx.AsyncClient(timeout=30) as client:
        org_resp, app_resp = await asyncio.gather(
            client.get(f"{api_base()}/org", headers=headers),
            client.get(f"{api_base()}/apps/{app_id}", headers=headers),
        )
        raise_for_okta_error(org_resp)
        raise_for_okta_error(app_resp)
        org_id = org_resp.json()["id"]
        orn_type = sign_on_mode_to_orn_type(app_resp.json().get("signOnMode"))

        principal_orn = f"orn:okta:directory:{org_id}:users:{user_id}"
        app_orn = f"orn:okta:idp:{org_id}:apps:{orn_type}:{app_id}"
        body = {"principalOrn": principal_orn, "actor": "ADMIN", "revokeOrns": [app_orn]}

        resp = await client.post(f"{gov_v2_base()}/revoke-principal-access", json=body, headers=headers)
    raise_for_okta_error(resp)
    result = resp.json() if resp.content else {}
    return {"ok": True, "principalOrn": principal_orn, "appOrn": app_orn, **result}
