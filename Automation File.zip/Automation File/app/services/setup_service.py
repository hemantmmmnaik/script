import httpx

from app import config_store, settings
from app.okta_client import m2m_headers, raise_for_okta_error


class AlreadyConfiguredError(Exception):
    pass


def get_status() -> dict:
    return {"configured": config_store.has_config()}


def get_tenant() -> dict:
    return {"domain": settings.okta_domain()}


async def run_setup(reset: bool = False) -> dict:
    if config_store.has_config() and not reset:
        raise AlreadyConfiguredError("Setup already completed")

    domain = settings.okta_domain()
    headers = await m2m_headers()

    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(f"https://{domain}/api/v1/org", headers=headers)

    raise_for_okta_error(resp)
    org = resp.json()
    config_store.save_config({"domain": domain, "orgId": org["id"]})
    return {"ok": True, "orgId": org["id"]}
