import asyncio
from typing import Optional

import httpx

from app.concurrency import run_limited
from app.okta_client import api_base, expect_list, gov_base, m2m_headers, raise_for_okta_error, unwrap_single, user_headers


async def _get_with_fallback(url: str, params: dict, access_token: Optional[str]) -> dict:
    """Try the caller's OIDC token first; fall back to the M2M token on 401/403."""
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(url, params=params, headers=await user_headers(access_token))
        if resp.status_code in (401, 403) and access_token:
            resp = await client.get(url, params=params, headers=await m2m_headers())
    raise_for_okta_error(resp)
    return resp.json()


async def search_users(access_token: Optional[str], q: str = "") -> list:
    search = (
        f'profile.login co "{q}" OR profile.email co "{q}" OR '
        f'profile.firstName co "{q}" OR profile.lastName co "{q}"'
    )
    data = await _get_with_fallback(f"{api_base()}/users", {"search": search, "limit": 25}, access_token)
    return expect_list(data, "GET /api/v1/users")


async def get_user(access_token: Optional[str], user_id: str) -> dict:
    return await _get_with_fallback(f"{api_base()}/users/{user_id}", {}, access_token)


async def get_app(app_id: str) -> dict:
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(f"{api_base()}/apps/{app_id}", headers=await m2m_headers())
    raise_for_okta_error(resp)
    return resp.json()


async def search_users_by_emails(emails: list, batch_size: int = 20) -> dict:
    """Batched exact-email lookup: resolves a whole test file's worth of user_email cells to
    real Okta users in as few API calls as possible. Distinct from search_users()'s single
    free-text "contains" query, which is built for an interactive user-picker, not batch exact
    matching -- kept separate rather than merged into one do-everything function."""
    unique_emails = sorted({e.strip() for e in emails if e and e.strip()})
    users_by_email = {}
    for i in range(0, len(unique_emails), batch_size):
        batch = unique_emails[i:i + batch_size]
        search = " or ".join(f'profile.email eq "{email}"' for email in batch)
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.get(
                f"{api_base()}/users", params={"search": search, "limit": 200}, headers=await m2m_headers()
            )
        raise_for_okta_error(resp)
        for user in expect_list(resp.json(), "GET /api/v1/users?search=..."):
            email = (user.get("profile", {}) or {}).get("email", "")
            if email:
                users_by_email[email.strip().lower()] = user
    return users_by_email

async def search_apps(q: str = "") -> list:
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(
            f"{api_base()}/apps",
            params={"q": q, "limit": 25, "filter": 'status eq "ACTIVE"'},
            headers=await m2m_headers(),
        )
    raise_for_okta_error(resp)
    return expect_list(resp.json(), "GET /api/v1/apps")


async def assign_user_to_app(app_id: str, user_id: str, user_name: Optional[str] = None) -> dict:
    if not user_id:
        raise ValueError("userId is required")
    body = {"id": user_id, "scope": "USER"}
    if user_name:
        body["credentials"] = {"userName": user_name}
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(f"{api_base()}/apps/{app_id}/users", json=body, headers=await m2m_headers())
    raise_for_okta_error(resp)
    return resp.json()


async def get_app_groups(app_id: str) -> list:
    headers = await m2m_headers()
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(f"{api_base()}/apps/{app_id}/groups", params={"limit": 100}, headers=headers)
        raise_for_okta_error(resp)
        assignments = expect_list(resp.json(), "GET /api/v1/apps/{id}/groups")

        async def enrich(assignment: dict) -> dict:
            gid = assignment["id"]
            try:
                gresp = await client.get(f"{api_base()}/groups/{gid}", headers=headers)
                raise_for_okta_error(gresp)
                return gresp.json()
            except Exception:
                return {"id": gid, "profile": {"name": gid}}

        return await asyncio.gather(*(enrich(a) for a in assignments))


async def assign_user_to_group(app_id: str, group_id: str, user_id: str) -> dict:
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.put(f"{api_base()}/groups/{group_id}/users/{user_id}", headers=await m2m_headers())
    raise_for_okta_error(resp)
    return {"ok": True}


async def remove_user_from_app(app_id: str, user_id: str) -> dict:
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.delete(f"{api_base()}/apps/{app_id}/users/{user_id}", headers=await m2m_headers())
    raise_for_okta_error(resp)
    return {"ok": True}


async def get_principal_access(app_id: str, user_id: str) -> dict:
    if not user_id:
        raise ValueError("userId is required")
    filter_ = (
        f'parent.externalId eq "{app_id}" AND parent.type eq "APPLICATION" AND '
        f'targetPrincipal.externalId eq "{user_id}" AND targetPrincipal.type eq "OKTA_USER"'
    )
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(
            f"{gov_base()}/principal-access", params={"filter": filter_}, headers=await m2m_headers()
        )
    raise_for_okta_error(resp)
    return unwrap_single(resp.json())


async def get_app_user_assignment(app_id: str, user_id: str) -> dict:
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(f"{api_base()}/apps/{app_id}/users/{user_id}", headers=await m2m_headers())
    if resp.status_code == 404:
        return {"assigned": False}
    raise_for_okta_error(resp)
    return {"assigned": True, "appUser": resp.json()}


async def get_app_entitlements(app_id: str) -> list:
    filter_ = f'parent.externalId eq "{app_id}" AND parent.type eq "APPLICATION"'
    headers = await m2m_headers()
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(f"{gov_base()}/entitlements", params={"filter": filter_, "limit": 50}, headers=headers)
        raise_for_okta_error(resp)
        schemas = expect_list(resp.json(), "GET /governance/api/v1/entitlements")

        async def load_values(schema: dict) -> dict:
            href = (schema.get("_links", {}).get("values") or {}).get("href")
            if not href:
                return {**schema, "values": []}
            try:
                vresp = await client.get(href, headers=headers)
                raise_for_okta_error(vresp)
                return {**schema, "values": expect_list(vresp.json(), "entitlement values href")}
            except Exception:
                return {**schema, "values": []}

        return await asyncio.gather(*(load_values(s) for s in schemas))


async def get_app_bundles(app_id: str) -> list:
    filter_ = f'target.externalId eq "{app_id}"'
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(
            f"{gov_base()}/entitlement-bundles",
            params={"filter": filter_, "limit": 100, "include": "full_entitlements"},
            headers=await m2m_headers(),
        )
    raise_for_okta_error(resp)
    return expect_list(resp.json(), "GET /governance/api/v1/entitlement-bundles")


async def batch_load(app_ids: list, skip_values: bool = False, skip_bundles: bool = False) -> list:
    if not app_ids:
        raise ValueError("appIds is required")

    async def load_one(app_id: str) -> dict:
        result = {"appId": app_id, "status": "loaded", "entitlements": [], "bundles": []}
        try:
            if not skip_values:
                result["entitlements"] = await get_app_entitlements(app_id)
            if not skip_bundles:
                result["bundles"] = await get_app_bundles(app_id)
        except Exception as exc:
            result["status"] = "error"
            result["error"] = str(exc)
        return result

    return await run_limited([lambda a=app_id: load_one(a) for app_id in app_ids], limit=5)


async def batch_grants(app_ids: list, user_id: str) -> list:
    if not user_id:
        raise ValueError("userId is required")

    async def load_one(app_id: str) -> dict:
        filter_ = (
            f'targetPrincipal.externalId eq "{user_id}" AND targetPrincipal.type eq "OKTA_USER" AND '
            f'target.externalId eq "{app_id}" AND target.type eq "APPLICATION"'
        )
        try:
            async with httpx.AsyncClient(timeout=30) as client:
                resp = await client.get(
                    f"{gov_base()}/grants",
                    params={"filter": filter_, "limit": 100, "include": "full_entitlements"},
                    headers=await m2m_headers(),
                )
            raise_for_okta_error(resp)
            return {"appId": app_id, "grants": expect_list(resp.json(), "GET /governance/api/v1/grants")}
        except Exception as exc:
            return {"appId": app_id, "grants": [], "error": str(exc)}

    return await run_limited([lambda a=app_id: load_one(a) for app_id in app_ids], limit=5)
