from datetime import datetime, timezone
from pathlib import Path

from app.settings import DATA_DIR

REPORTS_DIR = DATA_DIR / "reports"


def write_queue_report(results: list) -> Path:
    """Writes a plain-text success/failure report for a finished queue run and returns its path."""
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    path = REPORTS_DIR / f"queue-report-{stamp}.txt"

    succeeded = [r for r in results if r["status"] == "success"]
    failed = [r for r in results if r["status"] != "success"]
    checks = [r for r in results if r.get("targetSystemCheck")]
    checks_ok = [r for r in checks if r["targetSystemCheck"] == "verified"]
    checks_failed = [r for r in checks if r["targetSystemCheck"] != "verified"]

    lines = [
        f"Queue Report — {datetime.now(timezone.utc).isoformat()}",
        f"Total: {len(results)}  Success: {len(succeeded)}  Failed: {len(failed)}",
        f"Target system checks: {len(checks)}  Verified: {len(checks_ok)}  Failed: {len(checks_failed)}",
        "",
    ]
    for r in results:
        line = (
            f"[{r['status'].upper()}] app={r.get('app') or ''} | action={r.get('action') or ''} | "
            f"target={r.get('target') or ''} | user={r.get('user') or ''}"
        )
        if r["status"] != "success" and r.get("error"):
            line += f" | error={r['error']}"
        tsc = r.get("targetSystemCheck")
        if tsc:
            line += f" | targetSystemCheck={tsc.upper()}"
            if tsc != "verified" and r.get("targetSystemCheckError"):
                line += f" ({r['targetSystemCheckError']})"
        lines.append(line)

    path.write_text("\n".join(lines) + "\n")
    return path
