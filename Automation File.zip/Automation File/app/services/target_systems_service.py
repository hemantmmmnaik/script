import json
from datetime import datetime, timezone
from typing import Optional

from app.settings import DATA_DIR

VALID_TYPES = {"AD", "ENTRAID", "ORACLE", "MSSQL", "WEBSERVICE"}

CONFIG_PATH = DATA_DIR / "targetSystems.json"


def read_all() -> dict:
    if not CONFIG_PATH.exists():
        return {}
    return json.loads(CONFIG_PATH.read_text())


def _write_all(data: dict) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(data, indent=2))


def get_for_app(app_id: str) -> Optional[dict]:
    return read_all().get(app_id)


def set_for_app(app_id: str, config: dict) -> dict:
    if config.get("type") not in VALID_TYPES:
        raise ValueError(f"Invalid target system type: {config.get('type')}")
    data = read_all()
    data[app_id] = config
    _write_all(data)
    return config


def remove_for_app(app_id: str) -> None:
    data = read_all()
    if app_id in data:
        del data[app_id]
        _write_all(data)


async def validate(app_id: str, user_login: str, entitlement_values: list, user_id: Optional[str] = None) -> dict:
    from app.targetsystems import validate_many

    if not app_id or not user_login or not entitlement_values:
        raise ValueError("appId, userLogin, and entitlementValues are required")

    config = get_for_app(app_id)
    if not config:
        raise LookupError(f"No target system config for app {app_id}")

    result = await validate_many(config, user_login, entitlement_values, app_id=app_id, user_id=user_id)
    return {
        "appId": app_id,
        "checkedAt": datetime.now(timezone.utc).isoformat(),
        "hasAccess": result["hasAccess"],
        "results": result["results"],
    }
