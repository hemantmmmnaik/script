from io import BytesIO
from typing import Optional

from openpyxl import load_workbook

from app.services import connectors_service, entitlements_service, target_systems_service, users_service
from app.services.grant_logic import build_grant_body, grant_action_label, resolve_entitlement_value_codes

ADD_ACTIONS = {"add", "grant"}
REMOVE_ACTIONS = {"remove", "revoke"}


def user_display(user: dict) -> str:
    profile = user.get("profile", {})
    return profile.get("displayName") or profile.get("login") or profile.get("email") or user.get("id")


def _normalize_header(header) -> str:
    return str(header or "").strip().lower().replace("_", "").replace(" ", "")


def parse_rows(content: bytes) -> list:
    """Returns a list of {rowNum, appId, name, userEmail, action} dicts. Raises ValueError if
    required columns are missing; skips (with the row simply omitted) rows missing a
    required cell — callers should treat any row count mismatch as silently-dropped rows."""
    wb = load_workbook(BytesIO(content), read_only=True, data_only=True)
    ws = wb.active
    rows = ws.iter_rows(values_only=True)
    header = next(rows, None)
    if not header:
        return []

    col_index = {_normalize_header(h): i for i, h in enumerate(header)}
    app_col = col_index.get("appid")
    value_col = col_index.get("entitlementvaluename") or col_index.get("bundlename") or col_index.get("name")
    user_col = col_index.get("useremail")
    action_col = col_index.get("action")
    if app_col is None or value_col is None or user_col is None:
        raise ValueError('xlsx must have "appId", "entitlementValueName", and "userEmail" columns')

    def cell(row, idx):
        return row[idx] if idx is not None and idx < len(row) else None

    parsed = []
    for row_num, row in enumerate(rows, start=2):
        if not row:
            continue
        app_id, value_name, user_email = cell(row, app_col), cell(row, value_col), cell(row, user_col)
        if not app_id or not value_name or not user_email:
            continue
        action_raw = str(cell(row, action_col) or "add").strip().lower()
        parsed.append({
            "rowNum": row_num,
            "appId": str(app_id).strip(),
            "name": str(value_name).strip(),
            "userEmail": str(user_email).strip(),
            "action": action_raw,
        })
    return parsed


def find_bundle(connector: dict, target_name: str):
    target_name = target_name.strip().lower()
    return next(
        (b for b in connector.get("bundles", []) or [] if (b.get("name") or "").strip().lower() == target_name),
        None,
    )


def find_entitlement_value(connector: dict, target_name: str):
    target_name = target_name.strip().lower()
    return next(
        (
            (ent["id"], v)
            for ent in connector.get("entitlements", []) or []
            for v in ent.get("values", []) or []
            if (v.get("name") or "").strip().lower() == target_name
        ),
        None,
    )


def find_grant_for_bundle(grants: list, bundle_id: str):
    return next(
        (
            g for g in grants
            if g.get("grantType") == "ENTITLEMENT-BUNDLE"
            and (g.get("entitlementBundleId") == bundle_id or (g.get("entitlementBundle") or {}).get("id") == bundle_id)
        ),
        None,
    )


def find_grant_for_value(grants: list, value_id: str):
    return next(
        (
            g for g in grants
            if g.get("grantType") in ("ENTITLEMENT", "CUSTOM")
            and any(v.get("id") == value_id for ent in g.get("entitlements", []) or [] for v in ent.get("values", []) or [])
        ),
        None,
    )


def grant_target_name(grant: dict, connector: dict) -> str:
    if grant.get("grantType") == "ENTITLEMENT-BUNDLE":
        bundle_id = grant.get("entitlementBundleId") or (grant.get("entitlementBundle") or {}).get("id")
        bundle = next((b for b in connector.get("bundles", []) or [] if b.get("id") == bundle_id), None) or {}
        return bundle.get("name") or (grant.get("entitlementBundle") or {}).get("name") or bundle_id or grant["id"]
    names = [
        v.get("name") or v.get("id")
        for ent in grant.get("entitlements", []) or []
        for v in ent.get("values", []) or []
    ]
    return ", ".join(names) if names else grant["id"]


async def resolve_rows_to_actions(rows: list, connectors: dict) -> tuple:
    """Groups parsed xlsx rows by (app, user, add/remove) and resolves each group to queueable
    grant/revoke action dicts (same shape app.ui.state.add_to_queue expects, minus the "id").
    `connectors` must map appId -> {"status", "bundles", "entitlements", "app": {"label": ...}}.
    Returns (actions, errors)."""
    user_cache: dict = {}
    actions = []
    errors = []

    groups: dict = {}
    for row in rows:
        key = (row["appId"], row["userEmail"], "add" if row["action"] in ADD_ACTIONS else "remove")
        groups.setdefault(key, []).append(row["name"])

    for (app_id, user_email, action_kind), target_names in groups.items():
        connector = connectors.get(app_id)
        if not connector or connector.get("status") != "loaded":
            errors.append(f"{app_id}: app not added/loaded — skipped {len(target_names)} row(s)")
            continue

        if user_email not in user_cache:
            try:
                user_cache[user_email] = await users_service.get_user_by_email(user_email)
            except Exception as exc:
                user_cache[user_email] = None
                errors.append(f"userEmail {user_email}: lookup failed ({exc}) — skipped")
        user = user_cache[user_email]
        if not user:
            continue

        app_name = connector.get("app", {}).get("label")
        display = user_display(user)
        user_login = user.get("profile", {}).get("login")

        if action_kind == "add":
            by_entitlement: dict = {}
            names = []
            unresolved = []
            for target_name in target_names:
                bundle = find_bundle(connector, target_name)
                if bundle:
                    actions.append({
                        "appId": app_id, "appName": app_name, "userId": user["id"],
                        "userDisplay": display, "userLogin": user_login,
                        "grantType": "bundle", "targetId": bundle["id"],
                        "targetName": bundle.get("name") or target_name,
                        "entitlementId": None, "expiresAt": None,
                    })
                    continue

                match = find_entitlement_value(connector, target_name)
                if not match:
                    unresolved.append(target_name)
                    continue
                ent_id, v = match
                by_entitlement.setdefault(ent_id, []).append(v["id"])
                names.append(v.get("name") or target_name)

            if unresolved:
                errors.append(f"{app_id}: unresolved name(s) — not a bundle or entitlement value: {', '.join(unresolved)}")

            if by_entitlement:
                entitlements_body = [
                    {"id": eid, "values": [{"id": vid} for vid in vids]} for eid, vids in by_entitlement.items()
                ]
                actions.append({
                    "appId": app_id, "appName": app_name, "userId": user["id"],
                    "userDisplay": display, "userLogin": user_login,
                    "grantType": "additive-ent", "targetName": ", ".join(names),
                    "entitlements": entitlements_body, "expiresAt": None,
                })

        else:  # remove
            try:
                grants_result = await connectors_service.batch_grants([app_id], user["id"])
                grants = (grants_result[0] or {}).get("grants", []) if grants_result else []
            except Exception as exc:
                errors.append(f"{app_id} / {user_login or user_email}: failed to load existing grants ({exc})")
                continue

            matched_grants: dict = {}
            unresolved = []
            for target_name in target_names:
                bundle = find_bundle(connector, target_name)
                if bundle:
                    grant = find_grant_for_bundle(grants, bundle["id"])
                else:
                    match = find_entitlement_value(connector, target_name)
                    grant = find_grant_for_value(grants, match[1]["id"]) if match else None
                if not grant:
                    unresolved.append(target_name)
                    continue
                matched_grants[grant["id"]] = grant

            if unresolved:
                errors.append(
                    f"{app_id} / {user_login or user_email}: no existing grant found for name(s) {', '.join(unresolved)}"
                )

            for grant in matched_grants.values():
                bundle_id = grant.get("entitlementBundleId") or (grant.get("entitlementBundle") or {}).get("id")
                actions.append({
                    "actionType": "revoke-grant",
                    "appId": app_id, "appName": app_name, "userId": user["id"],
                    "userDisplay": display, "userLogin": user_login,
                    "grantId": grant["id"], "revokeGrantType": grant.get("grantType"),
                    "targetName": grant_target_name(grant, connector),
                    "entitlementBundleId": bundle_id if grant.get("grantType") == "ENTITLEMENT-BUNDLE" else None,
                })

    return actions, errors


async def execute_actions(queue_actions: list, connectors: Optional[dict] = None) -> list:
    """Executes queued grant/revoke actions directly against Okta — no UI/browser-storage
    dependency, unlike app.ui.actions.run_queue. Returns one result dict per action:
    {app, action, target, user, status, error, targetSystemCheck, targetSystemCheckError}."""
    connectors = dict(connectors or {})
    results = []

    for action in queue_actions:
        app_id = action["appId"]
        app_name = action.get("appName") or app_id
        user_id = action.get("userId")
        label = None
        status, error = "success", None
        tsc_status, tsc_error = None, None

        try:
            if action.get("actionType") == "revoke-grant":
                label = f"revoke-{action.get('revokeGrantType')}"
                await entitlements_service.delete_grant(
                    action["grantId"],
                    grant_type=action.get("revokeGrantType"),
                    app_id=app_id,
                    user_id=user_id,
                    entitlement_bundle_id=action.get("entitlementBundleId"),
                    hard_delete=True,
                )
            else:
                label = grant_action_label(action)
                await entitlements_service.create_grant(build_grant_body(action))

                if app_id not in connectors:
                    connectors[app_id] = (await connectors_service.batch_load([app_id]))[0]
                codes = resolve_entitlement_value_codes(connectors.get(app_id), action)
                config = target_systems_service.get_for_app(app_id)
                if codes and action.get("userLogin") and config:
                    try:
                        check = await target_systems_service.validate(
                            app_id, action["userLogin"], codes, user_id=user_id
                        )
                        tsc_status = "verified" if check.get("hasAccess") else "mismatch"
                    except Exception as exc:
                        tsc_status, tsc_error = "error", str(exc)
        except Exception as exc:
            status, error = "error", str(exc)

        results.append({
            "app": app_name,
            "action": label,
            "target": action.get("targetName"),
            "user": action.get("userDisplay") or action.get("userLogin"),
            "status": status,
            "error": error,
            "targetSystemCheck": tsc_status,
            "targetSystemCheckError": tsc_error,
        })

    return results
