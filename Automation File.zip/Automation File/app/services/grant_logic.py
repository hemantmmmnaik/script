from typing import Optional

GRANT_TYPE_MAP = {
    "bundle": "ENTITLEMENT-BUNDLE",
    "value": "ENTITLEMENT",
    "additive-ent": "ENTITLEMENT",
    "custom-ent": "CUSTOM",
    "revert-policy": "POLICY",
}

GRANT_ACTION_LABELS = {
    "bundle": "Grant Bundle",
    "value": "Grant Value",
    "custom-ent": "Grant Custom",
    "additive-ent": "Grant Entitlement",
    "revert-policy": "Revert to Policy",
}


def resolve_entitlement_value_codes(connector: Optional[dict], action: Optional[dict]) -> list:
    if not connector or not action:
        return []

    grant_type = action.get("grantType")

    if grant_type == "bundle":
        bundle = next((b for b in connector.get("bundles", []) if b.get("id") == action.get("targetId")), None)
        if not bundle:
            return []
        value_names = {
            v.get("id"): v.get("externalId")
            for ent in connector.get("entitlements", []) or []
            for v in ent.get("values", []) or []
            if v.get("id") and v.get("externalId")
        }
        codes = []
        for ent in bundle.get("entitlements", []) or []:
            for v in ent.get("values", []) or []:
                if isinstance(v, dict):
                    value = v.get("externalId") or value_names.get(v.get("id"))
                else:
                    value = value_names.get(v) or v
                if value:
                    codes.append(value)
        return codes

    if not grant_type or grant_type == "revert-policy":
        return []

    entries = action.get("entitlements") or [
        {"id": action.get("entitlementId"), "values": [{"id": action.get("targetId")}]}
    ]

    codes = []
    for entry in entries:
        schema = next((s for s in connector.get("entitlements", []) if s.get("id") == entry.get("id")), None)
        if not schema:
            continue
        for val in entry.get("values", []) or []:
            val_obj = next((v for v in schema.get("values", []) or [] if v.get("id") == val.get("id")), None)
            if val_obj and val_obj.get("name"):
                codes.append(val_obj["name"])
    return codes


def assigned_entitlement_ids(local_grants: list) -> tuple:
    """Returns (bundle_ids, value_ids) already granted to a user on an app, so pickers can
    exclude entitlements/bundles that would be redundant (or rejected as duplicates) to grant
    again."""
    bundle_ids = set()
    value_ids = set()
    for grant in local_grants or []:
        grant_type = grant.get("grantType")
        if grant_type == "ENTITLEMENT-BUNDLE":
            bundle_id = grant.get("entitlementBundleId") or (grant.get("entitlementBundle") or {}).get("id")
            if bundle_id:
                bundle_ids.add(bundle_id)
        elif grant_type in ("ENTITLEMENT", "CUSTOM"):
            for ent in grant.get("entitlements", []) or []:
                for value in ent.get("values", []) or []:
                    if value.get("id"):
                        value_ids.add(value["id"])
    return bundle_ids, value_ids


def grant_action_label(action: dict) -> str:
    grant_type = action.get("grantType")
    prefix = GRANT_ACTION_LABELS.get(grant_type, grant_type or "Grant")
    if grant_type == "revert-policy":
        return prefix
    target_name = action.get("targetName")
    return f"{prefix}: {target_name}" if target_name else prefix


def build_grant_body(action: dict) -> dict:
    okta_grant_type = GRANT_TYPE_MAP.get(action.get("grantType"), "ENTITLEMENT")
    body = {
        "grantType": okta_grant_type,
        "target": {"externalId": action["appId"], "type": "APPLICATION"},
        "targetPrincipal": {"externalId": action["userId"], "type": "OKTA_USER"},
    }
    if action.get("grantType") == "bundle":
        body["entitlementBundleId"] = action.get("targetId")
    elif action.get("entitlements"):
        body["entitlements"] = action["entitlements"]
    elif action.get("targetId"):
        body["entitlements"] = [{"id": action.get("entitlementId"), "values": [{"id": action.get("targetId")}]}]

    if action.get("expiresAt"):
        body["scheduleSettings"] = {"expirationDate": action["expiresAt"]}
    return body
