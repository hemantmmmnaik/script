"""Okta Workflows Access-Request invoke webhook -- the actual API-call logic for triggering the
assign/unassign flow."""

import httpx

from app import settings


def _invoke_url_and_token(action: str) -> tuple:
    if action == "assign":
        return settings.WORKFLOW_ASSIGN_INVOKE_URL, settings.WORKFLOW_ASSIGN_CLIENT_TOKEN
    if action == "termination":
        return settings.WORKFLOW_TERMINATION_INVOKE_URL, settings.WORKFLOW_TERMINATION_CLIENT_TOKEN
    return settings.WORKFLOW_UNASSIGN_INVOKE_URL, settings.WORKFLOW_UNASSIGN_CLIENT_TOKEN


async def invoke_access_request(action: str, payload: dict) -> tuple:
    """POSTs to the configured Workflows "assign"/"unassign" Access-Request invoke webhook. Does
    not raise on a non-2xx response -- the returned status code is the thing under test, not an
    error to be swallowed. Raises RuntimeError if the action's invoke URL isn't configured."""
    url, client_token = _invoke_url_and_token(action)
    if not url:
        raise RuntimeError(
            f"WORKFLOW_{action.upper()}_INVOKE_URL is not configured -- set it in .env before running."
        )
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(
            url,
            params={"clientToken": client_token},
            headers={"Accept": "application/json", "Content-Type": "application/json"},
            json=payload,
        )
    try:
        body = resp.json()
    except ValueError:
        body = resp.text
    return resp.status_code, body
