from app import dbautomation
from app.dbautomation import config as dbautomation_config


async def execute_action(app_id: str, action_name: str, params: dict) -> dict:
    """Thin service-layer wrapper around app.dbautomation.execute_action -- mirrors this app's
    existing services/*.py pattern of a pure async function with no UI knowledge (see
    app/services/target_systems_service.py::validate)."""
    return await dbautomation.execute_action(app_id, action_name, params)


def get_entitlement_column(app_id: str) -> str:
    return dbautomation_config.get_entitlement_column(app_id)
