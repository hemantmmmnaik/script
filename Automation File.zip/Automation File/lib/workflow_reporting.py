"""Summary + CSV report generation for scripts/run_workflow_tests.py, same
summary/detail/csv report-file convention as lib/reporting.py."""

import csv
import textwrap
from pathlib import Path
from typing import Optional

from app.services import target_systems_service
from lib import test_case_registry
from lib.test_catalog import app_connector_type, apps_in_scope

SUMMARY_WIDTH = 70
APP_SUMMARY_WIDTH = 70
DETAIL_WIDTH = 70
DETAIL_COL_WIDTHS = {
    "tc": 7,
    "app_name": 18,
    "description": 26,
    "test_data": 26,
    "expected_result": 26,
    "actual_result": 26,
    "status": 8,
    "tested_date": 12,
}
_DETAIL_HEADERS = ["tc", "app_name", "description", "test_data", "expected_result", "actual_result", "status", "tested_date"]
_DETAIL_TITLES = {
    "app_name": "App Name",
    "tc": "TC#",
    "description": "Test Case Description",
    "test_data": "Test Data",
    "expected_result": "Expected Result",
    "actual_result": "Actual Result",
    "status": "Status",
    "tested_date": "Tested Date",
}


def _connector_label(app_id: str) -> str:
    """Second header line of a detail-report app section: 'WEBSERVICE' for webservice-configured
    apps, 'JDBC CONNECTOR - ORACLE' / 'JDBC CONNECTOR - MSSQL' for db-target-system.json apps."""
    db_type = app_connector_type(app_id)
    if db_type != "UNKNOWN":
        return f"JDBC CONNECTOR - {db_type}"
    ts_config = target_systems_service.get_for_app(app_id) or {}
    ts_type = (ts_config.get("type") or "").upper()
    return ts_type or "UNKNOWN"


def _checks_for(test_case_id: Optional[str]) -> list:
    if not test_case_id:
        return []
    try:
        return test_case_registry.get(test_case_id)["checks"]
    except LookupError:
        return []


def _test_case_description(test_case_id: Optional[str]) -> str:
    if not test_case_id:
        return ""
    try:
        return test_case_registry.get(test_case_id)["description"]
    except LookupError:
        return ""


def _expected_result(test_case_id: Optional[str]) -> str:
    if not test_case_id:
        return ""
    try:
        return test_case_registry.get(test_case_id)["expected_result"]
    except LookupError:
        return ""


def _workflow_api_result(r) -> str:
    """Workflow invoke half of the Actual Result column: 'Workflow API passed with 200 status' on
    HTTP 200, else the actual HTTP status returned by the invoke webhook."""
    if r.http_status == 200:
        return "Workflow API passed with 200 status"
    return f"Workflow API returned HTTP {r.http_status}"


def _target_system_result(r) -> str:
    """Target-system half of the Actual Result column, using the same SUCCESS/SKIPPED/FAILED
    vocabulary as WorkflowResult.target_system_status (see lib/workflow_runner.py)."""
    if r.target_system_status == "SUCCESS":
        return "Access confirmed in target system"
    if r.target_system_status == "SKIPPED":
        return "target system not verified (no config)"
    return "Access not confirmed in target system"


def _actual_result(r) -> str:
    """Human-readable outcome for the Actual Result column -- failure_reason verbatim on
    failure/skip-with-reason, else the workflow-invoke status combined with the target-system
    verification status (e.g. 'Workflow API passed with 200 status/Access confirmed in target
    system'), since both halves independently matter to the reader."""
    if r.failure_reason:
        return r.failure_reason
    checks = _checks_for(r.test_case_id)
    if "sunset_present" in checks:
        return "expirationTime present in payload"
    if "sunset_absent" in checks:
        return "expirationTime absent from payload"
    return f"{_workflow_api_result(r)}/{_target_system_result(r)}"


def _test_data(r) -> str:
    """Human-entered inputs the row was run with -- the user, followed by the bundle/entitlement
    value (if any) right after the email (see WorkflowRow.user_email/requestable_item/item_type
    in lib/workflow_runner.py)."""
    if r.item_type in ("bundle", "entitlement") and r.requestable_item:
        return f"{r.user_email} / {r.item_type}: {r.requestable_item}"
    return r.user_email


def _sort_by_test_case(results: list) -> list:
    """Orders report rows by the approved spec's original row order (config/test_case_registry.json),
    regardless of the concurrent completion order run_limited() produces them in (see
    scripts/run_workflow_tests.py::run_all). Untagged/unrecognized-id rows sort after every tagged
    one. Stable sort -- rows sharing a test_case_id keep their original relative (completion) order."""
    return sorted(results, key=lambda r: test_case_registry.order_key(r.test_case_id))


def _counts(results: list) -> tuple:
    total = len(results)
    passed = sum(1 for r in results if r.overall_status == "SUCCESS")
    return total, passed, total - passed


def _status_counts(results: list, field: str, status) -> int:
    return sum(1 for r in results if getattr(r, field) == status)


def build_summary_lines(results: list, generated_at: Optional[str] = None) -> list:
    total, passed, failed = _counts(results)
    action = results[0].action if results else ""

    target_ok = _status_counts(results, "target_system_status", "SUCCESS")
    target_failed = _status_counts(results, "target_system_status", "FAILED")
    target_skipped = _status_counts(results, "target_system_status", "SKIPPED")
    http_ok = _status_counts(results, "http_status", 200)

    lines = []
    lines.append("=" * SUMMARY_WIDTH)
    lines.append(f"WORKFLOW ACCESS-REQUEST TEST RUN SUMMARY ({action})".center(SUMMARY_WIDTH))
    if generated_at:
        lines.append(f"Generated: {generated_at}".center(SUMMARY_WIDTH))
    lines.append("=" * SUMMARY_WIDTH)
    lines.append(f"{'Total Test Cases Run':<28}: {total}")
    lines.append(f"{'Total Passed':<28}: {passed}")
    lines.append(f"{'Total Failed':<28}: {failed}")
    lines.append("-" * SUMMARY_WIDTH)
    lines.append("Workflow Invoke Status".center(SUMMARY_WIDTH))
    lines.append(f"{'  HTTP 200':<28}: {http_ok}/{total}")
    lines.append("-" * SUMMARY_WIDTH)
    lines.append("Target System Status".center(SUMMARY_WIDTH))
    lines.append(f"{'  SUCCESS':<28}: {target_ok}/{total}")
    lines.append(f"{'  FAILED':<28}: {target_failed}/{total}")
    lines.append(f"{'  SKIPPED (no config)':<28}: {target_skipped}/{total}")
    lines.append("=" * SUMMARY_WIDTH)
    return lines


def _detail_table(results: list, app_name: str) -> list:
    lines = []
    header_row = "  ".join(f"{_DETAIL_TITLES[h].upper():<{DETAIL_COL_WIDTHS[h]}}" for h in _DETAIL_HEADERS)
    lines.append(header_row)
    lines.append("-" * len(header_row))
    for r in results:
        wrapped = {
            "tc": [r.test_case_id or ""],
            "app_name": textwrap.wrap(app_name, DETAIL_COL_WIDTHS["app_name"]) or [""],
            "description": textwrap.wrap(_test_case_description(r.test_case_id), DETAIL_COL_WIDTHS["description"]) or [""],
            "test_data": textwrap.wrap(_test_data(r), DETAIL_COL_WIDTHS["test_data"]) or [""],
            "expected_result": textwrap.wrap(_expected_result(r.test_case_id), DETAIL_COL_WIDTHS["expected_result"]) or [""],
            "actual_result": textwrap.wrap(_actual_result(r), DETAIL_COL_WIDTHS["actual_result"]) or [""],
            "status": [r.overall_status],
            "tested_date": [r.tested_at],
        }
        row_height = max(len(v) for v in wrapped.values())
        for i in range(row_height):
            cells = [f"{(wrapped[h][i] if i < len(wrapped[h]) else ''):<{DETAIL_COL_WIDTHS[h]}}" for h in _DETAIL_HEADERS]
            lines.append("  ".join(cells))
        lines.append("")
    return lines


def build_detail_lines(results: list) -> list:
    """Low-level detail report, grouped by app: APP name, connector type, and Pass/Fail count as
    the centered section header (mirroring lib/reporting.py::build_app_detail_lines), followed by
    the per-test-case table (see _DETAIL_HEADERS/_DETAIL_TITLES) -- each row repeats the app name
    right after TC# so a row is self-describing outside of its section too."""
    lines = []
    apps = sorted({(r.application_id, r.app_name) for r in results if r.application_id})
    for app_id, app_name in apps:
        app_results = _sort_by_test_case([r for r in results if r.application_id == app_id])
        total, passed, failed = _counts(app_results)
        display_name = app_name or app_id
        lines.append("=" * DETAIL_WIDTH)
        lines.append(display_name.center(DETAIL_WIDTH))
        lines.append(_connector_label(app_id).center(DETAIL_WIDTH))
        lines.append(f"{passed} Pass / {failed} Fail (of {total})".center(DETAIL_WIDTH))
        lines.append("=" * DETAIL_WIDTH)
        lines.extend(_detail_table(app_results, display_name))

    # Rows with no resolvable application_id (e.g. a resolution error before the app lookup) --
    # still reported, just outside any app section.
    unassigned = _sort_by_test_case([r for r in results if not r.application_id])
    if unassigned:
        lines.append("=" * DETAIL_WIDTH)
        lines.append("UNASSIGNED (no application_id)".center(DETAIL_WIDTH))
        lines.append("=" * DETAIL_WIDTH)
        lines.extend(_detail_table(unassigned, "UNASSIGNED"))

    return lines


# --------------------------------------------------------------------------------------
# App-Differentiated High-Level Summary Report (demo-facing) -- one row per test case per app,
# status is PASSED/FAILED/BLOCKED/SKIPPED. Low-level failure_reason detail stays in
# build_detail_lines(); this section never prints it, to keep the demo view uncluttered.
# --------------------------------------------------------------------------------------

def _test_case_status(results: list, app_id: str, test_case_id: str) -> tuple:
    """Returns (status, reason) for one (app, test_case) cell. BLOCKED wins even if a row happens
    to be tagged with that test_case_id, since a blocked test case has no real coverage behind it
    yet -- see lib/test_case_registry.py."""
    entry = test_case_registry.get(test_case_id)
    if entry["execution"] == "blocked":
        return "BLOCKED", entry["blocked_reason"] or ""

    rows = [r for r in results if r.application_id == app_id and r.test_case_id == test_case_id]
    if not rows:
        return "SKIPPED", "Not run in this pass"
    if any(r.overall_status == "SUCCESS" for r in rows) and all(r.overall_status == "SUCCESS" for r in rows):
        return "PASSED", ""
    return "FAILED", "; ".join(sorted({r.failure_reason for r in rows if r.failure_reason})) or "See detail report"


def build_app_summary(results: list) -> list:
    """Returns [{"app_id", "app_name", "connector_type", "total", "passed", "failed", "blocked",
    "skipped", "summary_line"}], one entry per app in config/test_mapping.py (via
    lib/test_catalog.apps_in_scope), independent of whether any results were recorded for that
    app in this particular run. Each app's test-case set comes from
    lib/test_case_registry.ids_for_app -- an app with 13 approved ids shows 13 rows, one with 15
    shows 15, no fixed per-app template size."""
    app_names = {r.application_id: r.app_name for r in results if r.application_id and r.app_name}
    app_ids = list(dict.fromkeys(apps_in_scope() + [r.application_id for r in results if r.application_id]))

    per_app = []
    for app_id in app_ids:
        ids = test_case_registry.ids_for_app(app_id)
        passed = failed = blocked = skipped = 0
        for tc_id in ids:
            status, _ = _test_case_status(results, app_id, tc_id)
            if status == "PASSED":
                passed += 1
            elif status == "FAILED":
                failed += 1
            elif status == "BLOCKED":
                blocked += 1
            else:
                skipped += 1
        total = len(ids)
        per_app.append({
            "app_id": app_id,
            "app_name": app_names.get(app_id, app_id),
            "connector_type": app_connector_type(app_id),
            "total": total, "passed": passed, "failed": failed, "blocked": blocked, "skipped": skipped,
            "summary_line": f"{total} test cases, {passed} out of {total} passed, "
                            f"{failed} failed, {blocked} blocked, {skipped} skipped",
        })
    return per_app


def build_app_summary_lines(results: list, generated_at: Optional[str] = None) -> list:
    per_app = build_app_summary(results)
    lines = []
    lines.append("=" * APP_SUMMARY_WIDTH)
    lines.append("APP-DIFFERENTIATED HIGH-LEVEL SUMMARY".center(APP_SUMMARY_WIDTH))
    if generated_at:
        lines.append(f"Generated: {generated_at}".center(APP_SUMMARY_WIDTH))
    lines.append("=" * APP_SUMMARY_WIDTH)

    for app in per_app:
        lines.append(f"{app['app_name']} [{app['connector_type']}]")
        lines.append(f"  {app['summary_line']}")
        lines.append("")

    total_cases = sum(a["total"] for a in per_app)
    total_passed = sum(a["passed"] for a in per_app)
    total_failed = sum(a["failed"] for a in per_app)
    total_blocked = sum(a["blocked"] for a in per_app)
    total_skipped = sum(a["skipped"] for a in per_app)
    lines.append("-" * APP_SUMMARY_WIDTH)
    lines.append("AGGREGATE TOTAL".center(APP_SUMMARY_WIDTH))
    lines.append(f"  {len(per_app)} apps, {total_cases} total eligible test cases")
    lines.append(f"  {total_cases} test cases, {total_passed} out of {total_cases} passed, "
                 f"{total_failed} failed, {total_blocked} blocked, {total_skipped} skipped")
    lines.append("=" * APP_SUMMARY_WIDTH)
    return lines


def print_app_summary(results: list) -> None:
    print("\n" + "\n".join(build_app_summary_lines(results)) + "\n")


def print_summary(results: list) -> None:
    print("\n" + "\n".join(build_summary_lines(results)) + "\n")


def write_reports(results: list, reports_dir: Path, generated_at: str, timestamp: str) -> tuple:
    reports_dir.mkdir(parents=True, exist_ok=True)

    app_summary_path = reports_dir / f"workflow_app_summary_{timestamp}.txt"
    app_summary_path.write_text("\n".join(build_app_summary_lines(results, generated_at=generated_at)) + "\n", encoding="utf-8")

    summary_path = reports_dir / f"workflow_summary_{timestamp}.txt"
    summary_path.write_text("\n".join(build_summary_lines(results, generated_at=generated_at)) + "\n", encoding="utf-8")

    detail_path = reports_dir / f"workflow_detail_{timestamp}.txt"
    detail_path.write_text("\n".join(build_detail_lines(results)) + "\n", encoding="utf-8")

    csv_path = reports_dir / f"workflow_results_{timestamp}.csv"
    # Same granular columns/row structure as the detail report (_DETAIL_HEADERS/_DETAIL_TITLES),
    # minus App Name (already implied by the grouping order below), item_type/"Type" (Bundle vs
    # Entitlement -- that's embedded in the Test Data column already), and the top-level Pass/Fail
    # count that only makes sense as a per-app section header in detail.txt, not a per-row value.
    csv_headers = [h for h in _DETAIL_HEADERS if h != "app_name"]
    fieldnames = [_DETAIL_TITLES[h] for h in csv_headers]
    # Grouped by app (application_id, then unassigned rows last), test-case-ordered within each
    # group -- same row order as the detail report, regardless of concurrent completion order.
    apps_order = sorted({r.application_id for r in results if r.application_id})
    ordered_results = []
    for app_id in apps_order:
        ordered_results.extend(_sort_by_test_case([r for r in results if r.application_id == app_id]))
    ordered_results.extend(_sort_by_test_case([r for r in results if not r.application_id]))

    row_values = {
        "tc": lambda r: r.test_case_id or "",
        "description": lambda r: _test_case_description(r.test_case_id),
        "test_data": _test_data,
        "expected_result": lambda r: _expected_result(r.test_case_id),
        "actual_result": _actual_result,
        "status": lambda r: r.overall_status,
        "tested_date": lambda r: r.tested_at,
    }
    with csv_path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()
        for r in ordered_results:
            writer.writerow({_DETAIL_TITLES[h]: row_values[h](r) for h in csv_headers})

    return app_summary_path, summary_path, detail_path, csv_path
