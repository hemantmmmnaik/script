"""Shared execution logic for the Okta Workflows Access-Request test runner
(scripts/run_workflow_tests.py). Unlike lib/grant_runner.py (which calls the Governance grants
API directly), this drives the Workflows "assign"/"unassign" invoke webhook for a
collection/bundle/entitlement requestable item, waits for the change to propagate, then reuses
the existing target_systems_service.validate() to confirm it landed downstream.

The xlsx test files carry human-entered user_email and requestableItem (a bundle/entitlement
name) rather than raw Okta ids -- resolve_rows() turns those into real ids by reusing the same
lookup helpers scripts/run_api_tests.py uses (fetch_users_by_email, fetch_bundles_by_name,
fetch_entitlement_value_index, fetch_app_name), imported straight from lib/grant_runner.py rather
than duplicated here.

Depends only on app.services.* / app.okta_client / app.settings, same as grant_runner.py --
safe to run standalone, no NiceGUI dependency.
"""

import asyncio
import random
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from openpyxl import load_workbook

from app.services import target_systems_service, workflow_service
from lib.grant_runner import (
    extract_entitlement_codes,
    fetch_bundles_by_name,
    fetch_entitlement_value_index,
    fetch_users_by_email,
)
from lib import test_case_registry

TARGET_VERIFY_DELAY_RANGE = (60.0, 80.0)  # seconds -- avg propagation time for the downstream write

ASSIGN_COLUMNS = [
    "user_email", "applicationId", "item_type", "requestableItem",
    "expirationTime", "timeZone", "referenceId", "comment",
]
UNASSIGN_COLUMNS = [
    "user_email", "applicationId", "item_type", "requestableItem",
    "referenceId", "comment",
]
# Optional -- not required in expected_columns/missing-column validation. Ties a row back to one
# or more of the approved ATC_NN ids in config/test_case_registry.json (';'/','-separated, e.g.
# 'ATC_09;ATC_32') for the App-Differentiated High-Level Summary Report -- process_row_group runs
# the row's workflow invoke + target-system verification once and reports the outcome once per
# tagged id, so the report breaks results down per test case. Rows without it are left untagged
# and show up as SKIPPED for that test case in the report, not silently dropped.
TEST_CASE_COLUMN = "test_case"

# --------------------------------------------------------------------------------------
# Data model
# --------------------------------------------------------------------------------------

@dataclass
class WorkflowRow:
    line_no: int
    action: str  # "assign" | "unassign"
    user_email: str
    application_id: str
    item_type: str
    requestable_item: str  # human input: bundle/entitlement name(s) (';'-separated), or a raw id for "collection"
    reference_id: str
    comment: str = ""
    expiration_time: str = ""
    time_zone: str = ""
    test_case_ids: list = field(default_factory=list)  # a row may satisfy more than one TC_NN at once


@dataclass
class ResolvedRequest:
    row: WorkflowRow
    item_label: str = ""  # the single bundle/entitlement name this ResolvedRequest is for
    user_id: str = ""
    user_login: str = ""
    requestable_item_id: str = ""
    entitlement_id: str = ""
    entitlement_codes: list = field(default_factory=list)
    error: str = ""


@dataclass
class WorkflowResult:
    action: str
    user_email: str
    application_id: str
    item_type: str
    requestable_item: str
    requestable_item_id: str
    entitlement_id: str
    reference_id: str
    app_name: str = ""
    test_case_id: Optional[str] = None
    http_status: Optional[int] = None
    response_body: str = ""
    target_system_status: str = "SKIPPED"
    overall_status: str = "FAILED"
    failure_reason: str = ""
    tested_at: str = ""


# --------------------------------------------------------------------------------------
# xlsx parsing
# --------------------------------------------------------------------------------------

def read_xlsx_rows(file_path: str, action: str) -> list:
    path = Path(file_path)
    if not path.exists():
        raise SystemExit(f"Test file not found: {file_path}")

    expected_columns = ASSIGN_COLUMNS if action == "assign" else UNASSIGN_COLUMNS

    wb = load_workbook(path, read_only=True, data_only=True)
    ws = wb.active
    rows_iter = ws.iter_rows(values_only=True)

    try:
        header = next(rows_iter)
    except StopIteration:
        raise SystemExit(f"Test file is empty (no header row): {file_path}")

    header = [str(h).strip() if h is not None else "" for h in header]
    missing = set(expected_columns) - set(header)
    if missing:
        raise SystemExit(
            f"{file_path} is missing required column(s): {', '.join(sorted(missing))}. "
            f"Found columns: {', '.join(header)}"
        )
    col_index = {name: header.index(name) for name in expected_columns}
    test_case_col_index = header.index(TEST_CASE_COLUMN) if TEST_CASE_COLUMN in header else None

    def cell(raw_row, name: str) -> str:
        idx = col_index[name]
        value = raw_row[idx] if idx < len(raw_row) else None
        return str(value).strip() if value is not None else ""

    def parse_test_case_ids(raw_row) -> list:
        if test_case_col_index is None or test_case_col_index >= len(raw_row):
            return []
        return test_case_registry.normalize_test_case_ids(raw_row[test_case_col_index])

    rows = []
    for line_no, raw_row in enumerate(rows_iter, start=2):
        if raw_row is None or all(v is None for v in raw_row):
            continue
        user_email = cell(raw_row, "user_email")
        requestable_item = cell(raw_row, "requestableItem")
        reference_id = cell(raw_row, "referenceId")
        if not user_email or not requestable_item or not reference_id:
            print(f"[WARN] {file_path}:{line_no}: skipping row with missing user_email/requestableItem/referenceId")
            continue
        test_case_ids = parse_test_case_ids(raw_row)
        application_id = cell(raw_row, "applicationId")
        if len(test_case_ids) == 1:
            derived_app_id = test_case_registry.application_id_for(test_case_ids[0])
            if derived_app_id:
                if application_id and application_id != derived_app_id:
                    print(
                        f"[WARN] {file_path}:{line_no}: applicationId '{application_id}' does not match "
                        f"the app registered for {test_case_ids[0]} ('{derived_app_id}') -- using the "
                        f"registry's value"
                    )
                application_id = derived_app_id

        rows.append(WorkflowRow(
            line_no=line_no,
            action=action,
            user_email=user_email,
            application_id=application_id,
            item_type=cell(raw_row, "item_type"),
            requestable_item=requestable_item,
            reference_id=reference_id,
            comment=cell(raw_row, "comment"),
            expiration_time=cell(raw_row, "expirationTime") if action == "assign" else "",
            time_zone=cell(raw_row, "timeZone") if action == "assign" else "",
            test_case_ids=test_case_ids,
        ))
    wb.close()

    if not rows:
        raise SystemExit(f"No valid rows found in {file_path} -- nothing to process.")
    return rows


# --------------------------------------------------------------------------------------
# Resolution -- turns user_email/requestableItem (names) into real Okta ids, mirroring
# scripts/run_api_tests.py::run_all's pre-resolution pattern (batch email lookup, per-app
# bundle/entitlement-index caching) but for the workflow invoke flow instead of grants.
# --------------------------------------------------------------------------------------

def _split_requestable_items(raw: str) -> list:
    """requestableItem cells may list more than one bundle/entitlement name, ';'-separated --
    same convention lib/grant_runner.py's CSV 'bundles'/'entitlements' columns already use. A
    "collection" row's raw id, or a negative-test row with an unknown item_type, is never split
    (it's a single opaque value, not a name list)."""
    items = [v.strip() for v in raw.split(";") if v.strip()]
    return items or [raw]


def group_resolved_by_row(resolved_rows: list) -> list:
    """Regroups resolve_rows()'s flat list back into one group per underlying WorkflowRow (a
    multi-item 'BundleA;BundleB' row expands into several ResolvedRequests that must be recombined
    before process_row_group treats them as a single test scenario). Groups by row identity
    (id()), not equality, since WorkflowRow isn't hashable and two textually-identical rows in the
    file are still distinct scenarios. Order-preserving."""
    groups: dict = {}
    order = []
    for resolved in resolved_rows:
        key = id(resolved.row)
        if key not in groups:
            groups[key] = []
            order.append(key)
        groups[key].append(resolved)
    return [groups[key] for key in order]


async def resolve_rows(rows: list) -> list:
    """Returns a list[ResolvedRequest]. A "bundle"/"entitlement" row whose requestableItem cell
    lists N ';'-separated names expands into N ResolvedRequest entries (one per name, each with
    its own item_label/requestable_item_id/entitlement_id) sharing the same underlying WorkflowRow
    -- each becomes its own workflow invoke call in process_row_group, since the Workflows webhook
    payload only carries one requestableItemId/entitlementId per call (see build_payload), but
    group_resolved_by_row() recombines them into a single test scenario before that. Rows that
    fail to resolve (unknown email, bundle/entitlement name not found) carry a non-empty `.error`
    and should be reported as FAILED without ever reaching the workflow invoke call. "collection"
    rows and unrecognized item_types are passed through as a single unresolved ResolvedRequest --
    requestable_item_id falls back to the raw input so they still reach the real API and exercise
    its validation."""
    print(f"[INFO] Resolving {len({r.user_email.strip().lower() for r in rows})} unique user(s) via Okta search...")
    users_by_email = await fetch_users_by_email([r.user_email for r in rows])
    print(f"[INFO] Resolved {len(users_by_email)} user(s).")

    bundles_cache, value_index_cache = {}, {}
    for row in rows:
        if not row.application_id or row.item_type not in ("bundle", "entitlement"):
            continue
        if row.item_type == "bundle" and row.application_id not in bundles_cache:
            print(f"[INFO] Fetching bundles for app {row.application_id}...")
            bundles_cache[row.application_id] = await fetch_bundles_by_name(row.application_id)
        if row.item_type == "entitlement" and row.application_id not in value_index_cache:
            print(f"[INFO] Fetching entitlement schemas for app {row.application_id}...")
            value_index_cache[row.application_id] = await fetch_entitlement_value_index(row.application_id)

    resolved = []
    for row in rows:
        user = users_by_email.get(row.user_email.strip().lower())
        if not user:
            resolved.append(ResolvedRequest(row=row, item_label=row.requestable_item, error="User not found in Okta for this email"))
            continue
        user_id = user["id"]
        user_login = (user.get("profile", {}) or {}).get("login") or row.user_email

        if row.item_type not in ("bundle", "entitlement"):
            # "collection" rows and unknown/negative-test item_types: single unresolved request,
            # never split -- requestable_item is a raw id/opaque value, not a name list.
            result = ResolvedRequest(row=row, item_label=row.requestable_item, user_id=user_id, user_login=user_login)
            result.requestable_item_id = row.requestable_item
            resolved.append(result)
            continue

        for item_label in _split_requestable_items(row.requestable_item):
            result = ResolvedRequest(row=row, item_label=item_label, user_id=user_id, user_login=user_login)
            if row.item_type == "bundle":
                bundle = bundles_cache.get(row.application_id, {}).get(item_label)
                if not bundle:
                    result.error = f"Bundle '{item_label}' not found for app {row.application_id}"
                    resolved.append(result)
                    continue
                result.requestable_item_id = bundle["id"]
                result.entitlement_codes = extract_entitlement_codes(bundle)
            else:  # entitlement
                entry = value_index_cache.get(row.application_id, {}).get(item_label)
                if not entry:
                    result.error = f"Entitlement value '{item_label}' not found for app {row.application_id}"
                    resolved.append(result)
                    continue
                result.requestable_item_id = entry["value_id"]
                result.entitlement_id = entry["schema_id"]
                if entry["code"]:
                    result.entitlement_codes = [entry["code"]]
            resolved.append(result)
    return resolved


# --------------------------------------------------------------------------------------
# Workflow invoke payload + HTTP call
# --------------------------------------------------------------------------------------

def build_payload(resolved: ResolvedRequest) -> dict:
    """Mirrors the doc's per-field rules exactly: applicationId/entitlementId are always sent
    (empty string when not applicable, matching the doc's bundle/collection examples).
    expirationTime/timeZone are each included only if that specific cell is non-empty --
    deliberately not enforced as a pair here, so a row that intentionally sets only one of the
    two (a negative test case) actually reaches the API and exercises its real 400 validation."""
    row = resolved.row
    payload = {
        "userId": resolved.user_id,
        "requestableItemId": resolved.requestable_item_id,
        "referenceId": row.reference_id,
        "comment": row.comment,
        "applicationId": row.application_id,
        "entitlementId": resolved.entitlement_id,
    }
    if row.expiration_time:
        payload["expirationTime"] = row.expiration_time
    if row.time_zone:
        payload["timeZone"] = row.time_zone
    return payload


async def invoke_workflow(resolved: ResolvedRequest) -> tuple:
    """Builds the row's Access-Request payload and delegates the actual API call to
    app.services.workflow_service -- this module owns test-data shaping only. Returns
    (status_code, body, payload) -- the payload is returned too since callers (Test 6/7's
    verify_expiration_in_payload) need to inspect exactly what was sent, not just the response."""
    payload = build_payload(resolved)
    try:
        status_code, body = await workflow_service.invoke_access_request(resolved.row.action, payload)
        return status_code, body, payload
    except RuntimeError as exc:
        raise SystemExit(str(exc))


# --------------------------------------------------------------------------------------
# Test 6 / Test 7 -- sunset-date (expirationTime) payload inclusion check
# --------------------------------------------------------------------------------------

def verify_expiration_in_payload(checks: list, payload: dict) -> tuple:
    """'sunset_present': passes iff the actual outgoing payload includes a non-empty
    `expirationTime` -- i.e. the sunset date was selected on the row (row.expiration_time truthy
    -> build_payload includes it) AND it actually made it into the payload sent to the workflow.
    'sunset_absent': passes iff `expirationTime` is absent from the payload (sunset date not
    selected). This is a payload-content check only -- independent of whether the target-system/
    HTTP checks below it in process_row_group pass or fail."""
    has_expiration = bool(payload.get("expirationTime"))
    if "sunset_present" in checks:
        if has_expiration:
            return "SUCCESS", ""
        return "FAILED", "expirationTime was not present in the payload sent to the workflow"
    if "sunset_absent" in checks:
        if not has_expiration:
            return "SUCCESS", ""
        return "FAILED", f"expirationTime={payload.get('expirationTime')!r} was present in the payload sent to the workflow"
    return "SUCCESS", ""


# --------------------------------------------------------------------------------------
# Target-system verification (shared tail of process_row)
# --------------------------------------------------------------------------------------

async def verify_target_system(resolved: ResolvedRequest, user_login: str) -> tuple:
    """Returns (target_system_status, failure_reason). SKIPPED when there's no applicationId to
    look up a target-system config for (common for collection rows, or bundle/entitlement rows
    with no resolvable entitlement code) or when none is configured for that app. Passes the
    resolved entitlement value CODE(s) (externalId/name -- see lib.grant_runner.extract_entitlement_codes
    / resolve_entitlement_values), not the Okta entitlementId/requestableItemId, since that's what
    target-system check_access queries actually match against.

    Pass/fail polarity depends on resolved.row.action: an "assign" row passes when the target
    system reports access (hasAccess=True); an "unassign" row is verifying access was *revoked*, so
    it passes when the target system reports no access (hasAccess=False) and fails if access is
    still present downstream."""
    row = resolved.row
    if not row.application_id:
        return "SKIPPED", ""
    if not resolved.entitlement_codes:
        return "SKIPPED", ""

    try:
        verification = await target_systems_service.validate(
            app_id=row.application_id, user_login=user_login, entitlement_values=resolved.entitlement_codes, user_id=resolved.user_id,
        )
        has_access = verification.get("hasAccess")

        if row.action == "unassign":
            if not has_access:
                return "SUCCESS", ""
            lingering = [r for r in verification.get("results", []) if r.get("hasAccess")]
            reason = f"Target system still shows access after unassign: {lingering}" if lingering else "Target system verification returned hasAccess=True after unassign"
            return "FAILED", reason

        if has_access:
            return "SUCCESS", ""
        failed_checks = [r for r in verification.get("results", []) if not r.get("hasAccess")]
        reason = f"Target system verification failed for: {failed_checks}" if failed_checks else "Target system verification returned hasAccess=False"
        return "FAILED", reason
    except LookupError:
        return "SKIPPED", ""
    except Exception as exc:  # noqa: BLE001 - a single row's failure must not abort the batch
        return "FAILED", f"Target system check errored: {exc}"


# --------------------------------------------------------------------------------------
# Per-row processing
# --------------------------------------------------------------------------------------

def _checks_for(test_case_id: Optional[str]) -> list:
    if not test_case_id:
        return ["target_system"]
    try:
        return test_case_registry.get(test_case_id)["checks"]
    except LookupError:
        return ["target_system"]


async def process_row_group(group: list, app_names: dict) -> list:
    """A "row group" is every ResolvedRequest resolve_rows() expanded from the same underlying
    WorkflowRow (e.g. a requestableItem cell listing 'BundleA;BundleB' becomes two
    ResolvedRequests sharing one row). Each item in the group still gets its own workflow invoke
    call -- the webhook payload only carries one requestableItemId per call -- but the group is
    treated as ONE test scenario: target-system verification runs ONCE against the union of every
    item's resolved entitlement codes, and exactly one WorkflowResult per test_case_id tagged on
    the row is returned, not one per item. This keeps detail.txt/the CSV report at one row per
    scenario instead of duplicating a row per bundle/entitlement in a multi-item request. A row
    with no test_case tag still returns a single untagged result. The audit-log check runs at most
    once total (shared) even if more than one tagged id needs it, since it asserts the same System
    Log event regardless of which id triggered it. A tagged id whose registry entry is
    execution == "blocked" short-circuits to BLOCKED without ever invoking the workflow."""
    row = group[0].row
    test_case_ids = row.test_case_ids or [None]

    blocked_ids = [tc_id for tc_id in test_case_ids if tc_id and test_case_registry.is_blocked(tc_id)]
    runnable_ids = [tc_id for tc_id in test_case_ids if tc_id not in blocked_ids]

    def base_result(test_case_id: Optional[str]) -> WorkflowResult:
        item_ids = ";".join(dict.fromkeys(r.requestable_item_id for r in group if r.requestable_item_id))
        ent_ids = ";".join(dict.fromkeys(r.entitlement_id for r in group if r.entitlement_id))
        return WorkflowResult(
            action=row.action, user_email=row.user_email, application_id=row.application_id, item_type=row.item_type,
            requestable_item=row.requestable_item, requestable_item_id=item_ids,
            entitlement_id=ent_ids, reference_id=row.reference_id,
            app_name=app_names.get(row.application_id, "") if row.application_id else "",
            test_case_id=test_case_id,
            tested_at=datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
        )

    blocked_results = []
    for test_case_id in blocked_ids:
        result = base_result(test_case_id)
        result.target_system_status = "SKIPPED"
        result.overall_status = "BLOCKED"
        result.failure_reason = test_case_registry.get(test_case_id)["blocked_reason"] or ""
        blocked_results.append(result)

    if not runnable_ids:
        return blocked_results

    errored = [r for r in group if r.error]
    resolvable = [r for r in group if not r.error]

    if not resolvable:
        reason = "; ".join(dict.fromkeys(r.error for r in errored))
        results = []
        for test_case_id in runnable_ids:
            result = base_result(test_case_id)
            result.failure_reason = reason
            results.append(result)
        return blocked_results + results

    invoke_started_at = datetime.now(timezone.utc).isoformat()
    invoke_outcomes = []  # (resolved, status_code_or_None, body, payload, error_or_None)
    for resolved in resolvable:
        try:
            status_code, body, payload = await invoke_workflow(resolved)
            invoke_outcomes.append((resolved, status_code, body, payload, None))
        except Exception as exc:  # noqa: BLE001
            invoke_outcomes.append((resolved, None, None, None, str(exc)))

    invoke_errors = [
        f"Workflow invoke failed for '{resolved.item_label}': {exc}"
        for resolved, _, _, _, exc in invoke_outcomes if exc
    ]
    non_200 = [
        (resolved, status_code) for resolved, status_code, _, _, exc in invoke_outcomes
        if exc is None and status_code != 200
    ]
    last_status_code = next((sc for _, sc, _, _, exc in reversed(invoke_outcomes) if exc is None), None)
    last_body = next((b for _, _, b, _, exc in reversed(invoke_outcomes) if exc is None), "")
    last_payload = next((p for _, _, _, p, exc in reversed(invoke_outcomes) if exc is None), {})

    if errored or invoke_errors or non_200:
        reasons = (
            [r.error for r in errored]
            + invoke_errors
            + [f"Workflow invoke for '{resolved.item_label}' returned HTTP {status_code}" for resolved, status_code in non_200]
        )
        results = []
        for test_case_id in runnable_ids:
            result = base_result(test_case_id)
            result.http_status = last_status_code
            result.response_body = str(last_body)[:500]
            result.overall_status = "FAILED"
            result.failure_reason = "; ".join(reasons)
            results.append(result)
        return blocked_results + results

    delay = random.uniform(*TARGET_VERIFY_DELAY_RANGE)
    await asyncio.sleep(delay)

    combined_codes = list(dict.fromkeys(code for resolved in resolvable for code in resolved.entitlement_codes))
    combined = ResolvedRequest(
        row=row, item_label=row.requestable_item, user_id=resolvable[0].user_id, user_login=resolvable[0].user_login,
        entitlement_codes=combined_codes,
    )
    target_status, target_reason = await verify_target_system(combined, combined.user_login)
    base_overall_status = "SUCCESS" if target_status in ("SUCCESS", "SKIPPED") else "FAILED"

    # Computed at most once, lazily, and shared across every test_case_id in this row that needs
    # it -- avoids asserting the same System Log event twice if more than one tagged id needs it.
    audit_result = None

    async def audit_check() -> tuple:
        nonlocal audit_result
        if audit_result is None:
            from lib.audit_log_check import verify_actor_is_service_account
            audit_result = await verify_actor_is_service_account(
                invoke_started_at, row.application_id, user_id=resolvable[0].user_id
            )
        return audit_result

    results = []
    for test_case_id in runnable_ids:
        checks = _checks_for(test_case_id)
        result = base_result(test_case_id)
        result.http_status = last_status_code
        result.response_body = str(last_body)[:500]

        if "sunset_present" in checks or "sunset_absent" in checks:
            # Payload-content check only -- whether expirationTime made it into the request sent
            # to the workflow -- independent of the target-system outcome below.
            result.target_system_status = "SKIPPED"
            result.overall_status, result.failure_reason = verify_expiration_in_payload(checks, last_payload)
            results.append(result)
            continue

        result.target_system_status = target_status
        result.failure_reason = target_reason
        result.overall_status = base_overall_status

        if "audit_log" in checks and result.overall_status == "SUCCESS":
            audit_status, audit_reason = await audit_check()
            if audit_status != "SUCCESS":
                result.overall_status = "FAILED"
                result.failure_reason = f"{result.failure_reason}; {audit_reason}".strip("; ")

        results.append(result)

    return blocked_results + results
