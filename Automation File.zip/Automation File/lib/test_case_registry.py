"""Accessor for config/test_case_registry.json -- the approved, permanent test case IDs (ATC_05..
ATC_487, one per app+scenario, see the approved spec "JDBC Application_Onboarding_Test_Cases
approved.xlsx" and scripts/generate_test_case_registry.py which produced this file).

Replaces the old ad hoc TC_01..TC_15-per-app template model (lib/test_catalog.py's now-removed
TEST_CASES list): every id here is globally unique and already tied to exactly one app, so
lib/workflow_runner.py / lib/grant_runner.py / lib/termination_runner.py can derive an app_id
straight from a tagged test case instead of requiring it as separate row input, and
lib/workflow_reporting.py can build each app's summary grid from exactly the ids that app has,
rather than assuming a fixed 15-per-app template.
"""

import json
import re
from pathlib import Path
from typing import Optional

from config import apps as apps_config

REGISTRY_PATH = Path(__file__).resolve().parent.parent / "config" / "test_case_registry.json"

_NUMBER_RE = re.compile(r"(\d+)")
_MULTI_SPLIT_RE = re.compile(r"[;,]")


def _load() -> dict:
    if not REGISTRY_PATH.exists():
        raise SystemExit(
            f"{REGISTRY_PATH} not found -- run `python -m scripts.generate_test_case_registry` first"
        )
    return json.loads(REGISTRY_PATH.read_text())


_REGISTRY = _load()
_VALID_IDS = set(_REGISTRY.keys())


def normalize_test_case_id(raw) -> Optional[str]:
    """Canonicalizes a raw 'test_case' spreadsheet cell (e.g. 'atc5', 'ATC-05', '5') into one of
    the registry's 'ATC_NN' ids. Returns None for a blank cell, or the stripped-upper raw text if
    it isn't a recognizable id (so callers can still see/report the bad value instead of silently
    losing it)."""
    if raw is None:
        return None
    text = str(raw).strip()
    if not text:
        return None
    if text.upper() in _VALID_IDS:
        return text.upper()
    match = _NUMBER_RE.search(text)
    if not match:
        return text.upper()
    candidate = f"ATC_{int(match.group(1)):02d}"
    if candidate in _VALID_IDS:
        return candidate
    candidate = f"ATC_{int(match.group(1))}"
    return candidate if candidate in _VALID_IDS else text.upper()


def normalize_test_case_ids(raw) -> list:
    """Same as normalize_test_case_id, but a cell may list more than one test case, ';'- or
    ','-separated. Returns a list of normalized ids, or [] for a blank cell."""
    if raw is None:
        return []
    text = str(raw).strip()
    if not text:
        return []
    parts = [p.strip() for p in _MULTI_SPLIT_RE.split(text) if p.strip()]
    return [normalize_test_case_id(p) for p in parts]


def get(atc_id: str) -> dict:
    entry = _REGISTRY.get(atc_id)
    if not entry:
        raise LookupError(f"Unrecognized test case id '{atc_id}' -- not in {REGISTRY_PATH.name}")
    return entry


def is_blocked(atc_id: str) -> bool:
    return get(atc_id)["execution"] == "blocked"


def _app_name_to_id_map() -> dict:
    """{app_name: app_id} for the current env, via config/apps.py (config/db-target-system.json).
    Built fresh each call -- these maps are tiny (<=12 entries) and this keeps the same
    "always read the current file" convention the rest of this codebase uses."""
    mapping = {}
    for app_id in apps_config.app_ids_for_env():
        name = apps_config.get_app_config(app_id).get("name")
        if name:
            mapping[name] = app_id
    return mapping


def application_id_for(atc_id: str) -> Optional[str]:
    """Resolves a test case id to the Okta app_id it belongs to, for the current environment.
    Returns None if the registry's app_name for this id has no matching entry in
    config/db-target-system.json for the current env (e.g. a QA app_id placeholder not filled
    in yet) -- callers should treat that the same as "can't resolve", not raise."""
    app_name = get(atc_id)["app_name"]
    return _app_name_to_id_map().get(app_name)


def ids_for_app(app_id: str) -> list:
    """Every test case id belonging to this app_id, in the registry's original spec order --
    drives lib/workflow_reporting.py's per-app summary grid."""
    name_to_id = _app_name_to_id_map()
    ids = [
        atc_id for atc_id, entry in _REGISTRY.items()
        if name_to_id.get(entry["app_name"]) == app_id
    ]
    return sorted(ids, key=lambda i: _REGISTRY[i]["order"])


def order_key(atc_id: Optional[str]) -> int:
    """Sort key for report ordering -- untagged/unrecognized ids sort last."""
    if atc_id and atc_id in _REGISTRY:
        return _REGISTRY[atc_id]["order"]
    return len(_REGISTRY)
