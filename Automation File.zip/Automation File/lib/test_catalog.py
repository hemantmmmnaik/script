"""Which apps are in scope for the current environment, and each app's connector type, per
config/db-target-system.json (via config/apps.py).

Test-case metadata (which ids exist, which app each belongs to, which are BLOCKED) now lives in
lib/test_case_registry.py -- see config/test_case_registry.json, generated from the approved spec
by scripts/generate_test_case_registry.py.
"""

from config import apps as apps_config


def apps_in_scope() -> list:
    """App ids the demo report should cover -- every app_id configured for the current
    environment in config/db-target-system.json (see config/apps.py, config/env_bootstrap.py).
    Generic by design: add another app there and this (and the report) picks them up
    automatically, no code change needed here."""
    return apps_config.app_ids_for_env()


def app_connector_type(app_id: str) -> str:
    try:
        connector_type = apps_config.get_app_config(app_id).get("connector_type")
    except LookupError:
        connector_type = None
    return connector_type.upper() if connector_type else "UNKNOWN"
