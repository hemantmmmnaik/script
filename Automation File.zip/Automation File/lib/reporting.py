"""Summary + per-app/connector detail report generation for run_tests.py, extending the
two-tier console/CSV/TXT report pattern proven in scripts/batch_assign_bundles.py with a
category breakdown (bundle vs entitlement) and per-app/connector grouping."""

import csv
import textwrap
from pathlib import Path
from typing import Optional

SUMMARY_WIDTH = 70
DETAIL_COL_WIDTHS = {
    "user_email": 28,
    "requested": 22,
    "okta_status": 10,
    "target_system_status": 14,
    "overall_status": 10,
    "failure_reason": 40,
}


def _counts(results: list, test_type: Optional[str] = None) -> tuple:
    subset = [r for r in results if test_type is None or r.test_type == test_type]
    total = len(subset)
    passed = sum(1 for r in subset if r.overall_status == "SUCCESS")
    return total, passed, total - passed


def _status_counts(results: list, field: str, status: str, test_type: Optional[str] = None) -> int:
    return sum(1 for r in results if getattr(r, field) == status and (test_type is None or r.test_type == test_type))


def build_summary_lines(results: list, generated_at: Optional[str] = None) -> list:
    total, passed, failed = _counts(results)
    bundle_total, bundle_pass, bundle_fail = _counts(results, "bundle")
    ent_total, ent_pass, ent_fail = _counts(results, "entitlement")

    okta_ok = _status_counts(results, "okta_status", "SUCCESS")
    okta_partial = _status_counts(results, "okta_status", "PARTIAL")
    okta_failed = _status_counts(results, "okta_status", "FAILED")
    target_ok = _status_counts(results, "target_system_status", "SUCCESS")
    target_failed = _status_counts(results, "target_system_status", "FAILED")
    target_skipped = _status_counts(results, "target_system_status", "SKIPPED")

    lines = []
    lines.append("=" * SUMMARY_WIDTH)
    lines.append("MULTI-CONNECTOR TEST RUN SUMMARY".center(SUMMARY_WIDTH))
    if generated_at:
        lines.append(f"Generated: {generated_at}".center(SUMMARY_WIDTH))
    lines.append("=" * SUMMARY_WIDTH)
    lines.append(f"{'Total Test Cases Run':<28}: {total}")
    lines.append(f"{'Total Passed':<28}: {passed}")
    lines.append(f"{'Total Failed':<28}: {failed}")
    lines.append("-" * SUMMARY_WIDTH)
    lines.append("Category Summary".center(SUMMARY_WIDTH))
    lines.append(f"{'  Bundle':<28}: {bundle_pass} Pass / {bundle_fail} Fail (of {bundle_total})")
    lines.append(f"{'  Entitlement':<28}: {ent_pass} Pass / {ent_fail} Fail (of {ent_total})")
    lines.append("-" * SUMMARY_WIDTH)
    lines.append("Okta Grant Status".center(SUMMARY_WIDTH))
    lines.append(f"{'  SUCCESS':<28}: {okta_ok}/{total}")
    lines.append(f"{'    Bundle':<26}: {_status_counts(results, 'okta_status', 'SUCCESS', 'bundle')}    "
                 f"Entitlement: {_status_counts(results, 'okta_status', 'SUCCESS', 'entitlement')}")
    lines.append(f"{'  PARTIAL':<28}: {okta_partial}/{total}")
    lines.append(f"{'    Bundle':<26}: {_status_counts(results, 'okta_status', 'PARTIAL', 'bundle')}    "
                 f"Entitlement: {_status_counts(results, 'okta_status', 'PARTIAL', 'entitlement')}")
    lines.append(f"{'  FAILED':<28}: {okta_failed}/{total}")
    lines.append(f"{'    Bundle':<26}: {_status_counts(results, 'okta_status', 'FAILED', 'bundle')}    "
                 f"Entitlement: {_status_counts(results, 'okta_status', 'FAILED', 'entitlement')}")
    lines.append("-" * SUMMARY_WIDTH)
    lines.append("Target System Status".center(SUMMARY_WIDTH))
    lines.append(f"{'  SUCCESS':<28}: {target_ok}/{total}")
    lines.append(f"{'    Bundle':<26}: {_status_counts(results, 'target_system_status', 'SUCCESS', 'bundle')}    "
                 f"Entitlement: {_status_counts(results, 'target_system_status', 'SUCCESS', 'entitlement')}")
    lines.append(f"{'  FAILED':<28}: {target_failed}/{total}")
    lines.append(f"{'    Bundle':<26}: {_status_counts(results, 'target_system_status', 'FAILED', 'bundle')}    "
                 f"Entitlement: {_status_counts(results, 'target_system_status', 'FAILED', 'entitlement')}")
    lines.append(f"{'  SKIPPED (no config)':<28}: {target_skipped}/{total}")
    lines.append(f"{'    Bundle':<26}: {_status_counts(results, 'target_system_status', 'SKIPPED', 'bundle')}    "
                 f"Entitlement: {_status_counts(results, 'target_system_status', 'SKIPPED', 'entitlement')}")
    lines.append("=" * SUMMARY_WIDTH)
    return lines


def _detail_table(rows: list) -> list:
    headers = ["user_email", "requested", "okta_status", "target_system_status", "overall_status", "failure_reason"]
    lines = []
    header_row = "  ".join(f"{h.upper():<{DETAIL_COL_WIDTHS[h]}}" for h in headers)
    lines.append(header_row)
    lines.append("-" * len(header_row))
    for r in rows:
        wrapped = {
            "user_email": textwrap.wrap(r.user_email, DETAIL_COL_WIDTHS["user_email"]) or [""],
            "requested": textwrap.wrap(r.requested, DETAIL_COL_WIDTHS["requested"]) or [""],
            "okta_status": [r.okta_status],
            "target_system_status": [r.target_system_status],
            "overall_status": [r.overall_status],
            "failure_reason": textwrap.wrap(r.failure_reason, DETAIL_COL_WIDTHS["failure_reason"]) or [""],
        }
        row_height = max(len(v) for v in wrapped.values())
        for i in range(row_height):
            cells = [f"{(wrapped[h][i] if i < len(wrapped[h]) else ''):<{DETAIL_COL_WIDTHS[h]}}" for h in headers]
            lines.append("  ".join(cells))
        lines.append("")
    return lines


def build_app_detail_lines(results: list) -> list:
    lines = []
    apps = sorted({(r.app_id, r.app_name, r.connector_type) for r in results})
    for app_id, app_name, connector_type in apps:
        app_results = [r for r in results if r.app_id == app_id]
        total, passed, failed = _counts(app_results)
        lines.append("=" * SUMMARY_WIDTH)
        lines.append(f"APP: {app_name or app_id}  [{connector_type}]  -- {passed} Pass / {failed} Fail (of {total})")
        lines.append("=" * SUMMARY_WIDTH)

        bundle_rows = [r for r in app_results if r.test_type == "bundle"]
        if bundle_rows:
            b_total, b_pass, b_fail = _counts(bundle_rows)
            lines.append(f"-- Bundle Tests: {b_pass} Pass / {b_fail} Fail (of {b_total}) --")
            lines.extend(_detail_table(bundle_rows))

        ent_rows = [r for r in app_results if r.test_type == "entitlement"]
        if ent_rows:
            e_total, e_pass, e_fail = _counts(ent_rows)
            lines.append(f"-- Entitlement Tests: {e_pass} Pass / {e_fail} Fail (of {e_total}) --")
            lines.extend(_detail_table(ent_rows))

    return lines


def print_summary(results: list) -> None:
    print("\n" + "\n".join(build_summary_lines(results)) + "\n")


def write_reports(results: list, reports_dir: Path, generated_at: str, timestamp: str) -> tuple:
    reports_dir.mkdir(parents=True, exist_ok=True)

    summary_path = reports_dir / f"summary_{timestamp}.txt"
    summary_path.write_text("\n".join(build_summary_lines(results, generated_at=generated_at)) + "\n", encoding="utf-8")

    detail_path = reports_dir / f"detail_{timestamp}.txt"
    detail_path.write_text("\n".join(build_app_detail_lines(results)) + "\n", encoding="utf-8")

    csv_path = reports_dir / f"results_{timestamp}.csv"
    fieldnames = ["app_id", "app_name", "connector_type", "test_type", "source_file", "user_email", "requested",
                  "okta_status", "target_system_status", "overall_status", "failure_reason"]
    with csv_path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()
        for r in results:
            writer.writerow({f: getattr(r, f) for f in fieldnames})

    return summary_path, detail_path, csv_path
