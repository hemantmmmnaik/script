"""Test 13 -- user termination automatically revokes all access in Target App and Target System.

Triggers termination via the Okta Workflows "termination" invoke webhook (mirrors the
assign/unassign flows in lib/workflow_runner.py -- see app/services/workflow_service.py), POSTing
{"employeeID": <id>}, then verifies per app in scope:
  - Target App: the user is no longer found in the app (Get Application User 404's) -- this alone
    is a pass for the app-assignment half of the check, on top of the existing Okta-grants check.
  - Target System: downstream access (where entitlement codes are known) is gone too.
An app the user was never assigned to before termination is reported SUCCESS with a remark noting
there was nothing to revoke, rather than being silently skipped.

Okta's own deprovisioning (removing app assignments/grants on deactivate) is asynchronous, so the
post-deactivate checks poll with a short backoff rather than checking once immediately.
"""

import asyncio
import random
from typing import Optional

from app.services import connectors_service, target_systems_service, workflow_service
from lib.grant_runner import extract_entitlement_codes, fetch_existing_grant_ids
from lib.test_catalog import apps_in_scope

# Okta-side app-assignment/grant removal on deactivate -- polled with a short backoff since it's
# usually quick, independent of how long the downstream target system takes.
DEPROVISION_POLL_ATTEMPTS = 6
DEPROVISION_POLL_DELAY_SECONDS = 5.0

# The termination webhook itself returns 200 as soon as the workflow is *triggered*, well before
# the target system has actually processed the deprovisioning -- Dell's target systems take
# 1-2 minutes end-to-end. Target-system verification must not start until that window has passed,
# on top of (not instead of) the Okta-side poll above.
TARGET_SYSTEM_VERIFY_DELAY_RANGE = (50.0, 100.0)  # seconds


async def _grants_cleared(app_id: str, user_id: str) -> bool:
    bundle_ids, value_ids = await fetch_existing_grant_ids(app_id, user_id)
    return not bundle_ids and not value_ids


async def _is_assigned_to_app(app_id: str, user_id: str) -> bool:

    """True if the Okta Get Application User API still returns this user for app_id -- i.e. the
    user is still found in the Target App. A 404 (get_app_user_assignment's assigned=False) means
    the app assignment itself was removed."""
    assignment = await connectors_service.get_app_user_assignment(app_id, user_id)
    return bool(assignment.get("assigned"))


async def _fetch_held_entitlement_codes(app_id: str, user_id: str) -> list:
    """Target-system-facing codes (externalId/name) for every entitlement/bundle value this user
    currently holds on app_id -- same GET .../grants (full_entitlements) response
    fetch_existing_grant_ids reads Okta ids from, but converted into
    extract_entitlement_codes()-style codes instead, since that's what
    target_systems_service.validate() matches against. Captured *before* deactivation so the
    target-system half of the check has something concrete to re-verify afterward, mirroring how
    lib/workflow_runner.py::verify_target_system re-checks the same codes it resolved for an
    unassign row."""
    loaded = await connectors_service.batch_grants([app_id], user_id)
    grants = (loaded[0] or {}).get("grants", []) if loaded else []
    codes = []
    for grant in grants:
        grant_type = grant.get("grantType")
        if grant_type == "ENTITLEMENT-BUNDLE":
            codes.extend(extract_entitlement_codes(grant.get("entitlementBundle") or {}))
        elif grant_type in ("ENTITLEMENT", "CUSTOM"):
            codes.extend(extract_entitlement_codes(grant))
    return codes


async def _target_system_access_cleared(app_id: str, user_login: str, user_id: str, entitlement_codes: list) -> Optional[bool]:
    """Returns True/False, or None if there's nothing to check (the user held no known entitlement
    codes on this app before termination, or the app has no target-system connector configured --
    e.g. LookupError from validate()). Same "unassign" polarity as
    lib/workflow_runner.py::verify_target_system: True (cleared) means the target system no longer
    reports access for these codes."""
    if not entitlement_codes:
        return None
    try:
        verification = await target_systems_service.validate(
            app_id=app_id, user_login=user_login, entitlement_values=entitlement_codes, user_id=user_id
        )
    except LookupError:
        return None
    return not verification.get("hasAccess")


async def verify_termination_revokes_access(
    user_id: str,
    user_login: str,
    employee_id,
    app_ids: Optional[list] = None,
) -> dict:
    """Returns:
        {"deactivated": bool, "reason": str,
         "per_app": {app_id: {"had_grants_before": bool, "okta_cleared": bool, "target_system_cleared": Optional[bool]}}}
    The entitlement/bundle codes needed for the target-system half of the check are captured from
    the user's actual Okta grants on each app *before* deactivation (see
    _fetch_held_entitlement_codes) -- the same "does access still exist downstream" check
    verify_target_system does for an unassign row, just derived here instead of supplied by the
    caller, since termination has no requestableItem input to resolve codes from.
    """
    app_ids = app_ids if app_ids is not None else apps_in_scope()

    had_grants_before = {}
    had_app_assignment_before = {}
    entitlement_codes_by_app = {}
    for app_id in app_ids:
        bundle_ids, value_ids = await fetch_existing_grant_ids(app_id, user_id)
        had_grants_before[app_id] = bool(bundle_ids or value_ids)
        had_app_assignment_before[app_id] = await _is_assigned_to_app(app_id, user_id)
        entitlement_codes_by_app[app_id] = await _fetch_held_entitlement_codes(app_id, user_id)

    try:
        status_code, body = await workflow_service.invoke_access_request(
            "termination", {"employeeID": employee_id}
        )
    except Exception as exc:  # noqa: BLE001 - surfaced to the caller as a failure, not raised
        return {"deactivated": False, "reason": f"Termination webhook call failed: {exc}", "per_app": {}}
    if not (200 <= status_code < 300):
        return {
            "deactivated": False,
            "reason": f"Termination webhook returned HTTP {status_code}: {body}",
            "per_app": {},
        }

    okta_cleared_by_app = {}
    app_assignment_cleared_by_app = {}
    for app_id in app_ids:
        okta_cleared = False
        app_assignment_cleared = False
        for attempt in range(DEPROVISION_POLL_ATTEMPTS):
            okta_cleared = await _grants_cleared(app_id, user_id)
            app_assignment_cleared = not await _is_assigned_to_app(app_id, user_id)
            if okta_cleared and app_assignment_cleared:
                break
            if attempt < DEPROVISION_POLL_ATTEMPTS - 1:
                await asyncio.sleep(DEPROVISION_POLL_DELAY_SECONDS)
        okta_cleared_by_app[app_id] = okta_cleared
        app_assignment_cleared_by_app[app_id] = app_assignment_cleared

    # The termination webhook returned 200 as soon as it was *triggered*, not once the target
    # system finished deprovisioning -- that takes 1-2 minutes end-to-end downstream, well past
    # the point Okta's own grants/assignment are already cleared above. Wait out that window once
    # for the whole batch before checking any app's target system, or the check races the
    # deprovisioning itself.
    await asyncio.sleep(random.uniform(*TARGET_SYSTEM_VERIFY_DELAY_RANGE))

    per_app = {}
    for app_id in app_ids:
        target_cleared = await _target_system_access_cleared(
            app_id, user_login, user_id, entitlement_codes_by_app.get(app_id, [])
        )
        per_app[app_id] = {
            "had_grants_before": had_grants_before[app_id],
            "had_app_assignment_before": had_app_assignment_before[app_id],
            "okta_cleared": okta_cleared_by_app[app_id],
            "app_assignment_cleared": app_assignment_cleared_by_app[app_id],
            "target_system_cleared": target_cleared,
        }

    return {"deactivated": True, "reason": "", "per_app": per_app}


def app_result(detail: dict) -> tuple:
    """Per-app SUCCESS/FAILED verdict for the Target App half of termination (registry check
    "termination_app") -- one entry of verify_termination_revokes_access()'s per_app dict, in the
    same SUCCESS/FAILED vocabulary used elsewhere (lib/grant_runner.py, lib/workflow_runner.py).

    - Not assigned to the app before termination at all: trivially SUCCESS with a remark -- there
      was nothing to remove.
    - Assigned before, but the Get Application User lookup now 404s ("user not found in the app"):
      that alone is a pass (a removed app assignment implies grants were removed with it).
    - Otherwise, fall through to the Okta-grants check.
    """
    if not detail["had_app_assignment_before"]:
        return "SUCCESS", "User was not assigned to this app before termination -- nothing to revoke"

    if detail["app_assignment_cleared"]:
        return "SUCCESS", "User no longer found in the app after termination (assignment removed)"

    reasons = ["User still found in the app after termination (assignment not removed)"]
    if not detail["okta_cleared"]:
        reasons.append("Okta grant(s) still present after deactivation")
    return "FAILED", "; ".join(reasons)


def target_system_result(detail: dict) -> tuple:
    """Per-app SUCCESS/FAILED verdict for the Target System half of termination (registry check
    "termination_target_system") -- independent of the Target App half above."""
    if not detail["had_app_assignment_before"]:
        return "SUCCESS", "User was not assigned to this app before termination -- nothing to revoke"

    if detail["target_system_cleared"] is False:
        return "FAILED", "Target-system access still present after deactivation"
    if detail["target_system_cleared"] is None:
        return "SKIPPED", "Target-system access not re-checked -- no entitlement codes supplied"
    return "SUCCESS", "Target-system access confirmed cleared after deactivation"
