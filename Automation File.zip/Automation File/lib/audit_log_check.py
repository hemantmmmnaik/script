"""Test 15 (Okta service account shown as actor in audit logs for add/revoke transactions) and the
Okta-side half of Test 12 (add/remove transactions logged in Okta -- Splunk forwarding is out of
scope, per project decision).

Queries the Okta System Log (https://developer.okta.com/docs/reference/system-log-query/) for
events tied to the app/user around the time of a create/revoke call, and requires a single event
that simultaneously has:
  - actor.alternateId == SERVICE_ACCOUNT_ALTERNATE_ID (the Okta Workflows service account -- every
    grant/revoke this test framework performs already runs as that account via app/m2m.py, so
    this verifies Okta's own audit trail reflects that, not asserting anything new about how the
    writes are made)
  - a target with type == "EntitlementManagementResource" (the grant/entitlement change itself)
  - a target with type == "AppInstance" and id == app_id (targetApp matches)
  - a target with type == "User" and id == user_id (targetUser matches), when user_id is known

The System Log's `target` field is an array of resources per event, not a single object -- an
event can carry the EntitlementManagementResource, AppInstance, and User targets all at once.
"""

import asyncio

from app.services.entitlements_service import logs_since

LOG_INDEXING_POLL_ATTEMPTS = 6
LOG_INDEXING_POLL_DELAY_SECONDS = 5.0

SERVICE_ACCOUNT_ALTERNATE_ID = "svc_oktaworkflows@dell.com"
ENTITLEMENT_TARGET_TYPE = "EntitlementManagementResource"
APP_TARGET_TYPE = "AppInstance"
USER_TARGET_TYPE = "User"


def _targets(event: dict) -> list:
    return event.get("target") or []


def _has_target(event: dict, type_: str, id_: str = None) -> bool:
    for target in _targets(event):
        if target.get("type") == type_ and (id_ is None or target.get("id") == id_):
            return True
    return False


def _actor_alternate_id(event: dict) -> str:
    return (event.get("actor") or {}).get("alternateId", "")


def event_matches(event: dict, app_id: str, user_id: str = None) -> bool:
    """The full Test 12/15 match criteria for a single System Log event."""
    if _actor_alternate_id(event) != SERVICE_ACCOUNT_ALTERNATE_ID:
        return False
    if not _has_target(event, ENTITLEMENT_TARGET_TYPE):
        return False
    if not _has_target(event, APP_TARGET_TYPE, app_id):
        return False
    if user_id and not _has_target(event, USER_TARGET_TYPE, user_id):
        return False
    return True


async def find_matching_event(since_iso: str, app_id: str, user_id: str = None) -> dict:
    """Polls the System Log for an event satisfying event_matches(), retrying for indexing lag
    (Okta's docs note events aren't always queryable immediately after they occur). Returns as
    soon as ANY attempt finds a match -- no need to keep polling once one is found. Returns None
    once every attempt is exhausted with no match.

    filter_expr always scopes the query to this app via `target.id eq "<app_id>" and target.type
    eq "AppInstance"` -- combining both clauses is required because a System Log event's target
    array can contain multiple resources (e.g. a User target with the same id pattern), so id
    alone isn't enough to pin down the AppInstance target.
    """
    filter_expr = f'target.id eq "{app_id}" and target.type eq "{APP_TARGET_TYPE}"'
    for attempt in range(1, LOG_INDEXING_POLL_ATTEMPTS + 1):
        events = await logs_since(since_iso, filter_expr=filter_expr)
        for event in events:
            if event_matches(event, app_id, user_id):
                return event
        if attempt < LOG_INDEXING_POLL_ATTEMPTS:
            await asyncio.sleep(LOG_INDEXING_POLL_DELAY_SECONDS)
    return None


async def verify_actor_is_service_account(since_iso: str, app_id: str, user_id: str = None) -> tuple:
    """Returns (status, reason) using the same SUCCESS/FAILED vocabulary as
    lib/grant_runner.py/lib/workflow_runner.py TestResult/WorkflowResult fields. Passes the moment
    one matching event is found across the poll attempts; fails only once every attempt is
    exhausted with no match."""
    event = await find_matching_event(since_iso, app_id, user_id)
    if event is not None:
        return "SUCCESS", ""

    target_desc = f'targetApp={app_id}' + (f", targetUser={user_id}" if user_id else "")
    return "FAILED", (
        f'No System Log event found matching actor.alternateId="{SERVICE_ACCOUNT_ALTERNATE_ID}", '
        f'target.type="{ENTITLEMENT_TARGET_TYPE}", {target_desc} '
        f"within {LOG_INDEXING_POLL_ATTEMPTS * LOG_INDEXING_POLL_DELAY_SECONDS:.0f}s of polling"
    )
