"""Shared grant-test execution logic used by run_tests.py, generalized from
scripts/batch_assign_bundles.py to support multiple app_ids, multiple CSV test files, and both
Okta grant types (ENTITLEMENT-BUNDLE and ENTITLEMENT), driven by config/test_mapping.py.

Depends only on app.services.* / app.okta_client / app.concurrency (module-level .env loading via
app.settings), same as batch_assign_bundles.py -- safe to run standalone, no NiceGUI dependency.
"""

import asyncio
import csv
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from app.okta_client import OktaApiError
from app.services import connectors_service, entitlements_service, target_systems_service
from lib import test_case_registry

USER_SEARCH_BATCH_SIZE = 20
MAX_RETRIES = 4
INITIAL_BACKOFF_SECONDS = 1.0


# --------------------------------------------------------------------------------------
# Data model
# --------------------------------------------------------------------------------------

@dataclass
class TestJob:
    app_id: str
    connector_type: str
    test_type: str  # "bundle" | "entitlement"
    source_file: str
    app_name: str = ""


@dataclass
class InputRow:
    line_no: int
    email: str
    targets: list  # bundle_names (list[str]) OR entitlement pairs (list[tuple[str, str]])
    test_case_id: Optional[str] = None


@dataclass
class TestResult:
    app_id: str
    connector_type: str
    test_type: str
    source_file: str
    user_email: str
    requested: str
    app_name: str = ""
    test_case_id: Optional[str] = None
    okta_status: str = "FAILED"
    target_system_status: str = "SKIPPED"
    overall_status: str = "FAILED"
    failure_reason: str = ""


# --------------------------------------------------------------------------------------
# Retry helper (Okta 429 rate limiting / transient 5xx) -- lifted from batch_assign_bundles.py
# --------------------------------------------------------------------------------------

async def call_with_retry(coro_fn, *args, **kwargs):
    attempt = 0
    while True:
        try:
            return await coro_fn(*args, **kwargs)
        except OktaApiError as exc:
            attempt += 1
            if attempt > MAX_RETRIES or (exc.status != 429 and exc.status < 500):
                raise
            delay = INITIAL_BACKOFF_SECONDS * (2 ** (attempt - 1))
            print(f"[RATE-LIMIT] Okta returned {exc.status}, retrying in {delay:.1f}s (attempt {attempt}/{MAX_RETRIES})")
            await asyncio.sleep(delay)


# --------------------------------------------------------------------------------------
# CSV parsing
# --------------------------------------------------------------------------------------

_TEST_CASE_COLUMN = "test_case"


def _read_csv_rows(file_path: str, required_column: str) -> list:
    path = Path(file_path)
    if not path.exists():
        raise SystemExit(f"Test file not found: {file_path}")

    rows = []
    with path.open(newline="", encoding="utf-8-sig") as fh:
        reader = csv.DictReader(fh)
        if reader.fieldnames is None:
            raise SystemExit(f"Test file is empty (no header row): {file_path}")
        header = {h.strip() for h in reader.fieldnames}
        if {"user_email", required_column} - header:
            raise SystemExit(
                f"{file_path} is missing required column(s). Found columns: {', '.join(reader.fieldnames)}"
            )
        for line_no, raw_row in enumerate(reader, start=2):
            email = (raw_row.get("user_email") or "").strip()
            raw_value = (raw_row.get(required_column) or "").strip()
            if not email:
                print(f"[WARN] {file_path}:{line_no}: skipping row with missing user_email")
                continue
            if not raw_value:
                print(f"[WARN] {file_path}:{line_no} ({email}): no {required_column} listed, skipping")
                continue
            test_case_ids = test_case_registry.normalize_test_case_ids(raw_row.get(_TEST_CASE_COLUMN))
            test_case_id = test_case_ids[0] if test_case_ids else None
            rows.append((line_no, email, raw_value, test_case_id))
    return rows


def read_bundle_csv(file_path: str) -> list:
    rows = []
    for line_no, email, raw_value, test_case_id in _read_csv_rows(file_path, "bundles"):
        bundle_names = [b.strip() for b in raw_value.split(";") if b.strip()]
        if bundle_names:
            rows.append(InputRow(line_no=line_no, email=email, targets=bundle_names, test_case_id=test_case_id))
    if not rows:
        raise SystemExit(f"No valid rows found in {file_path} -- nothing to process.")
    return rows


def read_entitlement_csv(file_path: str) -> list:
    """entitlements column format: 'Value;Value2' -- bare entitlement value names/codes, no
    schema qualifier required. The matching schema is resolved later by searching across all of
    the app's entitlement schemas (see fetch_entitlement_value_index/resolve_entitlement_values).
    Optional 'test_case' column ties a row back to one of config/test_case_registry.json's approved
    ATC ids -- untagged rows behave exactly as before."""
    rows = []
    for line_no, email, raw_value, test_case_id in _read_csv_rows(file_path, "entitlements"):
        value_names = [v.strip() for v in raw_value.split(";") if v.strip()]
        if value_names:
            rows.append(InputRow(line_no=line_no, email=email, targets=value_names, test_case_id=test_case_id))
    if not rows:
        raise SystemExit(f"No valid rows found in {file_path} -- nothing to process.")
    return rows


# --------------------------------------------------------------------------------------
# Okta user resolution -- lifted from batch_assign_bundles.py
# --------------------------------------------------------------------------------------

async def fetch_users_by_email(all_emails: list) -> dict:
    return await call_with_retry(lambda: connectors_service.search_users_by_emails(all_emails, USER_SEARCH_BATCH_SIZE))


# --------------------------------------------------------------------------------------
# App label lookup (for reports -- app name instead of raw app_id)
# --------------------------------------------------------------------------------------

async def fetch_app_name(app_id: str) -> str:
    try:
        app = await call_with_retry(lambda: connectors_service.get_app(app_id))
    except Exception as exc:  # noqa: BLE001 - report generation must not fail if this lookup errors
        print(f"[WARN] Could not fetch app name for {app_id}: {exc}")
        return app_id
    return (app.get("label") or app_id) if isinstance(app, dict) else app_id


# --------------------------------------------------------------------------------------
# Bundle resolution -- lifted from batch_assign_bundles.py
# --------------------------------------------------------------------------------------

async def fetch_bundles_by_name(app_id: str) -> dict:
    bundles = await call_with_retry(lambda: connectors_service.get_app_bundles(app_id))
    by_name = {}
    for bundle in bundles:
        name = bundle.get("name")
        if not name:
            continue
        if name in by_name:
            print(f"[WARN] Duplicate bundle name '{name}' for app {app_id} -- using the first match")
            continue
        by_name[name] = bundle
    return by_name


def extract_entitlement_codes(bundle: dict) -> list:
    codes = []
    for ent in bundle.get("entitlements", []) or []:
        for value in ent.get("values", []) or []:
            if isinstance(value, dict):
                code = value.get("externalId") or value.get("name") or value.get("id")
            else:
                code = value
            if code:
                codes.append(code)
    return codes


# --------------------------------------------------------------------------------------
# App-user assignment (must exist before an entitlement/bundle grant can be created) --
# https://developer.okta.com/docs/api/openapi/okta-management/management/tags/applicationusers/other/assignusertoapplication
# --------------------------------------------------------------------------------------

async def ensure_user_assigned_to_app(app_id: str, user_id: str, user_name: Optional[str] = None) -> Optional[str]:
    """Checks GET /api/v1/apps/{appId}/users/{userId}; if the user isn't already assigned, calls
    POST /api/v1/apps/{appId}/users (assignUserToApplication) to assign them. Returns None on
    success (or already-assigned), or an error message string on failure."""
    try:
        assignment = await call_with_retry(lambda: connectors_service.get_app_user_assignment(app_id, user_id))
        if assignment.get("assigned"):
            return None
        await call_with_retry(lambda: connectors_service.assign_user_to_app(app_id, user_id, user_name))
        return None
    except Exception as exc:  # noqa: BLE001 - surfaced to the caller as a row failure, not raised
        return f"Failed to assign user to application: {exc}"


# --------------------------------------------------------------------------------------
# Existing-grant lookup (duplicate-assignment detection)
# --------------------------------------------------------------------------------------

async def fetch_existing_grant_ids(app_id: str, user_id: str) -> tuple:
    """Returns (bundle_ids, value_ids) already granted to this user for this app, via the same
    GET /governance/api/v1/grants (target+targetPrincipal filter) path this repo already uses
    for this purpose (connectors_service.batch_grants, app/ui/actions.py::assigned_entitlement_ids).

    Note: GET /api/v1/apps/{appId}/users/{userId} only reports whether the user is assigned to
    the app at all -- it carries no per-entitlement/bundle detail, so it can't answer "does this
    user already have this specific entitlement/bundle". The grants list is the correct source
    for that check.
    """
    loaded = await call_with_retry(lambda: connectors_service.batch_grants([app_id], user_id))
    grants = (loaded[0] or {}).get("grants", []) if loaded else []

    bundle_ids, value_ids = set(), set()
    for grant in grants:
        grant_type = grant.get("grantType")
        if grant_type == "ENTITLEMENT-BUNDLE":
            bundle_id = grant.get("entitlementBundleId") or (grant.get("entitlementBundle") or {}).get("id")
            if bundle_id:
                bundle_ids.add(bundle_id)
        elif grant_type in ("ENTITLEMENT", "CUSTOM"):
            for ent in grant.get("entitlements", []) or []:
                for value in ent.get("values", []) or []:
                    if value.get("id"):
                        value_ids.add(value["id"])
    return bundle_ids, value_ids


# --------------------------------------------------------------------------------------
# Entitlement (value) resolution -- new, mirrors app/ui/actions.py's entitlement branch
# --------------------------------------------------------------------------------------

async def fetch_entitlement_value_index(app_id: str) -> dict:
    """Returns a flat {value_key: {"schema_id":..., "schema_name":..., "value_id":..., "code":...}}
    index across every entitlement schema for this app, keyed by both the value's name and its
    externalId (stringified) so a bare CSV value like 'ADMIN' or '23' -- with no schema qualifier
    -- can be resolved directly without the caller having to know which schema it belongs to."""
    schemas = await call_with_retry(lambda: connectors_service.get_app_entitlements(app_id))
    index = {}
    for schema in schemas:
        schema_id = schema.get("id")
        schema_name = schema.get("name")
        for value in schema.get("values", []) or []:
            value_id = value.get("id")
            if not value_id:
                continue
            code = value.get("externalId") or value.get("name") or value_id
            entry = {
                "schema_id": schema_id, "schema_name": schema_name, "value_id": value_id, "code": code,
                "value_name": value.get("name") or code,
            }
            for key in {str(value.get("name") or ""), str(value.get("externalId") or "")}:
                key = key.strip()
                if not key:
                    continue
                if key in index and index[key]["value_id"] != value_id:
                    print(f"[WARN] Entitlement value '{key}' is ambiguous for app {app_id} "
                          f"(matches schema '{index[key]['schema_name']}' and '{schema_name}') -- using the first match")
                    continue
                index[key] = entry
    return index


def resolve_entitlement_values(value_index: dict, value_names: list, existing_value_ids: Optional[set] = None) -> tuple:
    """Resolves [value_name, ...] (bare values, no schema qualifier) -> (entitlements_body_list,
    codes, errors, labels), by looking each one up in the flat per-app value_index. Values already
    present in `existing_value_ids` are excluded from the body and reported as an "already
    assigned" error instead of being re-granted. Multiple resolved values that belong to the same
    schema are grouped into a single {"id": schema_id, "values": [...]} entry, matching the
    createGrant payload shape. `labels` maps each input value_name -> a human-readable
    "SchemaName:ValueName" string (falling back to the raw input if it couldn't be resolved), so
    reports can show the actual entitlement name instead of a bare code like '23'."""
    existing_value_ids = existing_value_ids or set()
    values_by_schema = {}  # schema_id -> {"schema_id":..., "value_ids": [...]}
    codes = []
    errors = []
    labels = {}
    for value_name in value_names:
        entry = value_index.get(value_name)
        if not entry:
            errors.append(f"Entitlement value '{value_name}' not found for this app")
            labels[value_name] = value_name
            continue
        labels[value_name] = f"{entry['schema_name']}:{entry['value_name']}"
        if entry["value_id"] in existing_value_ids:
            errors.append(f"User is already assigned with entitlement '{labels[value_name]}'")
            continue
        bucket = values_by_schema.setdefault(entry["schema_id"], {"schema_id": entry["schema_id"], "value_ids": []})
        if entry["value_id"] not in bucket["value_ids"]:
            bucket["value_ids"].append(entry["value_id"])
        if entry["code"]:
            codes.append(entry["code"])
    entitlements_body = [
        {"id": bucket["schema_id"], "values": [{"id": vid} for vid in bucket["value_ids"]]}
        for bucket in values_by_schema.values()
    ]
    return entitlements_body, codes, errors, labels


# --------------------------------------------------------------------------------------
# Grant body builders -- mirrors app/ui/actions.py::_build_grant_body
# --------------------------------------------------------------------------------------

def build_bundle_grant_body(app_id: str, user_id: str, bundle_id: str) -> dict:
    return {
        "grantType": "ENTITLEMENT-BUNDLE",
        "target": {"externalId": app_id, "type": "APPLICATION"},
        "targetPrincipal": {"externalId": user_id, "type": "OKTA_USER"},
        "entitlementBundleId": bundle_id,
    }


def build_entitlement_grant_body(app_id: str, user_id: str, entitlements_body: list) -> dict:
    return {
        "grantType": "ENTITLEMENT",
        "target": {"externalId": app_id, "type": "APPLICATION"},
        "targetPrincipal": {"externalId": user_id, "type": "OKTA_USER"},
        "entitlements": entitlements_body,
    }


# --------------------------------------------------------------------------------------
# Target-system verification (shared tail of both process_* functions)
# --------------------------------------------------------------------------------------

async def _verify_target_system(result: TestResult, app_id: str, user_login: str, user_id: str, entitlement_codes: list) -> None:
    if not entitlement_codes:
        result.target_system_status = "SKIPPED"
        return
    try:
        verification = await target_systems_service.validate(
            app_id=app_id, user_login=user_login, entitlement_values=entitlement_codes, user_id=user_id
        )
        result.target_system_status = "SUCCESS" if verification.get("hasAccess") else "FAILED"
        if not verification.get("hasAccess"):
            failed_checks = [r for r in verification.get("results", []) if not r.get("hasAccess")]
            reason = f"Target system verification failed for: {failed_checks}" if failed_checks else "Target system verification returned hasAccess=False"
            result.failure_reason = f"{result.failure_reason}; {reason}".strip("; ")
    except LookupError:
        result.target_system_status = "SKIPPED"
    except Exception as exc:  # noqa: BLE001 - a single row's failure must not abort the batch
        result.target_system_status = "FAILED"
        result.failure_reason = f"{result.failure_reason}; Target system check errored: {exc}".strip("; ")


# --------------------------------------------------------------------------------------
# Per-row processing
# --------------------------------------------------------------------------------------

async def process_bundle_row(job: TestJob, row: InputRow, users_by_email: dict, bundles_by_name: dict) -> TestResult:
    result = TestResult(
        app_id=job.app_id, connector_type=job.connector_type, test_type="bundle", source_file=job.source_file,
        user_email=row.email, requested=";".join(row.targets), app_name=job.app_name,
        test_case_id=row.test_case_id,
    )

    user = users_by_email.get(row.email.strip().lower())
    if not user:
        result.failure_reason = "User not found in Okta for this email"
        return result

    user_id = user["id"]
    user_login = (user.get("profile", {}) or {}).get("login") or row.email

    assign_error = await ensure_user_assigned_to_app(job.app_id, user_id, user_login)
    if assign_error:
        result.failure_reason = assign_error
        return result

    existing_bundle_ids, _ = await fetch_existing_grant_ids(job.app_id, user_id)

    granted_bundles, grant_errors = [], []
    for bundle_name in row.targets:
        bundle = bundles_by_name.get(bundle_name)
        if not bundle:
            grant_errors.append(f"Bundle '{bundle_name}' not found for app {job.app_id}")
            continue
        if bundle["id"] in existing_bundle_ids:
            grant_errors.append(f"User is already assigned with entitlement bundle '{bundle_name}'")
            continue
        body = build_bundle_grant_body(job.app_id, user_id, bundle["id"])
        try:
            await call_with_retry(lambda body=body: entitlements_service.create_grant(body))
            granted_bundles.append(bundle)
        except Exception as exc:  # noqa: BLE001
            grant_errors.append(f"Bundle '{bundle_name}' grant failed: {exc}")

    if granted_bundles and not grant_errors:
        result.okta_status = "SUCCESS"
    elif granted_bundles and grant_errors:
        result.okta_status = "PARTIAL"
    else:
        result.okta_status = "FAILED"
    if grant_errors:
        result.failure_reason = "; ".join(grant_errors)

    if not granted_bundles:
        result.overall_status = "FAILED"
        return result

    entitlement_codes = []
    for bundle in granted_bundles:
        entitlement_codes.extend(extract_entitlement_codes(bundle))

    await _verify_target_system(result, job.app_id, user_login, user_id, entitlement_codes)
    result.overall_status = "SUCCESS" if result.okta_status == "SUCCESS" and result.target_system_status in ("SUCCESS", "SKIPPED") else "FAILED"
    return result


async def process_entitlement_row(job: TestJob, row: InputRow, users_by_email: dict, value_index: dict) -> TestResult:
    result = TestResult(
        app_id=job.app_id, connector_type=job.connector_type, test_type="entitlement", source_file=job.source_file,
        user_email=row.email, requested=";".join(row.targets), app_name=job.app_name,
        test_case_id=row.test_case_id,
    )

    user = users_by_email.get(row.email.strip().lower())
    if not user:
        result.failure_reason = "User not found in Okta for this email"
        return result

    user_id = user["id"]
    user_login = (user.get("profile", {}) or {}).get("login") or row.email

    assign_error = await ensure_user_assigned_to_app(job.app_id, user_id, user_login)
    if assign_error:
        result.failure_reason = assign_error
        return result

    _, existing_value_ids = await fetch_existing_grant_ids(job.app_id, user_id)
    entitlements_body, entitlement_codes, resolve_errors, labels = resolve_entitlement_values(
        value_index, row.targets, existing_value_ids=existing_value_ids
    )
    grant_errors = list(resolve_errors)
    result.requested = ";".join(labels.get(v, v) for v in row.targets)

    if entitlements_body:
        body = build_entitlement_grant_body(job.app_id, user_id, entitlements_body)
        try:
            await call_with_retry(lambda body=body: entitlements_service.create_grant(body))
            result.okta_status = "SUCCESS" if not grant_errors else "PARTIAL"
        except Exception as exc:  # noqa: BLE001
            grant_errors.append(f"Entitlement grant failed: {exc}")
            result.okta_status = "FAILED"
    else:
        result.okta_status = "FAILED"

    if grant_errors:
        result.failure_reason = "; ".join(grant_errors)

    if result.okta_status == "FAILED":
        result.overall_status = "FAILED"
        return result

    await _verify_target_system(result, job.app_id, user_login, user_id, entitlement_codes)
    result.overall_status = "SUCCESS" if result.okta_status == "SUCCESS" and result.target_system_status in ("SUCCESS", "SKIPPED") else "FAILED"
    return result
